import * as anchor from "@coral-xyz/anchor";
describe("simple", () => {
  it("works", async () => {
    console.log("✅ Test works!");
  });
});
