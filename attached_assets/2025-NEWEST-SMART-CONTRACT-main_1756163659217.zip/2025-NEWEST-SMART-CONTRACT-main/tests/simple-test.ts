import * as anchor from "@coral-xyz/anchor";

describe("simple-test", () => {
  it("Just logs something", async () => {
    console.log("🚀 Test started!");
    console.log("✅ Test completed!");
  });
});
