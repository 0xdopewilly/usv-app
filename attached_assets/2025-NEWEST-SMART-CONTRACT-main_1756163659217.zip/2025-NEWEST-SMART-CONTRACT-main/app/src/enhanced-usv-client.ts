// app/src/enhanced-usv-client.ts - Complete USV Token System

import * as anchor from '@coral-xyz/anchor';
import { Program } from '@coral-xyz/anchor';
import { PublicKey, SystemProgram, SYSVAR_RENT_PUBKEY, Connection } from '@solana/web3.js';
import { TOKEN_PROGRAM_ID, ASSOCIATED_TOKEN_PROGRAM_ID, getAssociatedTokenAddress } from '@solana/spl-token';
import { createHash } from 'crypto';

// Program IDs
export const USV_TOKEN_PROGRAM_ID = new PublicKey('5ANErUU8reBAF9p4LmbxKd5tEupeUwVkh9iazB6ucGSY');
export const USV_TRADING_PROGRAM_ID = new PublicKey('TradingContractProgramID11111111111111111');
export const METADATA_PROGRAM_ID = new PublicKey('metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s');

// Interfaces
export interface QRBatchResult {
  batchId: string;
  qrHashes: string[];
  count: number;
  partnerId?: string;
  transactionId: string;
}

export interface ClaimResult {
  success: boolean;
  transactionId?: string;
  error?: string;
  userEmail?: string;
}

export interface PurchaseResult {
  success: boolean;
  transactionId?: string;
  tokensReceived?: number;
  solPaid?: number;
  priceType: 'FIXED' | 'MARKET';
  error?: string;
}

export interface TokenStats {
  totalSupply: string;
  tokensClaimed: string;
  totalQrCodes: number;
  isPaused: boolean;
  authority: string;
  mint: string;
}

export interface TradingStats {
  totalSalesVolume: string;
  totalPurchases: string;
  fixedPriceCents: number;
  isActive: boolean;
}

export class EnhancedUSVTokenClient {
  private connection: Connection;
  private wallet: anchor.Wallet;
  private provider: anchor.AnchorProvider;
  private tokenProgram: Program;
  private tradingProgram: Program;

  constructor(connection: Connection, wallet: anchor.Wallet) {
    this.connection = connection;
    this.wallet = wallet;
    this.provider = new anchor.AnchorProvider(connection, wallet, {
      commitment: 'confirmed',
      preflightCommitment: 'confirmed'
    });

    // Load program IDLs (simplified for demo)
    const tokenIdl = this.getTokenIDL();
    const tradingIdl = this.getTradingIDL();

    this.tokenProgram = new Program(tokenIdl, USV_TOKEN_PROGRAM_ID, this.provider);
    this.tradingProgram = new Program(tradingIdl, USV_TRADING_PROGRAM_ID, this.provider);
  }

  // ========================================
  // CORE TOKEN FUNCTIONS
  // ========================================

  async initialize(): Promise<string> {
    const [usvState] = await this.getUSVStateAddress();
    const [mint] = await this.getMintAddress();
    const [mintAuthority] = await this.getMintAuthorityAddress();
    const [metadata] = await this.getMetadataAddress(mint);
    
    const authorityTokenAccount = await getAssociatedTokenAddress(
      mint,
      this.wallet.publicKey
    );

    const tx = await this.tokenProgram.methods
      .initialize()
      .accounts({
        usvState,
        mint,
        mintAuthority,
        metadata,
        authorityTokenAccount,
        authority: this.wallet.publicKey,
        tokenProgram: TOKEN_PROGRAM_ID,
        tokenMetadataProgram: METADATA_PROGRAM_ID,
        associatedTokenProgram: ASSOCIATED_TOKEN_PROGRAM_ID,
        systemProgram: SystemProgram.programId,
        rent: SYSVAR_RENT_PUBKEY,
      })
      .rpc();

    console.log('✅ USV Token system initialized');
    return tx;
  }

  async generateQRCodes(
    count: number,
    partnerId?: string,
    batchInfo: string = 'DEFAULT_BATCH'
  ): Promise<QRBatchResult> {
    const [usvState] = await this.getUSVStateAddress();
    const timestamp = Date.now();
    
    const [qrBatch] = await PublicKey.findProgramAddress(
      [
        Buffer.from('qr_batch'),
        this.wallet.publicKey.toBuffer(),
        Buffer.from(timestamp.toString())
      ],
      this.tokenProgram.programId
    );

    const tx = await this.tokenProgram.methods
      .generateQrCodes(count, partnerId || null, batchInfo)
      .accounts({
        usvState,
        qrBatch,
        authority: this.wallet.publicKey,
        systemProgram: SystemProgram.programId,
      })
      .rpc();

    // Generate QR hashes client-side (matching contract logic)
    const qrHashes = [];
    for (let i = 0; i < count; i++) {
      const uniqueData = `USV_${i}_${timestamp}_${this.wallet.publicKey.toString()}_${i}`;
      const hash = createHash('sha256').update(uniqueData).digest('hex').substring(0, 16);
      qrHashes.push(hash);
    }

    console.log(`✅ Generated ${count} QR codes`);
    
    return {
      batchId: `BATCH_${timestamp}`,
      qrHashes,
      count,
      partnerId,
      transactionId: tx
    };
  }

  async claimTokens(qrHash: string, userEmail?: string): Promise<ClaimResult> {
    try {
      const [usvState] = await this.getUSVStateAddress();
      const [qrClaim] = await PublicKey.findProgramAddress(
        [Buffer.from('qr_claim'), Buffer.from(qrHash)],
        this.tokenProgram.programId
      );

      const usvStateAccount = await this.tokenProgram.account.usvState.fetch(usvState);
      const authorityTokenAccount = await getAssociatedTokenAddress(
        usvStateAccount.mint,
        usvStateAccount.authority
      );

      // Note: Authority pays for claimer's token account creation
      const claimerTokenAccount = await getAssociatedTokenAddress(
        usvStateAccount.mint,
        this.wallet.publicKey
      );

      const tx = await this.tokenProgram.methods
        .claimTokens(qrHash, userEmail || null)
        .accounts({
          usvState,
          qrClaim,
          authorityTokenAccount,
          claimerTokenAccount,
          authority: usvStateAccount.authority,
          claimer: this.wallet.publicKey,
          tokenProgram: TOKEN_PROGRAM_ID,
          associatedTokenProgram: ASSOCIATED_TOKEN_PROGRAM_ID,
          systemProgram: SystemProgram.programId,
        })
        .rpc();

      console.log('✅ Successfully claimed 1 USV token');
      
      return {
        success: true,
        transactionId: tx,
        userEmail
      };

    } catch (error: any) {
      console.error('❌ Claim failed:', error);
      return {
        success: false,
        error: error.message || 'Claim failed'
      };
    }
  }

  async transferToPartner(
    partnerAddress: string,
    amount: number,
    partnerInfo: string
  ): Promise<string> {
    const [usvState] = await this.getUSVStateAddress();
    const partnerPublicKey = new PublicKey(partnerAddress);
    const usvStateAccount = await this.tokenProgram.account.usvState.fetch(usvState);
    
    const authorityTokenAccount = await getAssociatedTokenAddress(
      usvStateAccount.mint,
      this.wallet.publicKey
    );
    
    const partnerTokenAccount = await getAssociatedTokenAddress(
      usvStateAccount.mint,
      partnerPublicKey
    );

    const tokenAmount = amount * 10**6; // Convert to token decimals

    const tx = await this.tokenProgram.methods
      .transferToPartner(new anchor.BN(tokenAmount), partnerInfo)
      .accounts({
        usvState,
        authorityTokenAccount,
        partnerTokenAccount,
        partner: partnerPublicKey,
        authority: this.wallet.publicKey,
        tokenProgram: TOKEN_PROGRAM_ID,
        associatedTokenProgram: ASSOCIATED_TOKEN_PROGRAM_ID,
        systemProgram: SystemProgram.programId,
      })
      .rpc();

    console.log(`✅ Transferred ${amount} USV tokens to partner`);
    return tx;
  }

  // ========================================
  // TRADING FUNCTIONS
  // ========================================

  async initializeTrading(): Promise<string> {
    const [tradingState] = await this.getTradingStateAddress();
    const [usvMint] = await this.getMintAddress();

    const tx = await this.tradingProgram.methods
      .initializeTrading()
      .accounts({
        tradingState,
        usvMint,
        authority: this.wallet.publicKey,
        systemProgram: SystemProgram.programId,
      })
      .rpc();

    console.log('✅ Trading contract initialized');
    return tx;
  }

  async buyTokensFixedPrice(solAmount: number): Promise<PurchaseResult> {
    try {
      const [tradingState] = await this.getTradingStateAddress();
      const tradingStateAccount = await this.tradingProgram.account.tradingState.fetch(tradingState);
      
      const authorityTokenAccount = await getAssociatedTokenAddress(
        tradingStateAccount.usvMint,
        tradingStateAccount.authority
      );
      
      const buyerTokenAccount = await getAssociatedTokenAddress(
        tradingStateAccount.usvMint,
        this.wallet.publicKey
      );

      // Mock Pyth price feed (replace with actual Pyth account)
      const priceFeed = new PublicKey('11111111111111111111111111111111');

      const solAmountLamports = solAmount * anchor.web3.LAMPORTS_PER_SOL;

      const tx = await this.tradingProgram.methods
        .buyTokensFixedPrice(new anchor.BN(solAmountLamports))
        .accounts({
          tradingState,
          authorityTokenAccount,
          buyerTokenAccount,
          authority: tradingStateAccount.authority,
          buyer: this.wallet.publicKey,
          priceFeed,
          tokenProgram: TOKEN_PROGRAM_ID,
          associatedTokenProgram: ASSOCIATED_TOKEN_PROGRAM_ID,
          systemProgram: SystemProgram.programId,
        })
        .rpc();

      // Calculate tokens received (mock calculation)
      const solPriceUSD = 100; // Mock SOL price
      const tokenPriceCents = 20;
      const solValueUSD = solAmount * solPriceUSD;
      const tokensReceived = Math.floor((solValueUSD / (tokenPriceCents / 100)));

      console.log(`✅ Purchased ${tokensReceived} USV tokens for ${solAmount} SOL`);
      
      return {
        success: true,
        transactionId: tx,
        tokensReceived,
        solPaid: solAmount,
        priceType: 'FIXED'
      };

    } catch (error: any) {
      return {
        success: false,
        error: error.message || 'Purchase failed',
        priceType: 'FIXED'
      };
    }
  }

  async buyTokensMarketPrice(
    solAmount: number,
    minTokensOut: number
  ): Promise<PurchaseResult> {
    try {
      const [tradingState] = await this.getTradingStateAddress();
      const liquidityPool = new PublicKey('11111111111111111111111111111111'); // Mock pool

      const solAmountLamports = solAmount * anchor.web3.LAMPORTS_PER_SOL;
      const minTokensOutDecimals = minTokensOut * 10**6;

      const tx = await this.tradingProgram.methods
        .buyTokensMarketPrice(
          new anchor.BN(solAmountLamports),
          new anchor.BN(minTokensOutDecimals)
        )
        .accounts({
          tradingState,
          liquidityPool,
          buyer: this.wallet.publicKey,
          systemProgram: SystemProgram.programId,
        })
        .rpc();

      console.log(`✅ Market purchase completed: ${solAmount} SOL`);
      
      return {
        success: true,
        transactionId: tx,
        solPaid: solAmount,
        priceType: 'MARKET'
      };

    } catch (error: any) {
      return {
        success: false,
        error: error.message || 'Market purchase failed',
        priceType: 'MARKET'
      };
    }
  }

  async sellTokensMarketPrice(
    tokenAmount: number,
    minSolOut: number
  ): Promise<PurchaseResult> {
    try {
      const [tradingState] = await this.getTradingStateAddress();
      const liquidityPool = new PublicKey('11111111111111111111111111111111'); // Mock pool

      const tokenAmountDecimals = tokenAmount * 10**6;
      const minSolOutLamports = minSolOut * anchor.web3.LAMPORTS_PER_SOL;

      const tx = await this.tradingProgram.methods
        .sellTokensMarketPrice(
          new anchor.BN(tokenAmountDecimals),
          new anchor.BN(minSolOutLamports)
        )
        .accounts({
          tradingState,
          liquidityPool,
          seller: this.wallet.publicKey,
          tokenProgram: TOKEN_PROGRAM_ID,
          systemProgram: SystemProgram.programId,
        })
        .rpc();

      console.log(`✅ Market sell completed: ${tokenAmount} USV tokens`);
      
      return {
        success: true,
        transactionId: tx,
        tokensReceived: -tokenAmount, // Negative for sell
        priceType: 'MARKET'
      };

    } catch (error: any) {
      return {
        success: false,
        error: error.message || 'Market sell failed',
        priceType: 'MARKET'
      };
    }
  }

  // ========================================
  // UTILITY FUNCTIONS
  // ========================================

  async getTokenStats(): Promise<TokenStats> {
    const [usvState] = await this.getUSVStateAddress();
    
    await this.tokenProgram.methods
      .getStats()
      .accounts({ usvState })
      .rpc();

    const usvStateAccount = await this.tokenProgram.account.usvState.fetch(usvState);
    
    return {
      totalSupply: usvStateAccount.totalSupply.toString(),
      tokensClaimed: usvStateAccount.tokensClaimed.toString(),
      totalQrCodes: usvStateAccount.totalQrCodes,
      isPaused: usvStateAccount.isPaused,
      authority: usvStateAccount.authority.toString(),
      mint: usvStateAccount.mint.toString(),
    };
  }

  async getTradingStats(): Promise<TradingStats> {
    const [tradingState] = await this.getTradingStateAddress();
    
    await this.tradingProgram.methods
      .getTradingStats()
      .accounts({ tradingState })
      .rpc();

    const tradingStateAccount = await this.tradingProgram.account.tradingState.fetch(tradingState);
    
    return {
      totalSalesVolume: tradingStateAccount.totalSalesVolume.toString(),
      totalPurchases: tradingStateAccount.totalPurchases.toString(),
      fixedPriceCents: tradingStateAccount.fixedPriceCents,
      isActive: tradingStateAccount.isActive,
    };
  }

  async getTokenBalance(walletAddress?: PublicKey): Promise<number> {
    const address = walletAddress || this.wallet.publicKey;
    const [mint] = await this.getMintAddress();
    const tokenAccount = await getAssociatedTokenAddress(mint, address);
    
    try {
      const balance = await this.connection.getTokenAccountBalance(tokenAccount);
      return balance.value.uiAmount || 0;
    } catch (error) {
      return 0;
    }
  }

  async setPauseState(isPaused: boolean): Promise<string> {
    const [usvState] = await this.getUSVStateAddress();

    const tx = await this.tokenProgram.methods
      .setPauseState(isPaused)
      .accounts({
        usvState,
        authority: this.wallet.publicKey,
      })
      .rpc();

    console.log(`✅ Program pause state set to: ${isPaused}`);
    return tx;
  }

  async updateFixedPrice(newPriceCents: number): Promise<string> {
    const [tradingState] = await this.getTradingStateAddress();

    const tx = await this.tradingProgram.methods
      .updateFixedPrice(new anchor.BN(newPriceCents))
      .accounts({
        tradingState,
        authority: this.wallet.publicKey,
      })
      .rpc();

    console.log(`✅ Fixed price updated to: ${newPriceCents} cents`);
    return tx;
  }

  // ========================================
  // PDA HELPERS
  // ========================================

  private async getUSVStateAddress(): Promise<[PublicKey, number]> {
    return await PublicKey.findProgramAddress(
      [Buffer.from('usv_state')],
      this.tokenProgram.programId
    );
  }

  private async getMintAddress(): Promise<[PublicKey, number]> {
    return await PublicKey.findProgramAddress(
      [Buffer.from('mint')],
      this.tokenProgram.programId
    );
  }

  private async getMintAuthorityAddress(): Promise<[PublicKey, number]> {
    return await PublicKey.findProgramAddress(
      [Buffer.from('mint_authority')],
      this.tokenProgram.programId
    );
  }

  private async getTradingStateAddress(): Promise<[PublicKey, number]> {
    return await PublicKey.findProgramAddress(
      [Buffer.from('trading_state')],
      this.tradingProgram.programId
    );
  }

  private async getMetadataAddress(mint: PublicKey): Promise<[PublicKey, number]> {
    return await PublicKey.findProgramAddress(
      [
        Buffer.from('metadata'),
        METADATA_PROGRAM_ID.toBuffer(),
        mint.toBuffer(),
      ],
      METADATA_PROGRAM_ID
    );
  }

  // ========================================
  // IDL DEFINITIONS (Simplified)
  // ========================================

  private getTokenIDL(): any {
    return {
      version: "0.1.0",
      name: "usv_token",
      instructions: [
        {
          name: "initialize",
          accounts: [
            { name: "usvState", isMut: true, isSigner: false },
            { name: "mint", isMut: true, isSigner: false },
            { name: "mintAuthority", isMut: false, isSigner: false },
            { name: "metadata", isMut: true, isSigner: false },
            { name: "authorityTokenAccount", isMut: true, isSigner: false },
            { name: "authority", isMut: true, isSigner: true },
            { name: "tokenProgram", isMut: false, isSigner: false },
            { name: "tokenMetadataProgram", isMut: false, isSigner: false },
            { name: "associatedTokenProgram", isMut: false, isSigner: false },
            { name: "systemProgram", isMut: false, isSigner: false },
            { name: "rent", isMut: false, isSigner: false }
          ],
          args: []
        },
        // Add other instruction definitions...
      ],
      accounts: [
        {
          name: "USVState",
          type: {
            kind: "struct",
            fields: [
              { name: "authority", type: "publicKey" },
              { name: "mint", type: "publicKey" },
              { name: "totalSupply", type: "u64" },
              { name: "tokensClaimed", type: "u64" },
              { name: "totalQrCodes", type: "u32" },
              { name: "isPaused", type: "bool" },
              { name: "bump", type: "u8" },
              { name: "mintBump", type: "u8" }
            ]
          }
        }
      ]
    };
  }

  private getTradingIDL(): any {
    return {
      version: "0.1.0",
      name: "usv_trading",
      instructions: [
        {
          name: "initializeTrading",
          accounts: [
            { name: "tradingState", isMut: true, isSigner: false },
            { name: "usvMint", isMut: false, isSigner: false },
            { name: "authority", isMut: true, isSigner: true },
            { name: "systemProgram", isMut: false, isSigner: false }
          ],
          args: []
        },
        // Add other trading instruction definitions...
      ],
      accounts: [
        {
          name: "TradingState",
          type: {
            kind: "struct",
            fields: [
              { name: "authority", type: "publicKey" },
              { name: "usvMint", type: "publicKey" },
              { name: "fixedPriceCents", type: "u64" },
              { name: "isActive", type: "bool" },
              { name: "totalSalesVolume", type: "u64" },
              { name: "totalPurchases", type: "u64" },
              { name: "bump", type: "u8" }
            ]
          }
        }
      ]
    };
  }
}

// Factory function
export function createEnhancedUSVClient(
  connection: Connection,
  wallet: anchor.Wallet
): EnhancedUSVTokenClient {
  return new EnhancedUSVTokenClient(connection, wallet);
}

// Backend Integration Types
export interface BackendAPI {
  validateQRCode(qrHash: string): Promise<boolean>;
  markQRClaimed(qrHash: string, claimer: string): Promise<void>;
  storeUserEmail(email: string, wallet: string): Promise<void>;
  getClaimHistory(wallet: string): Promise<any[]>;
  notifyPartnerTransfer(partner: string, amount: number): Promise<void>;
}

// Export constants for frontend use
export const TOKEN_METADATA = {
  name: 'Ultra Smooth Vape',
  symbol: 'USV',
  decimals: 6,
  totalSupply: 1_000_000_000,
  fixedPriceCents: 20,
  image: 'https://indigo-big-buzzard-911.mypinata.cloud/ipfs/bafkreiaqxvhoekn67pghw56pcmtwfduvdblrdisftd66gf3pzzsjulogli'
};

export const BACKEND_ENDPOINTS = {
  BASE_URL: 'https://backend-api-y0ke.onrender.com',
  VALIDATE_QR: '/api/validate-qr',
  CLAIM_TOKEN: '/api/claim-token',
  PARTNER_TRANSFER: '/api/partner-transfer',
  STATISTICS: '/api/statistics',
  EMAIL_NOTIFICATION: '/api/email-notification'
};

// Backend Integration Class
export class USVBackendClient {
  private baseUrl: string;

  constructor(baseUrl: string = BACKEND_ENDPOINTS.BASE_URL) {
    this.baseUrl = baseUrl;
  }

  async validateQRCode(qrHash: string): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}${BACKEND_ENDPOINTS.VALIDATE_QR}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ qrHash })
      });
      const data = await response.json();
      return data.isValid && !data.isClaimed;
    } catch (error) {
      console.error('QR validation failed:', error);
      return false;
    }
  }

  async markQRClaimed(qrHash: string, claimer: string, transactionId: string): Promise<void> {
    try {
      await fetch(`${this.baseUrl}${BACKEND_ENDPOINTS.CLAIM_TOKEN}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          qrHash,
          claimer,
          transactionId,
          claimedAt: Date.now()
        })
      });
    } catch (error) {
      console.error('Failed to mark QR as claimed:', error);
    }
  }

  async storeUserEmail(email: string, wallet: string, qrHash: string): Promise<void> {
    try {
      await fetch(`${this.baseUrl}${BACKEND_ENDPOINTS.EMAIL_NOTIFICATION}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email,
          wallet,
          qrHash,
          timestamp: Date.now()
        })
      });
    } catch (error) {
      console.error('Failed to store user email:', error);
    }
  }

  async getClaimHistory(wallet: string): Promise<any[]> {
    try {
      const response = await fetch(`${this.baseUrl}/api/claim-history/${wallet}`);
      return await response.json();
    } catch (error) {
      console.error('Failed to get claim history:', error);
      return [];
    }
  }

  async notifyPartnerTransfer(partner: string, amount: number, transactionId: string): Promise<void> {
    try {
      await fetch(`${this.baseUrl}${BACKEND_ENDPOINTS.PARTNER_TRANSFER}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          partner,
          amount,
          transactionId,
          timestamp: Date.now()
        })
      });
    } catch (error) {
      console.error('Failed to notify partner transfer:', error);
    }
  }

  async getStatistics(): Promise<any> {
    try {
      const response = await fetch(`${this.baseUrl}${BACKEND_ENDPOINTS.STATISTICS}`);
      return await response.json();
    } catch (error) {
      console.error('Failed to get statistics:', error);
      return {};
    }
  }
}

// Enhanced client with backend integration
export class FullUSVClient extends EnhancedUSVTokenClient {
  private backend: USVBackendClient;

  constructor(connection: Connection, wallet: anchor.Wallet, backendUrl?: string) {
    super(connection, wallet);
    this.backend = new USVBackendClient(backendUrl);
  }

  async claimTokensWithValidation(qrHash: string, userEmail?: string): Promise<ClaimResult> {
    try {
      // First validate QR code with backend
      const isValid = await this.backend.validateQRCode(qrHash);
      if (!isValid) {
        return {
          success: false,
          error: 'Invalid or already claimed QR code'
        };
      }

      // Proceed with blockchain claim
      const result = await this.claimTokens(qrHash, userEmail);
      
      if (result.success) {
        // Mark as claimed in backend
        await this.backend.markQRClaimed(qrHash, this.wallet.publicKey.toString(), result.transactionId!);
        
        // Store email if provided
        if (userEmail) {
          await this.backend.storeUserEmail(userEmail, this.wallet.publicKey.toString(), qrHash);
        }
      }

      return result;
    } catch (error: any) {
      return {
        success: false,
        error: error.message || 'Claim validation failed'
      };
    }
  }

  async transferToPartnerWithNotification(
    partnerAddress: string,
    amount: number,
    partnerInfo: string
  ): Promise<string> {
    const tx = await this.transferToPartner(partnerAddress, amount, partnerInfo);
    
    // Notify backend of partner transfer
    await this.backend.notifyPartnerTransfer(partnerAddress, amount, tx);
    
    return tx;
  }

  async getFullStatistics(): Promise<{
    blockchain: TokenStats & TradingStats;
    backend: any;
  }> {
    const [tokenStats, tradingStats, backendStats] = await Promise.all([
      this.getTokenStats(),
      this.getTradingStats(),
      this.backend.getStatistics()
    ]);

    return {
      blockchain: { ...tokenStats, ...tradingStats },
      backend: backendStats
    };
  }

  async getClaimHistoryForWallet(wallet?: PublicKey): Promise<any[]> {
    const address = wallet || this.wallet.publicKey;
    return await this.backend.getClaimHistory(address.toString());
  }
}