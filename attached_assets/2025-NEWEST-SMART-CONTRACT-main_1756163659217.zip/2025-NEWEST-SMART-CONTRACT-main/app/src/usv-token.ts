import * as anchor from '@coral-xyz/anchor';
import { Program } from '@coral-xyz/anchor';
import { PublicKey, SystemProgram, SYSVAR_RENT_PUBKEY } from '@solana/web3.js';
import { TOKEN_PROGRAM_ID, ASSOCIATED_TOKEN_PROGRAM_ID, getAssociatedTokenAddress } from '@solana/spl-token';
import { v4 as uuidv4 } from 'uuid';

// Program ID - will be updated after deployment
export const PROGRAM_ID = new PublicKey('11111111111111111111111111111111');

// Metadata Program ID
export const METADATA_PROGRAM_ID = new PublicKey('metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s');

export interface USVTokenProgram {
  // Program methods
  initialize(): Promise<string>;
  generateQRCodes(count: number, partnerId?: string, batchInfo?: string): Promise<string[]>;
  claimTokens(qrCode: string, userEmail?: string): Promise<string>;
  buyTokens(solAmount: number): Promise<string>;
  airdropToPartner(partnerAddress: string, amount: number, partnerInfo: string): Promise<string>;
  setPauseState(isPaused: boolean): Promise<string>;
  updateTokenPrice(newPriceCents: number): Promise<string>;
  getStats(): Promise<any>;
  
  // Helper methods
  getUSVStateAddress(): Promise<[PublicKey, number]>;
  getMintAddress(): Promise<[PublicKey, number]>;
  getMintAuthorityAddress(): Promise<[PublicKey, number]>;
  getQRCodeAddress(qrCode: string): Promise<[PublicKey, number]>;
  getUserClaimHistoryAddress(userAddress: PublicKey): Promise<[PublicKey, number]>;
}

export class USVTokenClient implements USVTokenProgram {
  private program: Program;
  private provider: anchor.AnchorProvider;
  private wallet: anchor.Wallet;

  constructor(
    provider: anchor.AnchorProvider,
    programId: PublicKey = PROGRAM_ID
  ) {
    this.provider = provider;
    this.wallet = provider.wallet;
    
    // Load the program IDL
    const idl = {
      "version": "1.0.0",
      "name": "usv_token",
      "instructions": [
        {
          "name": "initialize",
          "accounts": [
            { "name": "usvState", "isMut": true, "isSigner": false },
            { "name": "mint", "isMut": true, "isSigner": false },
            { "name": "mintAuthority", "isMut": false, "isSigner": false },
            { "name": "metadata", "isMut": true, "isSigner": false },
            { "name": "adminTokenAccount", "isMut": true, "isSigner": false },
            { "name": "admin", "isMut": true, "isSigner": true },
            { "name": "tokenProgram", "isMut": false, "isSigner": false },
            { "name": "tokenMetadataProgram", "isMut": false, "isSigner": false },
            { "name": "systemProgram", "isMut": false, "isSigner": false },
            { "name": "rent", "isMut": false, "isSigner": false }
          ],
          "args": []
        },
        {
          "name": "generateQrCodes",
          "accounts": [
            { "name": "usvState", "isMut": true, "isSigner": false },
            { "name": "qrCodeAccount", "isMut": true, "isSigner": false },
            { "name": "admin", "isMut": true, "isSigner": true },
            { "name": "systemProgram", "isMut": false, "isSigner": false }
          ],
          "args": [
            { "name": "count", "type": "u32" },
            { "name": "partnerId", "type": { "option": "string" } },
            { "name": "batchInfo", "type": "string" }
          ]
        },
        {
          "name": "claimTokens",
          "accounts": [
            { "name": "usvState", "isMut": true, "isSigner": false },
            { "name": "qrCodeAccount", "isMut": true, "isSigner": false },
            { "name": "adminTokenAccount", "isMut": true, "isSigner": false },
            { "name": "claimerTokenAccount", "isMut": true, "isSigner": false },
            { "name": "userClaimHistory", "isMut": true, "isSigner": false },
            { "name": "admin", "isMut": true, "isSigner": false },
            { "name": "claimer", "isMut": true, "isSigner": true },
            { "name": "tokenProgram", "isMut": false, "isSigner": false },
            { "name": "systemProgram", "isMut": false, "isSigner": false }
          ],
          "args": [
            { "name": "qrCode", "type": "string" },
            { "name": "userEmail", "type": { "option": "string" } }
          ]
        },
        {
          "name": "buyTokens",
          "accounts": [
            { "name": "usvState", "isMut": false, "isSigner": false },
            { "name": "adminTokenAccount", "isMut": true, "isSigner": false },
            { "name": "buyerTokenAccount", "isMut": true, "isSigner": false },
            { "name": "admin", "isMut": true, "isSigner": false },
            { "name": "buyer", "isMut": true, "isSigner": true },
            { "name": "tokenProgram", "isMut": false, "isSigner": false },
            { "name": "systemProgram", "isMut": false, "isSigner": false }
          ],
          "args": [
            { "name": "solAmount", "type": "u64" }
          ]
        },
        {
          "name": "airdropToPartner",
          "accounts": [
            { "name": "usvState", "isMut": false, "isSigner": false },
            { "name": "adminTokenAccount", "isMut": true, "isSigner": false },
            { "name": "partnerTokenAccount", "isMut": true, "isSigner": false },
            { "name": "partner", "isMut": false, "isSigner": false },
            { "name": "admin", "isMut": true, "isSigner": true },
            { "name": "tokenProgram", "isMut": false, "isSigner": false },
            { "name": "systemProgram", "isMut": false, "isSigner": false }
          ],
          "args": [
            { "name": "amount", "type": "u64" },
            { "name": "partnerInfo", "type": "string" }
          ]
        },
        {
          "name": "setPauseState",
          "accounts": [
            { "name": "usvState", "isMut": true, "isSigner": false },
            { "name": "admin", "isMut": false, "isSigner": true }
          ],
          "args": [
            { "name": "isPaused", "type": "bool" }
          ]
        },
        {
          "name": "updateTokenPrice",
          "accounts": [
            { "name": "usvState", "isMut": true, "isSigner": false },
            { "name": "admin", "isMut": false, "isSigner": true }
          ],
          "args": [
            { "name": "newPriceCents", "type": "u64" }
          ]
        },
        {
          "name": "getStats",
          "accounts": [
            { "name": "usvState", "isMut": false, "isSigner": false }
          ],
          "args": []
        }
      ],
      "accounts": [
        {
          "name": "USVState",
          "type": {
            "kind": "struct",
            "fields": [
              { "name": "admin", "type": "publicKey" },
              { "name": "mint", "type": "publicKey" },
              { "name": "totalSupply", "type": "u64" },
              { "name": "tokensClaimed", "type": "u64" },
              { "name": "totalQrCodes", "type": "u32" },
              { "name": "tokenPriceCents", "type": "u64" },
              { "name": "isPaused", "type": "bool" },
              { "name": "bump", "type": "u8" }
            ]
          }
        },
        {
          "name": "QRCodeAccount",
          "type": {
            "kind": "struct",
            "fields": [
              { "name": "code", "type": "string" },
              { "name": "isClaimed", "type": "bool" },
              { "name": "partnerId", "type": { "option": "string" } },
              { "name": "batchInfo", "type": "string" },
              { "name": "createdAt", "type": "i64" },
              { "name": "claimedAt", "type": { "option": "i64" } },
              { "name": "claimer", "type": { "option": "publicKey" } },
              { "name": "bump", "type": "u8" }
            ]
          }
        }
      ]
    };

    this.program = new Program(idl as any, programId, provider);
  }

  async getUSVStateAddress(): Promise<[PublicKey, number]> {
    return await PublicKey.findProgramAddress(
      [Buffer.from('usv_state')],
      this.program.programId
    );
  }

  async getMintAddress(): Promise<[PublicKey, number]> {
    return await PublicKey.findProgramAddress(
      [Buffer.from('mint')],
      this.program.programId
    );
  }

  async getMintAuthorityAddress(): Promise<[PublicKey, number]> {
    return await PublicKey.findProgramAddress(
      [Buffer.from('mint_authority')],
      this.program.programId
    );
  }

  async getQRCodeAddress(qrCode: string): Promise<[PublicKey, number]> {
    return await PublicKey.findProgramAddress(
      [Buffer.from('qr_code'), Buffer.from(qrCode)],
      this.program.programId
    );
  }

  async getUserClaimHistoryAddress(userAddress: PublicKey): Promise<[PublicKey, number]> {
    return await PublicKey.findProgramAddress(
      [Buffer.from('user_claims'), userAddress.toBuffer()],
      this.program.programId
    );
  }

  async getMetadataAddress(mint: PublicKey): Promise<PublicKey> {
    const [address] = await PublicKey.findProgramAddress(
      [
        Buffer.from('metadata'),
        METADATA_PROGRAM_ID.toBuffer(),
        mint.toBuffer(),
      ],
      METADATA_PROGRAM_ID
    );
    return address;
  }

  async initialize(): Promise<string> {
    const [usvState] = await this.getUSVStateAddress();
    const [mint] = await this.getMintAddress();
    const [mintAuthority] = await this.getMintAuthorityAddress();
    const metadata = await this.getMetadataAddress(mint);
    
    const adminTokenAccount = await getAssociatedTokenAddress(
      mint,
      this.wallet.publicKey
    );

    const tx = await this.program.methods
      .initialize()
      .accounts({
        usvState,
        mint,
        mintAuthority,
        metadata,
        adminTokenAccount,
        admin: this.wallet.publicKey,
        tokenProgram: TOKEN_PROGRAM_ID,
        tokenMetadataProgram: METADATA_PROGRAM_ID,
        systemProgram: SystemProgram.programId,
        rent: SYSVAR_RENT_PUBKEY,
      })
      .rpc();

    console.log('✅ USV Token initialized successfully!');
    console.log('📋 Transaction signature:', tx);
    console.log('🏦 Token mint:', mint.toString());
    console.log('💰 Admin token account:', adminTokenAccount.toString());
    
    return tx;
  }

  async generateQRCodes(count: number, partnerId?: string, batchInfo = 'DEFAULT'): Promise<string[]> {
    const [usvState] = await this.getUSVStateAddress();
    const usvStateAccount = await this.program.account.usvState.fetch(usvState);
    
    const generatedCodes: string[] = [];
    
    for (let i = 0; i < count; i++) {
      const qrCodeNumber = usvStateAccount.totalQrCodes + i + 1;
      const qrCode = `USV-${qrCodeNumber.toString().padStart(4, '0')}-${Date.now().toString().slice(-6)}`;
      
      const [qrCodeAccount] = await PublicKey.findProgramAddress(
        [Buffer.from('qr_code'), Buffer.from(qrCode)],
        this.program.programId
      );

      await this.program.methods
        .generateQrCodes(count, partnerId || null, batchInfo)
        .accounts({
          usvState,
          qrCodeAccount,
          admin: this.wallet.publicKey,
          systemProgram: SystemProgram.programId,
        })
        .rpc();

      generatedCodes.push(qrCode);
    }

    console.log(`✅ Generated ${count} QR codes successfully!`);
    console.log('📋 QR Codes:', generatedCodes);
    
    return generatedCodes;
  }

  async claimTokens(qrCode: string, userEmail?: string): Promise<string> {
    const [usvState] = await this.getUSVStateAddress();
    const [qrCodeAccount] = await this.getQRCodeAddress(qrCode);
    const [mint] = await this.getMintAddress();
    const [userClaimHistory] = await this.getUserClaimHistoryAddress(this.wallet.publicKey);
    
    const usvStateAccount = await this.program.account.usvState.fetch(usvState);
    const adminPublicKey = usvStateAccount.admin;
    
    const adminTokenAccount = await getAssociatedTokenAddress(mint, adminPublicKey);
    const claimerTokenAccount = await getAssociatedTokenAddress(mint, this.wallet.publicKey);

    const tx = await this.program.methods
      .claimTokens(qrCode, userEmail || null)
      .accounts({
        usvState,
        qrCodeAccount,
        adminTokenAccount,
        claimerTokenAccount,
        userClaimHistory,
        admin: adminPublicKey,
        claimer: this.wallet.publicKey,
        tokenProgram: TOKEN_PROGRAM_ID,
        systemProgram: SystemProgram.programId,
      })
      .rpc();

    console.log('✅ Token claimed successfully!');
    console.log('📋 Transaction signature:', tx);
    console.log('🎫 QR Code:', qrCode);
    console.log('💰 Claimer token account:', claimerTokenAccount.toString());
    
    return tx;
  }

  async buyTokens(solAmount: number): Promise<string> {
    const [usvState] = await this.getUSVStateAddress();
    const [mint] = await this.getMintAddress();
    
    const usvStateAccount = await this.program.account.usvState.fetch(usvState);
    const adminPublicKey = usvStateAccount.admin;
    
    const adminTokenAccount = await getAssociatedTokenAddress(mint, adminPublicKey);
    const buyerTokenAccount = await getAssociatedTokenAddress(mint, this.wallet.publicKey);

    const tx = await this.program.methods
      .buyTokens(new anchor.BN(solAmount * anchor.web3.LAMPORTS_PER_SOL))
      .accounts({
        usvState,
        adminTokenAccount,
        buyerTokenAccount,
        admin: adminPublicKey,
        buyer: this.wallet.publicKey,
        tokenProgram: TOKEN_PROGRAM_ID,
        systemProgram: SystemProgram.programId,
      })
      .rpc();

    console.log('✅ Tokens purchased successfully!');
    console.log('📋 Transaction signature:', tx);
    console.log('💰 SOL amount:', solAmount);
    
    return tx;
  }

  async airdropToPartner(partnerAddress: string, amount: number, partnerInfo: string): Promise<string> {
    const [usvState] = await this.getUSVStateAddress();
    const [mint] = await this.getMintAddress();
    
    const partnerPublicKey = new PublicKey(partnerAddress);
    const adminTokenAccount = await getAssociatedTokenAddress(mint, this.wallet.publicKey);
    const partnerTokenAccount = await getAssociatedTokenAddress(mint, partnerPublicKey);

    const tx = await this.program.methods
      .airdropToPartner(new anchor.BN(amount), partnerInfo)
      .accounts({
        usvState,
        adminTokenAccount,
        partnerTokenAccount,
        partner: partnerPublicKey,
        admin: this.wallet.publicKey,
        tokenProgram: TOKEN_PROGRAM_ID,
        systemProgram: SystemProgram.programId,
      })
      .rpc();

    console.log('✅ Airdrop completed successfully!');
    console.log('📋 Transaction signature:', tx);
    console.log('🤝 Partner:', partnerAddress);
    console.log('💰 Amount:', amount, 'USV tokens');
    
    return tx;
  }

  async setPauseState(isPaused: boolean): Promise<string> {
    const [usvState] = await this.getUSVStateAddress();

    const tx = await this.program.methods
      .setPauseState(isPaused)
      .accounts({
        usvState,
        admin: this.wallet.publicKey,
      })
      .rpc();

    console.log(`✅ Program pause state changed to: ${isPaused}`);
    console.log('📋 Transaction signature:', tx);
    
    return tx;
  }

  async updateTokenPrice(newPriceCents: number): Promise<string> {
    const [usvState] = await this.getUSVStateAddress();

    const tx = await this.program.methods
      .updateTokenPrice(new anchor.BN(newPriceCents))
      .accounts({
        usvState,
        admin: this.wallet.publicKey,
      })
      .rpc();

    console.log(`✅ Token price updated to: ${newPriceCents} cents`);
    console.log('📋 Transaction signature:', tx);
    
    return tx;
  }

  async getStats(): Promise<any> {
    const [usvState] = await this.getUSVStateAddress();

    const tx = await this.program.methods
      .getStats()
      .accounts({
        usvState,
      })
      .rpc();

    const usvStateAccount = await this.program.account.usvState.fetch(usvState);
    
    const stats = {
      admin: usvStateAccount.admin.toString(),
      mint: usvStateAccount.mint.toString(),
      totalSupply: usvStateAccount.totalSupply.toString(),
      tokensClaimed: usvStateAccount.tokensClaimed.toString(),
      totalQrCodes: usvStateAccount.totalQrCodes,
      tokenPriceCents: usvStateAccount.tokenPriceCents.toString(),
      isPaused: usvStateAccount.isPaused,
      transactionSignature: tx
    };

    console.log('📊 USV Token Statistics:');
    console.log(stats);
    
    return stats;
  }

  // Utility methods
  async getTokenBalance(walletAddress: PublicKey): Promise<number> {
    const [mint] = await this.getMintAddress();
    const tokenAccount = await getAssociatedTokenAddress(mint, walletAddress);
    
    try {
      const balance = await this.provider.connection.getTokenAccountBalance(tokenAccount);
      return balance.value.uiAmount || 0;
    } catch (error) {
      console.log('Token account not found or no balance');
      return 0;
    }
  }

  async getQRCodeInfo(qrCode: string): Promise<any> {
    const [qrCodeAccount] = await this.getQRCodeAddress(qrCode);
    
    try {
      const qrCodeInfo = await this.program.account.qrCodeAccount.fetch(qrCodeAccount);
      return {
        code: qrCodeInfo.code,
        isClaimed: qrCodeInfo.isClaimed,
        partnerId: qrCodeInfo.partnerId,
        batchInfo: qrCodeInfo.batchInfo,
        createdAt: new Date(qrCodeInfo.createdAt * 1000),
        claimedAt: qrCodeInfo.claimedAt ? new Date(qrCodeInfo.claimedAt * 1000) : null,
        claimer: qrCodeInfo.claimer?.toString() || null
      };
    } catch (error) {
      throw new Error(`QR code ${qrCode} not found`);
    }
  }

  async getUserClaimHistory(userAddress: PublicKey): Promise<any> {
    const [userClaimHistory] = await this.getUserClaimHistoryAddress(userAddress);
    
    try {
      const history = await this.program.account.userClaimHistory.fetch(userClaimHistory);
      return {
        user: history.user.toString(),
        claimedCodes: history.claimedCodes,
        totalClaimed: history.totalClaimed.toString(),
        lastClaimAt: new Date(history.lastClaimAt * 1000)
      };
    } catch (error) {
      console.log('No claim history found for user');
      return null;
    }
  }
}

// Helper function to create a new client instance
export function createUSVTokenClient(
  connection: anchor.web3.Connection,
  wallet: anchor.Wallet,
  programId: PublicKey = PROGRAM_ID
): USVTokenClient {
  const provider = new anchor.AnchorProvider(connection, wallet, {
    commitment: 'confirmed',
    preflightCommitment: 'confirmed'
  });
  
  return new USVTokenClient(provider, programId);
}

// QR Code generation utility (for commercial use)
export function generateQRCodeFormat(sequence: number, timestamp?: number): string {
  const ts = timestamp || Date.now();
  return `USV-${sequence.toString().padStart(4, '0')}-${ts.toString().slice(-6)}`;
}

// Email notification utility (for future backend integration)
export async function notifyBackend(
  endpoint: string,
  data: {
    qrCode: string;
    walletAddress: string;
    email?: string;
    timestamp: number;
  }
): Promise<void> {
  try {
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });
    
    if (!response.ok) {
      throw new Error(`Backend notification failed: ${response.status}`);
    }
    
    console.log('✅ Backend notification sent successfully');
  } catch (error) {
    console.error('❌ Backend notification failed:', error);
    // Don't throw error - notification failure shouldn't break token claiming
  }
}

// Constants for future use
export const BACKEND_ENDPOINTS = {
  CLAIM_NOTIFICATION: 'https://backend-api-y0ke.onrender.com/api/notify-claim',
  PARTNER_NOTIFICATION: 'https://backend-api-y0ke.onrender.com/api/notify-partner',
  QR_GENERATED: 'https://backend-api-y0ke.onrender.com/api/notify-qr-generated',
};

export const TOKEN_METADATA = {
  name: 'Ultra Smooth Vape',
  symbol: 'USV',
  description: 'Experience the ultimate in vaping pleasure with Ultra Smooth Vape tokens. Each token represents a share of our premium vaping ecosystem, offering holders exclusive access to the smoothest, most refined vaping experience available. Join our community of discerning vapers who appreciate quality, innovation, and the perfect balance of flavor and satisfaction.',
  image: 'https://indigo-big-buzzard-911.mypinata.cloud/ipfs/bafkreiaqxvhoekn67pghw56pcmtwfduvdblrdisftd66gf3pzzsjulogli',
  external_url: 'https://backend-api-y0ke.onrender.com',
  attributes: [
    { trait_type: 'Type', value: 'Utility Token' },
    { trait_type: 'Decimals', value: '6' },
    { trait_type: 'Total Supply', value: '1,000,000,000' },
    { trait_type: 'Initial Price', value: '$0.20' },
    { trait_type: 'Network', value: 'Solana' },
  ],
};

// RPC Configuration
export const RPC_CONFIG = {
  DEVNET: 'https://api.devnet.solana.com',
  MAINNET: 'https://api.mainnet-beta.solana.com',
  TESTNET: 'https://api.testnet.solana.com',
  // Alternative high-performance RPC endpoints
  HELIUS_DEVNET: 'https://devnet.helius-rpc.com/?api-key=your-api-key',
  QUICKNODE_DEVNET: 'https://your-endpoint.solana-devnet.quiknode.pro/token/your-token/',
  ALCHEMY_DEVNET: 'https://solana-devnet.g.alchemy.com/v2/your-api-key',
};

// Future DEX Integration Constants (for liquidity pools)
export const DEX_CONFIG = {
  RAYDIUM: {
    programId: '675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8',
    ammProgramId: '675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8',
  },
  ORCA: {
    programId: '9W959DqEETiGZocYWCQPaJ6sBmUzgfxXfqGeTEdp3aQP',
    whirlpoolProgramId: 'whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3uctyCc',
  },
  JUPITER: {
    programId: 'JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4',
    aggregatorProgramId: 'JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4',
  },
};

export default USVTokenClient;