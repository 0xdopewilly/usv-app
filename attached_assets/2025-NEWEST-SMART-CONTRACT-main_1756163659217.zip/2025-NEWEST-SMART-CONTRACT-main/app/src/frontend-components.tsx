// Frontend Integration for USV Token System
// File: app/src/frontend-components.tsx

import React, { useState, useEffect, useCallback } from 'react';
import { Connection, PublicKey } from '@solana/web3.js';
import { useWallet, useConnection } from '@solana/wallet-adapter-react';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import { FullUSVClient, TokenStats, TradingStats, ClaimResult, PurchaseResult } from './enhanced-usv-client';

// Main USV Token App Component
export const USVTokenApp: React.FC = () => {
  const { connection } = useConnection();
  const wallet = useWallet();
  const [client, setClient] = useState<FullUSVClient | null>(null);
  const [tokenBalance, setTokenBalance] = useState<number>(0);
  const [stats, setStats] = useState<TokenStats | null>(null);
  const [tradingStats, setTradingStats] = useState<TradingStats | null>(null);

  // Initialize client when wallet connects
  useEffect(() => {
    if (wallet.connected && wallet.publicKey) {
      const usvClient = new FullUSVClient(
        connection,
        wallet as any // Type assertion for wallet adapter
      );
      setClient(usvClient);
      loadData(usvClient);
    } else {
      setClient(null);
      setTokenBalance(0);
      setStats(null);
      setTradingStats(null);
    }
  }, [wallet.connected, wallet.publicKey, connection]);

  const loadData = async (usvClient: FullUSVClient) => {
    try {
      const [balance, tokenStats, tradingStatsData] = await Promise.all([
        usvClient.getTokenBalance(),
        usvClient.getTokenStats(),
        usvClient.getTradingStats()
      ]);
      
      setTokenBalance(balance);
      setStats(tokenStats);
      setTradingStats(tradingStatsData);
    } catch (error) {
      console.error('Failed to load data:', error);
    }
  };

  const refreshData = useCallback(() => {
    if (client) {
      loadData(client);
    }
  }, [client]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-900 via-purple-900 to-indigo-900">
      <div className="container mx-auto px-4 py-8">
        <header className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-4">
            Ultra Smooth Vape Token (USV)
          </h1>
          <p className="text-violet-200 text-lg">
            Premium vaping experience on the blockchain
          </p>
        </header>

        {/* Wallet Connection */}
        <div className="flex justify-center mb-8">
          <WalletMultiButton className="!bg-violet-600 !hover:bg-violet-700" />
        </div>

        {wallet.connected && client ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Left Column */}
            <div className="space-y-6">
              <TokenBalanceCard balance={tokenBalance} onRefresh={refreshData} />
              <QRClaimCard client={client} onSuccess={refreshData} />
              <TokenPurchaseCard client={client} onSuccess={refreshData} />
            </div>

            {/* Right Column */}
            <div className="space-y-6">
              <StatsCard stats={stats} tradingStats={tradingStats} />
              <AdminPanel client={client} onUpdate={refreshData} />
              <ClaimHistoryCard client={client} />
            </div>
          </div>
        ) : (
          <div className="text-center text-violet-200 mt-16">
            <h2 className="text-2xl mb-4">Connect Your Wallet</h2>
            <p>Connect your Phantom wallet to start using USV tokens</p>
          </div>
        )}
      </div>
    </div>
  );
};

// Token Balance Display Component
interface TokenBalanceCardProps {
  balance: number;
  onRefresh: () => void;
}

const TokenBalanceCard: React.FC<TokenBalanceCardProps> = ({ balance, onRefresh }) => {
  return (
    <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-violet-500/20">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-semibold text-white">Your USV Balance</h3>
        <button
          onClick={onRefresh}
          className="p-2 rounded-lg bg-violet-600 hover:bg-violet-700 text-white transition-colors"
        >
          🔄
        </button>
      </div>
      
      <div className="flex items-center space-x-4">
        <img
          src="https://indigo-big-buzzard-911.mypinata.cloud/ipfs/bafkreiaqxvhoekn67pghw56pcmtwfduvdblrdisftd66gf3pzzsjulogli"
          alt="USV Token"
          className="w-12 h-12 rounded-full"
        />
        <div>
          <p className="text-3xl font-bold text-white">
            {balance.toLocaleString()} USV
          </p>
          <p className="text-violet-200">Ultra Smooth Vape Tokens</p>
        </div>
      </div>
    </div>
  );
};

// QR Code Claiming Component
interface QRClaimCardProps {
  client: FullUSVClient;
  onSuccess: () => void;
}

const QRClaimCard: React.FC<QRClaimCardProps> = ({ client, onSuccess }) => {
  const [qrHash, setQrHash] = useState('');
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<ClaimResult | null>(null);

  const handleClaim = async () => {
    if (!qrHash.trim()) return;
    
    setIsLoading(true);
    setResult(null);
    
    try {
      const claimResult = await client.claimTokensWithValidation(
        qrHash.trim(),
        email.trim() || undefined
      );
      
      setResult(claimResult);
      
      if (claimResult.success) {
        setQrHash('');
        setEmail('');
        onSuccess();
      }
    } catch (error) {
      setResult({
        success: false,
        error: 'Claim failed. Please try again.'
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-violet-500/20">
      <h3 className="text-xl font-semibold text-white mb-4">Claim Tokens with QR Code</h3>
      
      <div className="space-y-4">
        <div>
          <label className="block text-violet-200 mb-2">QR Code Hash</label>
          <input
            type="text"
            value={qrHash}
            onChange={(e) => setQrHash(e.target.value)}
            placeholder="Enter QR code hash..."
            className="w-full px-4 py-2 rounded-lg bg-white/5 border border-violet-500/30 text-white placeholder-violet-300 focus:outline-none focus:border-violet-400"
          />
        </div>
        
        <div>
          <label className="block text-violet-200 mb-2">Email (Optional)</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="your@email.com"
            className="w-full px-4 py-2 rounded-lg bg-white/5 border border-violet-500/30 text-white placeholder-violet-300 focus:outline-none focus:border-violet-400"
          />
        </div>
        
        <button
          onClick={handleClaim}
          disabled={isLoading || !qrHash.trim()}
          className="w-full py-3 px-4 rounded-lg bg-violet-600 hover:bg-violet-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white font-semibold transition-colors"
        >
          {isLoading ? 'Claiming...' : 'Claim 1 USV Token'}
        </button>
        
        {result && (
          <div className={`p-3 rounded-lg ${result.success ? 'bg-green-500/20 text-green-300' : 'bg-red-500/20 text-red-300'}`}>
            {result.success ? (
              <div>
                ✅ Successfully claimed 1 USV token!
                {result.transactionId && (
                  <p className="text-xs mt-1 opacity-80">
                    TX: {result.transactionId.substring(0, 20)}...
                  </p>
                )}
              </div>
            ) : (
              <div>❌ {result.error}</div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

// Token Purchase Component
interface TokenPurchaseCardProps {
  client: FullUSVClient;
  onSuccess: () => void;
}

const TokenPurchaseCard: React.FC<TokenPurchaseCardProps> = ({ client, onSuccess }) => {
  const [solAmount, setSolAmount] = useState('');
  const [purchaseType, setPurchaseType] = useState<'FIXED' | 'MARKET'>('FIXED');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<PurchaseResult | null>(null);

  const handlePurchase = async () => {
    if (!solAmount || parseFloat(solAmount) <= 0) return;
    
    setIsLoading(true);
    setResult(null);
    
    try {
      const amount = parseFloat(solAmount);
      
      const purchaseResult = purchaseType === 'FIXED'
        ? await client.buyTokensFixedPrice(amount)
        : await client.buyTokensMarketPrice(amount, 0); // No slippage protection for demo
      
      setResult(purchaseResult);
      
      if (purchaseResult.success) {
        setSolAmount('');
        onSuccess();
      }
    } catch (error) {
      setResult({
        success: false,
        error: 'Purchase failed. Please try again.',
        priceType: purchaseType
      });
    } finally {
      setIsLoading(false);
    }
  };

  const estimatedTokens = solAmount ? Math.floor(parseFloat(solAmount) * 100 / 0.20) : 0;

  return (
    <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-violet-500/20">
      <h3 className="text-xl font-semibold text-white mb-4">Purchase USV Tokens</h3>
      
      <div className="space-y-4">
        <div className="flex space-x-2">
          <button
            onClick={() => setPurchaseType('FIXED')}
            className={`flex-1 py-2 px-4 rounded-lg font-semibold transition-colors ${
              purchaseType === 'FIXED'
                ? 'bg-violet-600 text-white'
                : 'bg-white/5 text-violet-200 hover:bg-white/10'
            }`}
          >
            Fixed Price (20¢)
          </button>
          <button
            onClick={() => setPurchaseType('MARKET')}
            className={`flex-1 py-2 px-4 rounded-lg font-semibold transition-colors ${
              purchaseType === 'MARKET'
                ? 'bg-violet-600 text-white'
                : 'bg-white/5 text-violet-200 hover:bg-white/10'
            }`}
          >
            Market Price
          </button>
        </div>
        
        <div>
          <label className="block text-violet-200 mb-2">SOL Amount</label>
          <input
            type="number"
            value={solAmount}
            onChange={(e) => setSolAmount(e.target.value)}
            placeholder="0.1"
            step="0.01"
            min="0"
            className="w-full px-4 py-2 rounded-lg bg-white/5 border border-violet-500/30 text-white placeholder-violet-300 focus:outline-none focus:border-violet-400"
          />
          {purchaseType === 'FIXED' && estimatedTokens > 0 && (
            <p className="text-violet-300 text-sm mt-1">
              ≈ {estimatedTokens.toLocaleString()} USV tokens
            </p>
          )}
        </div>
        
        <button
          onClick={handlePurchase}
          disabled={isLoading || !solAmount || parseFloat(solAmount) <= 0}
          className="w-full py-3 px-4 rounded-lg bg-green-600 hover:bg-green-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white font-semibold transition-colors"
        >
          {isLoading ? 'Processing...' : `Buy Tokens (${purchaseType.toLowerCase()} price)`}
        </button>
        
        {result && (
          <div className={`p-3 rounded-lg ${result.success ? 'bg-green-500/20 text-green-300' : 'bg-red-500/20 text-red-300'}`}>
            {result.success ? (
              <div>
                ✅ Purchase successful!
                {result.tokensReceived && (
                  <p>Received: {result.tokensReceived.toLocaleString()} USV tokens</p>
                )}
                {result.transactionId && (
                  <p className="text-xs mt-1 opacity-80">
                    TX: {result.transactionId.substring(0, 20)}...
                  </p>
                )}
              </div>
            ) : (
              <div>❌ {result.error}</div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

// Statistics Display Component
interface StatsCardProps {
  stats: TokenStats | null;
  tradingStats: TradingStats | null;
}

const StatsCard: React.FC<StatsCardProps> = ({ stats, tradingStats }) => {
  if (!stats || !tradingStats) {
    return (
      <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-violet-500/20">
        <h3 className="text-xl font-semibold text-white mb-4">Loading Statistics...</h3>
      </div>
    );
  }

  const claimedPercentage = (parseInt(stats.tokensClaimed) / parseInt(stats.totalSupply)) * 100;

  return (
    <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-violet-500/20">
      <h3 className="text-xl font-semibold text-white mb-4">Token Statistics</h3>
      
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-violet-200 text-sm">Total Supply</p>
            <p className="text-white font-semibold">
              {parseInt(stats.totalSupply).toLocaleString()}
            </p>
          </div>
          <div>
            <p className="text-violet-200 text-sm">Tokens Claimed</p>
            <p className="text-white font-semibold">
              {parseInt(stats.tokensClaimed).toLocaleString()}
            </p>
          </div>
          <div>
            <p className="text-violet-200 text-sm">QR Codes Generated</p>
            <p className="text-white font-semibold">{stats.totalQrCodes.toLocaleString()}</p>
          </div>
          <div>
            <p className="text-violet-200 text-sm">Fixed Price</p>
            <p className="text-white font-semibold">{tradingStats.fixedPriceCents}¢ USD</p>
          </div>
        </div>
        
        <div>
          <p className="text-violet-200 text-sm mb-2">Claim Progress</p>
          <div className="w-full bg-white/10 rounded-full h-2">
            <div
              className="bg-violet-500 h-2 rounded-full transition-all duration-500"
              style={{ width: `${Math.min(claimedPercentage, 100)}%` }}
            />
          </div>
          <p className="text-violet-300 text-xs mt-1">
            {claimedPercentage.toFixed(4)}% claimed
          </p>
        </div>
        
        <div className="border-t border-violet-500/20 pt-4">
          <p className="text-violet-200 text-sm">Trading Volume</p>
          <p className="text-white font-semibold">
            {(parseInt(tradingStats.totalSalesVolume) / 1e9).toFixed(2)} SOL
          </p>
          <p className="text-violet-200 text-sm mt-2">Total Purchases</p>
          <p className="text-white font-semibold">{tradingStats.totalPurchases}</p>
        </div>
      </div>
    </div>
  );
};

// Admin Panel Component (only shows for authority)
interface AdminPanelProps {
  client: FullUSVClient;
  onUpdate: () => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ client, onUpdate }) => {
  const [isAdmin, setIsAdmin] = useState(false);
  const [partnerAddress, setPartnerAddress] = useState('');
  const [transferAmount, setTransferAmount] = useState('');
  const [qrCount, setQrCount] = useState('');
  const [partnerId, setPartnerId] = useState('');

  // Check if current wallet is admin (simplified check)
  useEffect(() => {
    // In production, verify against the authority from stats
    setIsAdmin(true); // For demo purposes
  }, []);

  if (!isAdmin) return null;

  const handlePartnerTransfer = async () => {
    if (!partnerAddress || !transferAmount) return;
    
    try {
      await client.transferToPartnerWithNotification(
        partnerAddress,
        parseInt(transferAmount),
        `Partner distribution: ${transferAmount} USV tokens`
      );
      setPartnerAddress('');
      setTransferAmount('');
      onUpdate();
    } catch (error) {
      console.error('Partner transfer failed:', error);
    }
  };

  const handleGenerateQRs = async () => {
    if (!qrCount) return;
    
    try {
      await client.generateQRCodes(
        parseInt(qrCount),
        partnerId || undefined,
        `Admin batch ${Date.now()}`
      );
      setQrCount('');
      setPartnerId('');
      onUpdate();
    } catch (error) {
      console.error('QR generation failed:', error);
    }
  };

  return (
    <div className="bg-red-500/10 backdrop-blur-md rounded-xl p-6 border border-red-500/20">
      <h3 className="text-xl font-semibold text-white mb-4">🔒 Admin Panel</h3>
      
      <div className="space-y-4">
        <div className="border-b border-red-500/20 pb-4">
          <h4 className="text-white font-semibold mb-2">Partner Transfer</h4>
          <div className="space-y-2">
            <input
              type="text"
              value={partnerAddress}
              onChange={(e) => setPartnerAddress(e.target.value)}
              placeholder="Partner wallet address"
              className="w-full px-3 py-2 rounded bg-white/5 border border-red-500/30 text-white placeholder-red-300 text-sm"
            />
            <input
              type="number"
              value={transferAmount}
              onChange={(e) => setTransferAmount(e.target.value)}
              placeholder="Amount (min 1000)"
              min="1000"
              className="w-full px-3 py-2 rounded bg-white/5 border border-red-500/30 text-white placeholder-red-300 text-sm"
            />
            <button
              onClick={handlePartnerTransfer}
              disabled={!partnerAddress || !transferAmount || parseInt(transferAmount) < 1000}
              className="w-full py-2 px-4 rounded bg-red-600 hover:bg-red-700 disabled:bg-gray-600 text-white font-semibold text-sm"
            >
              Transfer to Partner
            </button>
          </div>
        </div>
        
        <div>
          <h4 className="text-white font-semibold mb-2">Generate QR Codes</h4>
          <div className="space-y-2">
            <input
              type="number"
              value={qrCount}
              onChange={(e) => setQrCount(e.target.value)}
              placeholder="Number of QR codes"
              min="1"
              className="w-full px-3 py-2 rounded bg-white/5 border border-red-500/30 text-white placeholder-red-300 text-sm"
            />
            <input
              type="text"
              value={partnerId}
              onChange={(e) => setPartnerId(e.target.value)}
              placeholder="Partner ID (optional)"
              className="w-full px-3 py-2 rounded bg-white/5 border border-red-500/30 text-white placeholder-red-300 text-sm"
            />
            <button
              onClick={handleGenerateQRs}
              disabled={!qrCount || parseInt(qrCount) < 1}
              className="w-full py-2 px-4 rounded bg-red-600 hover:bg-red-700 disabled:bg-gray-600 text-white font-semibold text-sm"
            >
              Generate QR Codes
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Claim History Component
interface ClaimHistoryCardProps {
  client: FullUSVClient;
}

const ClaimHistoryCard: React.FC<ClaimHistoryCardProps> = ({ client }) => {
  const [history, setHistory] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const loadHistory = async () => {
    setIsLoading(true);
    try {
      const claimHistory = await client.getClaimHistoryForWallet();
      setHistory(claimHistory);
    } catch (error) {
      console.error('Failed to load claim history:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadHistory();
  }, [client]);

  return (
    <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-violet-500/20">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-semibold text-white">Claim History</h3>
        <button
          onClick={loadHistory}
          disabled={isLoading}
          className="p-2 rounded-lg bg-violet-600 hover:bg-violet-700 disabled:bg-gray-600 text-white transition-colors"
        >
          {isLoading ? '⏳' : '🔄'}
        </button>
      </div>
      
      {history.length > 0 ? (
        <div className="space-y-2 max-h-60 overflow-y-auto">
          {history.map((claim, index) => (
            <div
              key={index}
              className="p-3 rounded-lg bg-white/5 border border-violet-500/20"
            >
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-white font-semibold">1 USV Token</p>
                  <p className="text-violet-300 text-sm">
                    QR: {claim.qrHash?.substring(0, 12)}...
                  </p>
                  {claim.userEmail && (
                    <p className="text-violet-300 text-sm">
                      Email: {claim.userEmail}
                    </p>
                  )}
                </div>
                <div className="text-right">
                  <p className="text-violet-200 text-xs">
                    {new Date(claim.claimedAt).toLocaleDateString()}
                  </p>
                  <p className="text-violet-200 text-xs">
                    {new Date(claim.claimedAt).toLocaleTimeString()}
                  </p>
                </div>
              </div>
              {claim.transactionId && (
                <p className="text-violet-400 text-xs mt-2 font-mono">
                  TX: {claim.transactionId.substring(0, 20)}...
                </p>
              )}
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center text-violet-300 py-8">
          <p>No claims yet</p>
          <p className="text-sm">Use a QR code to claim your first USV tokens!</p>
        </div>
      )}
    </div>
  );
};

// Wallet Provider Setup Component
export const USVWalletProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="min-h-screen">
      {children}
    </div>
  );
};

// Notification Component for Success/Error Messages
interface NotificationProps {
  message: string;
  type: 'success' | 'error' | 'info';
  onClose: () => void;
}

export const Notification: React.FC<NotificationProps> = ({ message, type, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(onClose, 5000);
    return () => clearTimeout(timer);
  }, [onClose]);

  const bgColor = {
    success: 'bg-green-500/90',
    error: 'bg-red-500/90',
    info: 'bg-blue-500/90'
  }[type];

  const icon = {
    success: '✅',
    error: '❌',
    info: 'ℹ️'
  }[type];

  return (
    <div className={`fixed top-4 right-4 ${bgColor} text-white px-6 py-4 rounded-lg shadow-lg backdrop-blur-md z-50 max-w-sm`}>
      <div className="flex items-start justify-between">
        <div className="flex items-start space-x-3">
          <span className="text-xl">{icon}</span>
          <p className="text-sm font-medium">{message}</p>
        </div>
        <button
          onClick={onClose}
          className="text-white/80 hover:text-white transition-colors"
        >
          ✕
        </button>
      </div>
    </div>
  );
};

// Hook for managing notifications
export const useNotifications = () => {
  const [notifications, setNotifications] = useState<Array<{
    id: string;
    message: string;
    type: 'success' | 'error' | 'info';
  }>>([]);

  const addNotification = (message: string, type: 'success' | 'error' | 'info') => {
    const id = Date.now().toString();
    setNotifications(prev => [...prev, { id, message, type }]);
  };

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const NotificationContainer = () => (
    <div className="fixed top-4 right-4 space-y-2 z-50">
      {notifications.map(notification => (
        <Notification
          key={notification.id}
          message={notification.message}
          type={notification.type}
          onClose={() => removeNotification(notification.id)}
        />
      ))}
    </div>
  );

  return {
    addNotification,
    NotificationContainer
  };
};

// Enhanced USV App with notifications
export const USVTokenAppWithNotifications: React.FC = () => {
  const { addNotification, NotificationContainer } = useNotifications();
  const { connection } = useConnection();
  const wallet = useWallet();
  const [client, setClient] = useState<FullUSVClient | null>(null);

  // Initialize client when wallet connects
  useEffect(() => {
    if (wallet.connected && wallet.publicKey) {
      const usvClient = new FullUSVClient(connection, wallet as any);
      setClient(usvClient);
      addNotification('Wallet connected successfully!', 'success');
    } else {
      setClient(null);
      if (wallet.disconnecting) {
        addNotification('Wallet disconnected', 'info');
      }
    }
  }, [wallet.connected, wallet.publicKey, connection]);

  return (
    <>
      <USVTokenApp />
      <NotificationContainer />
    </>
  );
};

export default USVTokenApp;