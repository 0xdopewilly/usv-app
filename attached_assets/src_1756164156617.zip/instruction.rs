use anchor_lang::prelude::*;
use anchor_spl::token::{Token, TokenAccount, Mint};
use anchor_spl::metadata::Metadata as MetaplexMetadata;
use crate::state::*;

/// Initialize the USV token program
#[derive(Accounts)]
pub struct Initialize<'info> {
    #[account(
        init,
        payer = admin,
        space = 8 + USVState::LEN,
        seeds = [b"usv_state"],
        bump
    )]
    pub usv_state: Account<'info, USVState>,
    
    #[account(
        init,
        payer = admin,
        mint::decimals = 6,
        mint::authority = mint_authority,
        seeds = [b"mint"],
        bump
    )]
    pub mint: Account<'info, Mint>,
    
    /// CHECK: This is the mint authority PDA
    #[account(
        seeds = [b"mint_authority"],
        bump
    )]
    pub mint_authority: UncheckedAccount<'info>,
    
    /// CHECK: This account is checked by the metadata program
    #[account(mut)]
    pub metadata: UncheckedAccount<'info>,
    
    #[account(
        init,
        payer = admin,
        token::mint = mint,
        token::authority = admin,
    )]
    pub admin_token_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub admin: Signer<'info>,
    
    pub token_program: Program<'info, Token>,
    pub token_metadata_program: Program<'info, MetaplexMetadata>,
    pub system_program: Program<'info, System>,
    pub rent: Sysvar<'info, Rent>,
}

/// Generate QR codes
#[derive(Accounts)]
#[instruction(count: u32)]
pub struct GenerateQRCodes<'info> {
    #[account(
        mut,
        seeds = [b"usv_state"],
        bump = usv_state.bump,
        has_one = admin
    )]
    pub usv_state: Account<'info, USVState>,
    
    #[account(
        init,
        payer = admin,
        space = 8 + QRCodeAccount::LEN,
        seeds = [b"qr_code", &usv_state.total_qr_codes.to_le_bytes()],
        bump
    )]
    pub qr_code_account: Account<'info, QRCodeAccount>,
    
    #[account(mut)]
    pub admin: Signer<'info>,
    
    pub system_program: Program<'info, System>,
}

/// Claim tokens using QR code
#[derive(Accounts)]
#[instruction(qr_code: String)]
pub struct ClaimTokens<'info> {
    #[account(
        mut,
        seeds = [b"usv_state"],
        bump = usv_state.bump
    )]
    pub usv_state: Account<'info, USVState>,
    
    #[account(
        mut,
        seeds = [b"qr_code", qr_code.as_bytes()],
        bump = qr_code_account.bump
    )]
    pub qr_code_account: Account<'info, QRCodeAccount>,
    
    #[account(
        mut,
        token::mint = usv_state.mint,
        token::authority = admin,
    )]
    pub admin_token_account: Account<'info, TokenAccount>,
    
    #[account(
        init_if_needed,
        payer = claimer,
        token::mint = usv_state.mint,
        token::authority = claimer,
    )]
    pub claimer_token_account: Account<'info, TokenAccount>,
    
    #[account(
        init_if_needed,
        payer = claimer,
        space = 8 + UserClaimHistory::LEN,
        seeds = [b"user_claims", claimer.key().as_ref()],
        bump
    )]
    pub user_claim_history: Account<'info, UserClaimHistory>,
    
    /// CHECK: This is the admin account from state
    #[account(mut, address = usv_state.admin)]
    pub admin: UncheckedAccount<'info>,
    
    #[account(mut)]
    pub claimer: Signer<'info>,
    
    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

/// Buy tokens with SOL
#[derive(Accounts)]
pub struct BuyTokens<'info> {
    #[account(
        seeds = [b"usv_state"],
        bump = usv_state.bump
    )]
    pub usv_state: Account<'info, USVState>,
    
    #[account(
        mut,
        token::mint = usv_state.mint,
        token::authority = admin,
    )]
    pub admin_token_account: Account<'info, TokenAccount>,
    
    #[account(
        init_if_needed,
        payer = buyer,
        token::mint = usv_state.mint,
        token::authority = buyer,
    )]
    pub buyer_token_account: Account<'info, TokenAccount>,
    
    /// CHECK: This is the admin account from state
    #[account(mut, address = usv_state.admin)]
    pub admin: UncheckedAccount<'info>,
    
    #[account(mut)]
    pub buyer: Signer<'info>,
    
    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

/// Airdrop tokens to partners
#[derive(Accounts)]
pub struct AirdropToPartner<'info> {
    #[account(
        seeds = [b"usv_state"],
        bump = usv_state.bump,
        has_one = admin
    )]
    pub usv_state: Account<'info, USVState>,
    
    #[account(
        mut,
        token::mint = usv_state.mint,
        token::authority = admin,
    )]
    pub admin_token_account: Account<'info, TokenAccount>,
    
    #[account(
        init_if_needed,
        payer = admin,
        token::mint = usv_state.mint,
        token::authority = partner,
    )]
    pub partner_token_account: Account<'info, TokenAccount>,
    
    /// CHECK: This is the partner's wallet address
    pub partner: UncheckedAccount<'info>,
    
    #[account(mut)]
    pub admin: Signer<'info>,
    
    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

/// Set pause state
#[derive(Accounts)]
pub struct SetPauseState<'info> {
    #[account(
        mut,
        seeds = [b"usv_state"],
        bump = usv_state.bump,
        has_one = admin
    )]
    pub usv_state: Account<'info, USVState>,
    
    pub admin: Signer<'info>,
}

/// Update token price
#[derive(Accounts)]
pub struct UpdateTokenPrice<'info> {
    #[account(
        mut,
        seeds = [b"usv_state"],
        bump = usv_state.bump,
        has_one = admin
    )]
    pub usv_state: Account<'info, USVState>,
    
    pub admin: Signer<'info>,
}

/// Get program statistics
#[derive(Accounts)]
pub struct GetStats<'info> {
    #[account(
        seeds = [b"usv_state"],
        bump = usv_state.bump
    )]
    pub usv_state: Account<'info, USVState>,
}