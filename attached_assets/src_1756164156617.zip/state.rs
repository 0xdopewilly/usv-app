use anchor_lang::prelude::*;

/// Main program state
#[account]
pub struct USVState {
    /// Admin who can perform administrative actions
    pub admin: Pubkey,
    /// Token mint address
    pub mint: Pubkey,
    /// Total token supply
    pub total_supply: u64,
    /// Number of tokens claimed via QR codes
    pub tokens_claimed: u64,
    /// Total number of QR codes generated
    pub total_qr_codes: u32,
    /// Token price in cents (e.g., 20 for $0.20)
    pub token_price_cents: u64,
    /// Whether the program is paused
    pub is_paused: bool,
    /// Bump seed for PDA
    pub bump: u8,
}

impl USVState {
    pub const LEN: usize = 32 + 32 + 8 + 8 + 4 + 8 + 1 + 1 + 8; // 102 bytes + padding
}

/// QR Code account structure
#[account]
pub struct QRCodeAccount {
    /// The QR code string (format: USV-XXXX-XXXXXX)
    pub code: String,
    /// Whether this QR code has been claimed
    pub is_claimed: bool,
    /// Optional partner ID
    pub partner_id: Option<String>,
    /// Batch information
    pub batch_info: String,
    /// When the QR code was created
    pub created_at: i64,
    /// When the QR code was claimed (if claimed)
    pub claimed_at: Option<i64>,
    /// Who claimed the QR code
    pub claimer: Option<Pubkey>,
    /// Bump seed for PDA
    pub bump: u8,
}

impl QRCodeAccount {
    pub const LEN: usize = 4 + 32 + 1 + 1 + 4 + 64 + 4 + 64 + 8 + 1 + 8 + 1 + 32 + 1 + 8; // ~233 bytes + padding
}

/// User claim history
#[account]
pub struct UserClaimHistory {
    /// User's wallet address
    pub user: Pubkey,
    /// List of claimed QR codes
    pub claimed_codes: Vec<String>,
    /// Total tokens claimed by this user
    pub total_claimed: u64,
    /// Last claim timestamp
    pub last_claim_at: i64,
    /// Bump seed for PDA
    pub bump: u8,
}

impl UserClaimHistory {
    pub const LEN: usize = 32 + 4 + (4 + 32) * 50 + 8 + 8 + 1 + 8; // Support up to 50 claims per user
}

/// Partner information
#[account]
pub struct PartnerAccount {
    /// Partner's wallet address
    pub partner: Pubkey,
    /// Partner name/company
    pub name: String,
    /// Contact email
    pub email: String,
    /// Number of QR codes generated for this partner
    pub qr_codes_generated: u32,
    /// Number of tokens claimed from this partner's QR codes
    pub tokens_claimed: u64,
    /// Whether partner is active
    pub is_active: bool,
    /// When partner was registered
    pub registered_at: i64,
    /// Bump seed for PDA
    pub bump: u8,
}

impl PartnerAccount {
    pub const LEN: usize = 32 + 4 + 128 + 4 + 128 + 4 + 8 + 1 + 8 + 1 + 8; // ~322 bytes + padding
}