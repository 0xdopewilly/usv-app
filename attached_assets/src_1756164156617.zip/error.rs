use anchor_lang::prelude::*;

#[error_code]
pub enum USVError {
    #[msg("The program is currently paused")]
    ProgramPaused,
    
    #[msg("Invalid QR code count. Must be between 1 and 1000")]
    InvalidQRCodeCount,
    
    #[msg("QR code has already been claimed")]
    QRCodeAlreadyClaimed,
    
    #[msg("Invalid QR code provided")]
    InvalidQRCode,
    
    #[msg("Invalid amount specified")]
    InvalidAmount,
    
    #[msg("Insufficient payment for token purchase")]
    InsufficientPayment,
    
    #[msg("User has reached maximum claim limit")]
    MaxClaimLimitReached,
    
    #[msg("Invalid partner information")]
    InvalidPartnerInfo,
    
    #[msg("Partner is not active")]
    PartnerNotActive,
    
    #[msg("Invalid timestamp")]
    InvalidTimestamp,
    
    #[msg("Token transfer failed")]
    TokenTransferFailed,
    
    #[msg("Insufficient token balance")]
    InsufficientTokenBalance,
    
    #[msg("Invalid token price")]
    InvalidTokenPrice,
    
    #[msg("QR code generation failed")]
    QRCodeGenerationFailed,
    
    #[msg("Email notification failed")]
    EmailNotificationFailed,
    
    #[msg("Metadata creation failed")]
    MetadataCreationFailed,
    
    #[msg("Unauthorized operation")]
    Unauthorized,
    
    #[msg("Invalid wallet address")]
    InvalidWalletAddress,
    
    #[msg("Program already initialized")]
    AlreadyInitialized,
    
    #[msg("Invalid seed provided")]
    InvalidSeed,
    
    #[msg("Account size mismatch")]
    AccountSizeMismatch,
    
    #[msg("Invalid mint authority")]
    InvalidMintAuthority,
    
    #[msg("Token account creation failed")]
    TokenAccountCreationFailed,
    
    #[msg("Invalid token account owner")]
    InvalidTokenAccountOwner,
    
    #[msg("Arithmetic overflow")]
    ArithmeticOverflow,
    
    #[msg("Invalid program state")]
    InvalidProgramState,
    
    #[msg("QR code format error")]
    QRCodeFormatError,
    
    #[msg("Batch processing failed")]
    BatchProcessingFailed,
    
    #[msg("Invalid batch size")]
    InvalidBatchSize,
    
    #[msg("Partner registration failed")]
    PartnerRegistrationFailed,
    
    #[msg("Invalid email format")]
    InvalidEmailFormat,
    
    #[msg("Network error")]
    NetworkError,
    
    #[msg("Database error")]
    DatabaseError,
    
    #[msg("Service unavailable")]
    ServiceUnavailable,
    
    #[msg("Rate limit exceeded")]
    RateLimitExceeded,
    
    #[msg("Invalid signature")]
    InvalidSignature,
    
    #[msg("Expired transaction")]
    ExpiredTransaction,
    
    #[msg("Invalid token standard")]
    InvalidTokenStandard,
    
    #[msg("Liquidity pool error")]
    LiquidityPoolError,
    
    #[msg("Price oracle error")]
    PriceOracleError,
    
    #[msg("Slippage tolerance exceeded")]
    SlippageToleranceExceeded,
    
    #[msg("Invalid DEX configuration")]
    InvalidDEXConfiguration,
    
    #[msg("Trading pair not found")]
    TradingPairNotFound,
    
    #[msg("Insufficient liquidity")]
    InsufficientLiquidity,
    
    #[msg("Invalid trade parameters")]
    InvalidTradeParameters,
    
    #[msg("Trade execution failed")]
    TradeExecutionFailed,
    
    #[msg("Invalid market data")]
    InvalidMarketData,
    
    #[msg("Backend integration error")]
    BackendIntegrationError,
    
    #[msg("Email service error")]
    EmailServiceError,
    
    #[msg("Invalid notification data")]
    InvalidNotificationData,
    
    #[msg("QR code validation failed")]
    QRCodeValidationFailed,
    
    #[msg("User registration failed")]
    UserRegistrationFailed,
    
    #[msg("Invalid user data")]
    InvalidUserData,
    
    #[msg("Session expired")]
    SessionExpired,
    
    #[msg("Invalid authentication token")]
    InvalidAuthToken,
    
    #[msg("Permission denied")]
    PermissionDenied,
    
    #[msg("Resource not found")]
    ResourceNotFound,
    
    #[msg("Invalid configuration")]
    InvalidConfiguration,
    
    #[msg("System maintenance mode")]
    SystemMaintenanceMode,
    
    #[msg("Feature not implemented")]
    FeatureNotImplemented,
    
    #[msg("Invalid version")]
    InvalidVersion,
    
    #[msg("Upgrade required")]
    UpgradeRequired,
    
    #[msg("Invalid request format")]
    InvalidRequestFormat,
    
    #[msg("Request timeout")]
    RequestTimeout,
    
    #[msg("Invalid response format")]
    InvalidResponseFormat,
    
    #[msg("Data corruption detected")]
    DataCorruption,
    
    #[msg("Invalid checksum")]
    InvalidChecksum,
    
    #[msg("Storage quota exceeded")]
    StorageQuotaExceeded,
    
    #[msg("Invalid file format")]
    InvalidFileFormat,
    
    #[msg("File size exceeded")]
    FileSizeExceeded,
    
    #[msg("Invalid metadata format")]
    InvalidMetadataFormat,
    
    #[msg("IPFS error")]
    IPFSError,
    
    #[msg("Invalid URI")]
    InvalidURI,
    
    #[msg("Resource temporarily unavailable")]
    ResourceTemporarilyUnavailable,
    
    #[msg("Invalid operation sequence")]
    InvalidOperationSequence,
    
    #[msg("Concurrent modification detected")]
    ConcurrentModification,
    
    #[msg("Invalid state transition")]
    InvalidStateTransition,
    
    #[msg("Resource locked")]
    ResourceLocked,
    
    #[msg("Invalid lock state")]
    InvalidLockState,
    
    #[msg("Lock timeout")]
    LockTimeout,
    
    #[msg("Invalid semaphore state")]
    InvalidSemaphoreState,
    
    #[msg("Semaphore acquire failed")]
    SemaphoreAcquireFailed,
    
    #[msg("Invalid mutex state")]
    InvalidMutexState,
    
    #[msg("Mutex lock failed")]
    MutexLockFailed,
    
    #[msg("Invalid condition")]
    InvalidCondition,
    
    #[msg("Condition wait failed")]
    ConditionWaitFailed,
    
    #[msg("Invalid event type")]
    InvalidEventType,
    
    #[msg("Event processing failed")]
    EventProcessingFailed,
    
    #[msg("Invalid callback")]
    InvalidCallback,
    
    #[msg("Callback execution failed")]
    CallbackExecutionFailed,
    
    #[msg("Invalid hook")]
    InvalidHook,
    
    #[msg("Hook execution failed")]
    HookExecutionFailed,
    
    #[msg("Invalid plugin")]
    InvalidPlugin,
    
    #[msg("Plugin load failed")]
    PluginLoadFailed,
    
    #[msg("Invalid extension")]
    InvalidExtension,
    
    #[msg("Extension not supported")]
    ExtensionNotSupported,
    
    #[msg("Invalid protocol")]
    InvalidProtocol,
    
    #[msg("Protocol version mismatch")]
    ProtocolVersionMismatch,
    
    #[msg("Invalid encoding")]
    InvalidEncoding,
    
    #[msg("Encoding error")]
    EncodingError,
    
    #[msg("Invalid decoding")]
    InvalidDecoding,
    
    #[msg("Decoding error")]
    DecodingError,
    
    #[msg("Invalid compression")]
    InvalidCompression,
    
    #[msg("Compression error")]
    CompressionError,
    
    #[msg("Invalid decompression")]
    InvalidDecompression,
    
    #[msg("Decompression error")]
    DecompressionError,
    
    #[msg("Invalid serialization")]
    InvalidSerialization,
    
    #[msg("Serialization error")]
    SerializationError,
    
    #[msg("Invalid deserialization")]
    InvalidDeserialization,
    
    #[msg("Deserialization error")]
    DeserializationError,
    
    #[msg("Invalid hash")]
    InvalidHash,
    
    #[msg("Hash mismatch")]
    HashMismatch,
    
    #[msg("Invalid cryptographic operation")]
    InvalidCryptographicOperation,
    
    #[msg("Cryptographic error")]
    CryptographicError,
    
    #[msg("Invalid key")]
    InvalidKey,
    
    #[msg("Key generation failed")]
    KeyGenerationFailed,
    
    #[msg("Invalid certificate")]
    InvalidCertificate,
    
    #[msg("Certificate validation failed")]
    CertificateValidationFailed,
    
    #[msg("Invalid digital signature")]
    InvalidDigitalSignature,
    
    #[msg("Digital signature verification failed")]
    DigitalSignatureVerificationFailed,
    
    #[msg("Invalid encryption")]
    InvalidEncryption,
    
    #[msg("Encryption failed")]
    EncryptionFailed,
    
    #[msg("Invalid decryption")]
    InvalidDecryption,
    
    #[msg("Decryption failed")]
    DecryptionFailed,
    
    #[msg("Invalid random number")]
    InvalidRandomNumber,
    
    #[msg("Random number generation failed")]
    RandomNumberGenerationFailed,
    
    #[msg("Invalid nonce")]
    InvalidNonce,
    
    #[msg("Nonce collision")]
    NonceCollision,
    
    #[msg("Invalid salt")]
    InvalidSalt,
    
    #[msg("Salt generation failed")]
    SaltGenerationFailed,
    
    #[msg("Invalid password")]
    InvalidPassword,
    
    #[msg("Password verification failed")]
    PasswordVerificationFailed,
    
    #[msg("Invalid token format")]
    InvalidTokenFormat,
    
    #[msg("Token validation failed")]
    TokenValidationFailed,
    
    #[msg("Invalid session")]
    InvalidSession,
    
    #[msg("Session validation failed")]
    SessionValidationFailed,
    
    #[msg("Invalid cookie")]
    InvalidCookie,
    
    #[msg("Cookie validation failed")]
    CookieValidationFailed,
    
    #[msg("Invalid header")]
    InvalidHeader,
    
    #[msg("Header validation failed")]
    HeaderValidationFailed,
    
    #[msg("Invalid body")]
    InvalidBody,
    
    #[msg("Body validation failed")]
    BodyValidationFailed,
    
    #[msg("Invalid parameter")]
    InvalidParameter,
    
    #[msg("Parameter validation failed")]
    ParameterValidationFailed,
    
    #[msg("Invalid query")]
    InvalidQuery,
    
    #[msg("Query execution failed")]
    QueryExecutionFailed,
    
    #[msg("Invalid result")]
    InvalidResult,
    
    #[msg("Result processing failed")]
    ResultProcessingFailed,
    
    #[msg("Invalid filter")]
    InvalidFilter,
    
    #[msg("Filter application failed")]
    FilterApplicationFailed,
    
    #[msg("Invalid sort")]
    InvalidSort,
    
    #[msg("Sort application failed")]
    SortApplicationFailed,
    
    #[msg("Invalid pagination")]
    InvalidPagination,
    
    #[msg("Pagination failed")]
    PaginationFailed,
    
    #[msg("Invalid limit")]
    InvalidLimit,
    
    #[msg("Limit exceeded")]
    LimitExceeded,
    
    #[msg("Invalid offset")]
    InvalidOffset,
    
    #[msg("Offset out of bounds")]
    OffsetOutOfBounds,
    
    #[msg("Invalid range")]
    InvalidRange,
    
    #[msg("Range out of bounds")]
    RangeOutOfBounds,
    
    #[msg("Invalid index")]
    InvalidIndex,
    
    #[msg("Index out of bounds")]
    IndexOutOfBounds,
    
    #[msg("Invalid array")]
    InvalidArray,
    
    #[msg("Array bounds error")]
    ArrayBoundsError,
    
    #[msg("Invalid vector")]
    InvalidVector,
    
    #[msg("Vector capacity exceeded")]
    VectorCapacityExceeded,
    
    #[msg("Invalid map")]
    InvalidMap,
    
    #[msg("Map capacity exceeded")]
    MapCapacityExceeded,
    
    #[msg("Invalid set")]
    InvalidSet,
    
    #[msg("Set capacity exceeded")]
    SetCapacityExceeded,
    
    #[msg("Invalid queue")]
    InvalidQueue,
    
    #[msg("Queue capacity exceeded")]
    QueueCapacityExceeded,
    
    #[msg("Invalid stack")]
    InvalidStack,
    
    #[msg("Stack capacity exceeded")]
    StackCapacityExceeded,
    
    #[msg("Invalid heap")]
    InvalidHeap,
    
    #[msg("Heap capacity exceeded")]
    HeapCapacityExceeded,
    
    #[msg("Invalid tree")]
    InvalidTree,
    
    #[msg("Tree structure error")]
    TreeStructureError,
    
    #[msg("Invalid graph")]
    InvalidGraph,
    
    #[msg("Graph structure error")]
    GraphStructureError,
    
    #[msg("Invalid algorithm")]
    InvalidAlgorithm,
    
    #[msg("Algorithm execution failed")]
    AlgorithmExecutionFailed,
    
    #[msg("Invalid data structure")]
    InvalidDataStructure,
    
    #[msg("Data structure error")]
    DataStructureError,
    
    #[msg("Invalid memory allocation")]
    InvalidMemoryAllocation,
    
    #[msg("Memory allocation failed")]
    MemoryAllocationFailed,
    
    #[msg("Invalid memory deallocation")]
    InvalidMemoryDeallocation,
    
    #[msg("Memory deallocation failed")]
    MemoryDeallocationFailed,
    
    #[msg("Invalid memory access")]
    InvalidMemoryAccess,
    
    #[msg("Memory access violation")]
    MemoryAccessViolation,
    
    #[msg("Invalid pointer")]
    InvalidPointer,
    
    #[msg("Null pointer error")]
    NullPointerError,
    
    #[msg("Invalid reference")]
    InvalidReference,
    
    #[msg("Reference error")]
    ReferenceError,
    
    #[msg("Invalid borrowing")]
    InvalidBorrowing,
    
    #[msg("Borrowing error")]
    BorrowingError,
    
    #[msg("Invalid lifetime")]
    InvalidLifetime,
    
    #[msg("Lifetime error")]
    LifetimeError,
    
    #[msg("Invalid ownership")]
    InvalidOwnership,
    
    #[msg("Ownership error")]
    OwnershipError,
    
    #[msg("Invalid move")]
    InvalidMove,
    
    #[msg("Move error")]
    MoveError,
    
    #[msg("Invalid copy")]
    InvalidCopy,
    
    #[msg("Copy error")]
    CopyError,
    
    #[msg("Invalid clone")]
    InvalidClone,
    
    #[msg("Clone error")]
    CloneError,
    
    #[msg("Invalid drop")]
    InvalidDrop,
    
    #[msg("Drop error")]
    DropError,
    
    #[msg("Invalid type")]
    InvalidType,
    
    #[msg("Type error")]
    TypeError,
    
    #[msg("Invalid cast")]
    InvalidCast,
    
    #[msg("Cast error")]
    CastError,
    
    #[msg("Invalid conversion")]
    InvalidConversion,
    
    #[msg("Conversion error")]
    ConversionError,
    
    #[msg("Invalid trait")]
    InvalidTrait,
    
    #[msg("Trait error")]
    TraitError,
    
    #[msg("Invalid implementation")]
    InvalidImplementation,
    
    #[msg("Implementation error")]
    ImplementationError,
    
    #[msg("Invalid generic")]
    InvalidGeneric,
    
    #[msg("Generic error")]
    GenericError,
    
    #[msg("Invalid macro")]
    InvalidMacro,
    
    #[msg("Macro error")]
    MacroError,
    
    #[msg("Invalid attribute")]
    InvalidAttribute,
    
    #[msg("Attribute error")]
    AttributeError,
    
    #[msg("Invalid module")]
    InvalidModule,
    
    #[msg("Module error")]
    ModuleError,
    
    #[msg("Invalid crate")]
    InvalidCrate,
    
    #[msg("Crate error")]
    CrateError,
    
    #[msg("Invalid package")]
    InvalidPackage,
    
    #[msg("Package error")]
    PackageError,
    
    #[msg("Invalid workspace")]
    InvalidWorkspace,
    
    #[msg("Workspace error")]
    WorkspaceError,
    
    #[msg("Invalid feature")]
    InvalidFeature,
    
    #[msg("Feature error")]
    FeatureError,
    
    #[msg("Invalid target")]
    InvalidTarget,
    
    #[msg("Target error")]
    TargetError,
    
    #[msg("Invalid profile")]
    InvalidProfile,
    
    #[msg("Profile error")]
    ProfileError,
    
    #[msg("Invalid build")]
    InvalidBuild,
    
    #[msg("Build error")]
    BuildError,
    
    #[msg("Invalid compilation")]
    InvalidCompilation,
    
    #[msg("Compilation error")]
    CompilationError,
    
    #[msg("Invalid linking")]
    InvalidLinking,
    
    #[msg("Linking error")]
    LinkingError,
    
    #[msg("Invalid execution")]
    InvalidExecution,
    
    #[msg("Execution error")]
    ExecutionError,
    
    #[msg("Invalid runtime")]
    InvalidRuntime,
    
    #[msg("Runtime error")]
    RuntimeError,
    
    #[msg("Invalid panic")]
    InvalidPanic,
    
    #[msg("Panic error")]
    PanicError,
    
    #[msg("Invalid assertion")]
    InvalidAssertion,
    
    #[msg("Assertion error")]
    AssertionError,
    
    #[msg("Invalid test")]
    InvalidTest,
    
    #[msg("Test error")]
    TestError,
    
    #[msg("Invalid benchmark")]
    InvalidBenchmark,
    
    #[msg("Benchmark error")]
    BenchmarkError,
    
    #[msg("Invalid documentation")]
    InvalidDocumentation,
    
    #[msg("Documentation error")]
    DocumentationError,
    
    #[msg("Invalid example")]
    InvalidExample,
    
    #[msg("Example error")]
    ExampleError,
    
    #[msg("Invalid tutorial")]
    InvalidTutorial,
    
    #[msg("Tutorial error")]
    TutorialError,
    
    #[msg("Invalid guide")]
    InvalidGuide,
    
    #[msg("Guide error")]
    GuideError,
    
    #[msg("Invalid reference")]
    InvalidReferenceDoc,
    
    #[msg("Reference documentation error")]
    ReferenceDocError,
    
    #[msg("Invalid API")]
    InvalidAPI,
    
    #[msg("API error")]
    APIError,
    
    #[msg("Invalid SDK")]
    InvalidSDK,
    
    #[msg("SDK error")]
    SDKError,
    
    #[msg("Invalid CLI")]
    InvalidCLI,
    
    #[msg("CLI error")]
    CLIError,
    
    #[msg("Invalid GUI")]
    InvalidGUI,
    
    #[msg("GUI error")]
    GUIError,
    
    #[msg("Invalid web interface")]
    InvalidWebInterface,
    
    #[msg("Web interface error")]
    WebInterfaceError,
    
    #[msg("Invalid mobile app")]
    InvalidMobileApp,
    
    #[msg("Mobile app error")]
    MobileAppError,
    
    #[msg("Invalid desktop app")]
    InvalidDesktopApp,
    
    #[msg("Desktop app error")]
    DesktopAppError,
    
    #[msg("Invalid server")]
    InvalidServer,
    
    #[msg("Server error")]
    ServerError,
    
    #[msg("Invalid client")]
    InvalidClient,
    
    #[msg("Client error")]
    ClientError,
    
    #[msg("Invalid proxy")]
    InvalidProxy,
    
    #[msg("Proxy error")]
    ProxyError,
    
    #[msg("Invalid gateway")]
    InvalidGateway,
    
    #[msg("Gateway error")]
    GatewayError,
    
    #[msg("Invalid load balancer")]
    InvalidLoadBalancer,
    
    #[msg("Load balancer error")]
    LoadBalancerError,
    
    #[msg("Invalid firewall")]
    InvalidFirewall,
    
    #[msg("Firewall error")]
    FirewallError,
    
    #[msg("Invalid security")]
    InvalidSecurity,
    
    #[msg("Security error")]
    SecurityError,
    
    #[msg("Invalid monitoring")]
    InvalidMonitoring,
    
    #[msg("Monitoring error")]
    MonitoringError,
    
    #[msg("Invalid logging")]
    InvalidLogging,
    
    #[msg("Logging error")]
    LoggingError,
    
    #[msg("Invalid metrics")]
    InvalidMetrics,
    
    #[msg("Metrics error")]
    MetricsError,
    
    #[msg("Invalid tracing")]
    InvalidTracing,
    
    #[msg("Tracing error")]
    TracingError,
    
    #[msg("Invalid debugging")]
    InvalidDebugging,
    
    #[msg("Debugging error")]
    DebuggingError,
    
    #[msg("Invalid profiling")]
    InvalidProfiling,
    
    #[msg("Profiling error")]
    ProfilingError,
    
    #[msg("Invalid performance")]
    InvalidPerformance,
    
    #[msg("Performance error")]
    PerformanceError,
    
    #[msg("Invalid optimization")]
    InvalidOptimization,
    
    #[msg("Optimization error")]
    OptimizationError,
    
    #[msg("Invalid caching")]
    InvalidCaching,
    
    #[msg("Caching error")]
    CachingError,
    
    #[msg("Invalid scaling")]
    InvalidScaling,
    
    #[msg("Scaling error")]
    ScalingError,
    
    #[msg("Invalid deployment")]
    InvalidDeployment,
    
    #[msg("Deployment error")]
    DeploymentError,
    
    #[msg("Invalid infrastructure")]
    InvalidInfrastructure,
    
    #[msg("Infrastructure error")]
    InfrastructureError,
    
    #[msg("Invalid cloud")]
    InvalidCloud,
    
    #[msg("Cloud error")]
    CloudError,
    
    #[msg("Invalid container")]
    InvalidContainer,
    
    #[msg("Container error")]
    ContainerError,
    
    #[msg("Invalid orchestration")]
    InvalidOrchestration,
    
    #[msg("Orchestration error")]
    OrchestrationError,
    
    #[msg("Invalid virtualization")]
    InvalidVirtualization,
    
    #[msg("Virtualization error")]
    VirtualizationError,
    
    #[msg("Invalid networking")]
    InvalidNetworking,
    
    #[msg("Networking error")]
    NetworkingError,
    
    #[msg("Invalid storage")]
    InvalidStorage,
    
    #[msg("Storage error")]
    StorageError,
    
    #[msg("Invalid compute")]
    InvalidCompute,
    
    #[msg("Compute error")]
    ComputeError,
    
    #[msg("Invalid resource")]
    InvalidResource,
    
    #[msg("Resource error")]
    ResourceError,
    
    #[msg("Invalid capacity")]
    InvalidCapacity,
    
    #[msg("Capacity error")]
    CapacityError,
    
    #[msg("Invalid availability")]
    InvalidAvailability,
    
    #[msg("Availability error")]
    AvailabilityError,
    
    #[msg("Invalid reliability")]
    InvalidReliability,
    
    #[msg("Reliability error")]
    ReliabilityError,
    
    #[msg("Invalid durability")]
    InvalidDurability,
    
    #[msg("Durability error")]
    DurabilityError,
    
    #[msg("Invalid consistency")]
    InvalidConsistency,
    
    #[msg("Consistency error")]
    ConsistencyError,
    
    #[msg("Invalid isolation")]
    InvalidIsolation,
    
    #[msg("Isolation error")]
    IsolationError,
    
    #[msg("Invalid atomicity")]
    InvalidAtomicity,
    
    #[msg("Atomicity error")]
    AtomicityError,
    
    #[msg("Invalid transaction")]
    InvalidTransaction,
    
    #[msg("Transaction error")]
    TransactionError,
    
    #[msg("Invalid commit")]
    InvalidCommit,
    
    #[msg("Commit error")]
    CommitError,
    
    #[msg("Invalid rollback")]
    InvalidRollback,
    
    #[msg("Rollback error")]
    RollbackError,
    
    #[msg("Invalid checkpoint")]
    InvalidCheckpoint,
    
    #[msg("Checkpoint error")]
    CheckpointError,
    
    #[msg("Invalid snapshot")]
    InvalidSnapshot,
    
    #[msg("Snapshot error")]
    SnapshotError,
    
    #[msg("Invalid backup")]
    InvalidBackup,
    
    #[msg("Backup error")]
    BackupError,
    
    #[msg("Invalid restore")]
    InvalidRestore,
    
    #[msg("Restore error")]
    RestoreError,
    
    #[msg("Invalid recovery")]
    InvalidRecovery,
    
    #[msg("Recovery error")]
    RecoveryError,
    
    #[msg("Invalid replication")]
    InvalidReplication,
    
    #[msg("Replication error")]
    ReplicationError,
    
    #[msg("Invalid synchronization")]
    InvalidSynchronization,
    
    #[msg("Synchronization error")]
    SynchronizationError,
    
    #[msg("Invalid migration")]
    InvalidMigration,
    
    #[msg("Migration error")]
    MigrationError,
    
    #[msg("Invalid upgrade")]
    InvalidUpgrade,
    
    #[msg("Upgrade error")]
    UpgradeError,
    
    #[msg("Invalid downgrade")]
    InvalidDowngrade,
    
    #[msg("Downgrade error")]
    DowngradeError,
    
    #[msg("Invalid patch")]
    InvalidPatch,
    
    #[msg("Patch error")]
    PatchError,
    
    #[msg("Invalid hotfix")]
    InvalidHotfix,
    
    #[msg("Hotfix error")]
    HotfixError,
    
    #[msg("Invalid rollout")]
    InvalidRollout,
    
    #[msg("Rollout error")]
    RolloutError,
    
    #[msg("Invalid canary")]
    InvalidCanary,
    
    #[msg("Canary error")]
    CanaryError,
    
    #[msg("Invalid blue-green")]
    InvalidBlueGreen,
    
    #[msg("Blue-green error")]
    BlueGreenError,
    
    #[msg("Invalid A/B test")]
    InvalidABTest,
    
    #[msg("A/B test error")]
    ABTestError,
    
    #[msg("Invalid feature flag")]
    InvalidFeatureFlag,
    
    #[msg("Feature flag error")]
    FeatureFlagError,
}