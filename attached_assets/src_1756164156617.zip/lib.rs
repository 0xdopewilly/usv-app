use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount, Mint, MintTo, Transfer};
use anchor_spl::metadata::{
    create_metadata_accounts_v3, mpl_token_metadata::types::DataV2, CreateMetadataAccountsV3,
    Metadata as MetaplexMetadata,
};

declare_id!("HcLq8Q3pMYjg3RCn9N56AFbXpj2oXjz7YNXVJs1q9KyB");

pub mod error;
pub mod instruction;
pub mod state;

use error::*;
use instruction::*;
use state::*;

// Constants
const LAMPORTS_PER_SOL: u64 = 1_000_000_000;

#[program]
pub mod usv_token {
    use super::*;

    /// Initialize the USV token program
    pub fn initialize(ctx: Context<Initialize>) -> Result<()> {
        let usv_state = &mut ctx.accounts.usv_state;
        
        // Initialize state
        usv_state.admin = ctx.accounts.admin.key();
        usv_state.mint = ctx.accounts.mint.key();
        usv_state.total_supply = 1_000_000_000 * 10_u64.pow(6); // 1B tokens with 6 decimals
        usv_state.tokens_claimed = 0;
        usv_state.total_qr_codes = 0;
        usv_state.token_price_cents = 20; // $0.20
        usv_state.is_paused = false;
        usv_state.bump = ctx.bumps.usv_state;

        // Create token metadata
        let metadata_ctx = CpiContext::new(
            ctx.accounts.token_metadata_program.to_account_info(),
            CreateMetadataAccountsV3 {
                metadata: ctx.accounts.metadata.to_account_info(),
                mint: ctx.accounts.mint.to_account_info(),
                mint_authority: ctx.accounts.mint_authority.to_account_info(),
                update_authority: ctx.accounts.admin.to_account_info(),
                payer: ctx.accounts.admin.to_account_info(),
                system_program: ctx.accounts.system_program.to_account_info(),
                rent: ctx.accounts.rent.to_account_info(),
            },
        );

        let data_v2 = DataV2 {
            name: "Ultra Smooth Vape".to_string(),
            symbol: "USV".to_string(),
            uri: "https://indigo-big-buzzard-911.mypinata.cloud/ipfs/bafkreiaqxvhoekn67pghw56pcmtwfduvdblrdisftd66gf3pzzsjulogli".to_string(),
            seller_fee_basis_points: 0,
            creators: None,
            collection: None,
            uses: None,
        };

        create_metadata_accounts_v3(metadata_ctx, data_v2, false, true, None)?;

        // Mint all tokens to admin's token account
        let mint_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            MintTo {
                mint: ctx.accounts.mint.to_account_info(),
                to: ctx.accounts.admin_token_account.to_account_info(),
                authority: ctx.accounts.mint_authority.to_account_info(),
            },
        );

        token::mint_to(mint_ctx, usv_state.total_supply)?;

        msg!("USV Token initialized successfully!");
        msg!("Total supply: {} tokens", usv_state.total_supply);
        msg!("Admin: {}", usv_state.admin);
        
        Ok(())
    }

    /// Generate QR codes for partners/stores
    pub fn generate_qr_codes(
        ctx: Context<GenerateQRCodes>,
        count: u32,
        partner_id: Option<String>,
        batch_info: String,
    ) -> Result<()> {
        let usv_state = &mut ctx.accounts.usv_state;
        
        require!(!usv_state.is_paused, USVError::ProgramPaused);
        require!(count > 0 && count <= 1000, USVError::InvalidQRCodeCount);

        let clock = Clock::get()?;
        let current_slot = clock.slot;
        
        // Generate QR codes in format: USV-XXXX-XXXXXX
        for i in 0..count {
            let qr_code = format!(
                "USV-{:04}-{:06}",
                (usv_state.total_qr_codes + i + 1) % 10000,
                current_slot % 1000000
            );
            
            let qr_account = &mut ctx.accounts.qr_code_account;
            qr_account.code = qr_code.clone();
            qr_account.is_claimed = false;
            qr_account.partner_id = partner_id.clone();
            qr_account.batch_info = batch_info.clone();
            qr_account.created_at = clock.unix_timestamp;
            qr_account.claimed_at = None;
            qr_account.claimer = None;
            qr_account.bump = ctx.bumps.qr_code_account;
            
            msg!("Generated QR code: {}", qr_code);
        }

        usv_state.total_qr_codes += count;
        
        msg!("Generated {} QR codes for batch: {}", count, batch_info);
        Ok(())
    }

    /// Claim tokens using QR code
    pub fn claim_tokens(
        ctx: Context<ClaimTokens>,
        qr_code: String,
        user_email: Option<String>,
    ) -> Result<()> {
        let usv_state = &mut ctx.accounts.usv_state;
        let qr_account = &mut ctx.accounts.qr_code_account;
        
        require!(!usv_state.is_paused, USVError::ProgramPaused);
        require!(!qr_account.is_claimed, USVError::QRCodeAlreadyClaimed);
        require!(qr_account.code == qr_code, USVError::InvalidQRCode);

        let clock = Clock::get()?;
        
        // Mark QR code as claimed
        qr_account.is_claimed = true;
        qr_account.claimed_at = Some(clock.unix_timestamp);
        qr_account.claimer = Some(ctx.accounts.claimer.key());

        // Transfer 1 token (1 * 10^6 due to 6 decimals) to claimer
        let token_amount = 1_000_000; // 1 token with 6 decimals
        
        let transfer_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.admin_token_account.to_account_info(),
                to: ctx.accounts.claimer_token_account.to_account_info(),
                authority: ctx.accounts.admin.to_account_info(),
            },
        );

        token::transfer(transfer_ctx, token_amount)?;

        // Update state
        usv_state.tokens_claimed += 1;

        msg!("Token claimed successfully!");
        msg!("QR Code: {}", qr_code);
        msg!("Claimer: {}", ctx.accounts.claimer.key());
        msg!("Amount: 1 USV token");
        
        // TODO: Emit event for backend notification
        // This will be implemented when backend endpoint is ready
        if let Some(email) = user_email {
            msg!("User email for notification: {}", email);
        }

        Ok(())
    }

    /// Buy tokens with SOL (for future use)
    pub fn buy_tokens(
        ctx: Context<BuyTokens>,
        sol_amount: u64,
    ) -> Result<()> {
        let usv_state = &ctx.accounts.usv_state;
        
        require!(!usv_state.is_paused, USVError::ProgramPaused);
        require!(sol_amount > 0, USVError::InvalidAmount);

        // Calculate token amount based on price
        // Price: $0.20 per token
        // Assuming 1 SOL = $100 (this should be fetched from oracle in production)
        let sol_price_cents = 10000; // $100 in cents
        let token_price_cents = usv_state.token_price_cents;
        
        let tokens_to_mint = (sol_amount * sol_price_cents) / (token_price_cents * LAMPORTS_PER_SOL);
        
        require!(tokens_to_mint > 0, USVError::InsufficientPayment);

        // Transfer SOL from buyer to admin
        let transfer_ix = anchor_lang::system_program::Transfer {
            from: ctx.accounts.buyer.to_account_info(),
            to: ctx.accounts.admin.to_account_info(),
        };
        
        anchor_lang::system_program::transfer(
            CpiContext::new(
                ctx.accounts.system_program.to_account_info(),
                transfer_ix,
            ),
            sol_amount,
        )?;

        // Transfer tokens to buyer
        let transfer_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.admin_token_account.to_account_info(),
                to: ctx.accounts.buyer_token_account.to_account_info(),
                authority: ctx.accounts.admin.to_account_info(),
            },
        );

        token::transfer(transfer_ctx, tokens_to_mint)?;

        msg!("Tokens purchased successfully!");
        msg!("SOL amount: {} lamports", sol_amount);
        msg!("Tokens received: {} USV", tokens_to_mint / 1_000_000);

        Ok(())
    }

    /// Transfer tokens to partners (airdrop)
    pub fn airdrop_to_partner(
        ctx: Context<AirdropToPartner>,
        amount: u64,
        partner_info: String,
    ) -> Result<()> {
        let usv_state = &ctx.accounts.usv_state;
        
        require!(!usv_state.is_paused, USVError::ProgramPaused);
        require!(amount > 0, USVError::InvalidAmount);

        // Convert amount to token units (multiply by 10^6 for 6 decimals)
        let token_amount = amount * 1_000_000;

        let transfer_ctx = CpiContext::new(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.admin_token_account.to_account_info(),
                to: ctx.accounts.partner_token_account.to_account_info(),
                authority: ctx.accounts.admin.to_account_info(),
            },
        );

        token::transfer(transfer_ctx, token_amount)?;

        msg!("Airdrop completed successfully!");
        msg!("Partner: {}", partner_info);
        msg!("Amount: {} USV tokens", amount);

        Ok(())
    }

    /// Admin function to pause/unpause the program
    pub fn set_pause_state(ctx: Context<SetPauseState>, is_paused: bool) -> Result<()> {
        let usv_state = &mut ctx.accounts.usv_state;
        usv_state.is_paused = is_paused;
        
        msg!("Program pause state changed to: {}", is_paused);
        Ok(())
    }

    /// Admin function to update token price
    pub fn update_token_price(ctx: Context<UpdateTokenPrice>, new_price_cents: u64) -> Result<()> {
        let usv_state = &mut ctx.accounts.usv_state;
        
        require!(new_price_cents > 0, USVError::InvalidAmount);
        
        let old_price = usv_state.token_price_cents;
        usv_state.token_price_cents = new_price_cents;
        
        msg!("Token price updated from {} to {} cents", old_price, new_price_cents);
        Ok(())
    }

    /// Get program statistics
    pub fn get_stats(ctx: Context<GetStats>) -> Result<()> {
        let usv_state = &ctx.accounts.usv_state;
        
        msg!("=== USV Token Statistics ===");
        msg!("Total Supply: {} tokens", usv_state.total_supply);
        msg!("Tokens Claimed: {}", usv_state.tokens_claimed);
        msg!("Total QR Codes Generated: {}", usv_state.total_qr_codes);
        msg!("Token Price: {} cents", usv_state.token_price_cents);
        msg!("Is Paused: {}", usv_state.is_paused);
        msg!("Admin: {}", usv_state.admin);
        
        Ok(())
    }
}