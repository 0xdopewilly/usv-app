use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount, Mint, MintTo, Transfer};

declare_id!("7eS4oJKS4ukfBN2gQAHU9gedkBPPnwxR3paiE1gQPPFA");

#[program]
pub mod usv_token {
    use super::*;

    /// Initialize the USV token program
    pub fn initialize(ctx: Context<Initialize>) -> Result<()> {
        let usv_state = &mut ctx.accounts.usv_state;
        
        // Initialize state
        usv_state.admin = ctx.accounts.admin.key();
        usv_state.mint = ctx.accounts.mint.key();
        usv_state.total_supply = 1_000_000_000 * 1_000_000; // 1B tokens with 6 decimals
        usv_state.tokens_claimed = 0;
        usv_state.total_qr_codes = 0;
        usv_state.token_price_lamports = 4_000_000; // ~$0.20 worth of SOL
        usv_state.is_paused = false;
        usv_state.bump = ctx.bumps.usv_state;

        msg!("USV Token initialized successfully!");
        msg!("Total supply: {} tokens", usv_state.total_supply);
        msg!("Admin: {}", usv_state.admin);
        
        Ok(())
    }

    /// Generate QR codes for claiming
    pub fn generate_qr_codes(
        ctx: Context<GenerateQRCodes>,
        count: u32,
        batch_info: String,
    ) -> Result<()> {
        let usv_state = &mut ctx.accounts.usv_state;
        
        require!(!usv_state.is_paused, USVError::ProgramPaused);
        require!(count > 0 && count <= 100, USVError::InvalidQRCodeCount);

        let clock = Clock::get()?;
        let qr_account = &mut ctx.accounts.qr_code_account;
        
        // Generate simple QR code format
        let qr_code = format!("USV-{}-{}", 
            usv_state.total_qr_codes + 1, 
            clock.unix_timestamp % 1000000
        );
        
        qr_account.code = qr_code.clone();
        qr_account.is_claimed = false;
        qr_account.batch_info = batch_info.clone();
        qr_account.created_at = clock.unix_timestamp;
        qr_account.bump = ctx.bumps.qr_code_account;
        
        usv_state.total_qr_codes += 1;
        
        msg!("Generated QR code: {} for batch: {}", qr_code, batch_info);
        Ok(())
    }

    /// Claim tokens using QR code
    pub fn claim_tokens(
        ctx: Context<ClaimTokens>,
        qr_code: String,
    ) -> Result<()> {
        let usv_state = &mut ctx.accounts.usv_state;
        let qr_account = &mut ctx.accounts.qr_code_account;
        
        require!(!usv_state.is_paused, USVError::ProgramPaused);
        require!(!qr_account.is_claimed, USVError::QRCodeAlreadyClaimed);
        require!(qr_account.code == qr_code, USVError::InvalidQRCode);

        // Mark QR code as claimed
        qr_account.is_claimed = true;
        qr_account.claimed_at = Some(Clock::get()?.unix_timestamp);
        qr_account.claimer = Some(ctx.accounts.claimer.key());

        // Transfer 1 token (1 * 10^6 due to 6 decimals)
        let token_amount = 1_000_000;
        
        let seeds = &[b"usv_state", &[usv_state.bump]];
        let signer = &[&seeds[..]];
        
        let cpi_ctx = CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.admin_token_account.to_account_info(),
                to: ctx.accounts.claimer_token_account.to_account_info(),
                authority: ctx.accounts.usv_state.to_account_info(),
            },
            signer,
        );

        token::transfer(cpi_ctx, token_amount)?;
        usv_state.tokens_claimed += 1;

        msg!("Token claimed! QR: {}, Claimer: {}", qr_code, ctx.accounts.claimer.key());
        Ok(())
    }

    /// Admin function to pause/unpause
    pub fn set_pause_state(ctx: Context<SetPauseState>, is_paused: bool) -> Result<()> {
        let usv_state = &mut ctx.accounts.usv_state;
        usv_state.is_paused = is_paused;
        
        msg!("Program pause state: {}", is_paused);
        Ok(())
    }

    /// Get program statistics
    pub fn get_stats(ctx: Context<GetStats>) -> Result<()> {
        let usv_state = &ctx.accounts.usv_state;
        
        msg!("=== USV Token Stats ===");
        msg!("Total Supply: {}", usv_state.total_supply);
        msg!("Tokens Claimed: {}", usv_state.tokens_claimed);
        msg!("QR Codes Generated: {}", usv_state.total_qr_codes);
        msg!("Is Paused: {}", usv_state.is_paused);
        
        Ok(())
    }
}

// Account structures
#[derive(Accounts)]
pub struct Initialize<'info> {
    #[account(
        init,
        payer = admin,
        space = 8 + USVState::LEN,
        seeds = [b"usv_state"],
        bump
    )]
    pub usv_state: Account<'info, USVState>,
    
    #[account(
        init,
        payer = admin,
        mint::decimals = 6,
        mint::authority = usv_state,
        seeds = [b"mint"],
        bump
    )]
    pub mint: Account<'info, Mint>,
    
    #[account(
        init,
        payer = admin,
        token::mint = mint,
        token::authority = usv_state,
    )]
    pub admin_token_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub admin: Signer<'info>,
    
    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
    pub rent: Sysvar<'info, Rent>,
}

#[derive(Accounts)]
pub struct GenerateQRCodes<'info> {
    #[account(
        mut,
        seeds = [b"usv_state"],
        bump = usv_state.bump,
        has_one = admin
    )]
    pub usv_state: Account<'info, USVState>,
    
    #[account(
        init,
        payer = admin,
        space = 8 + QRCodeAccount::LEN,
        seeds = [b"qr_code", &(usv_state.total_qr_codes + 1).to_le_bytes()],
        bump
    )]
    pub qr_code_account: Account<'info, QRCodeAccount>,
    
    #[account(mut)]
    pub admin: Signer<'info>,
    
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct ClaimTokens<'info> {
    #[account(
        mut,
        seeds = [b"usv_state"],
        bump = usv_state.bump
    )]
    pub usv_state: Account<'info, USVState>,
    
    #[account(
        mut,
        seeds = [b"qr_code", qr_code.as_bytes()],
        bump = qr_code_account.bump
    )]
    pub qr_code_account: Account<'info, QRCodeAccount>,
    
    #[account(
        mut,
        token::mint = usv_state.mint,
        token::authority = usv_state,
    )]
    pub admin_token_account: Account<'info, TokenAccount>,
    
    #[account(
        init_if_needed,
        payer = claimer,
        token::mint = usv_state.mint,
        token::authority = claimer,
    )]
    pub claimer_token_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub claimer: Signer<'info>,
    
    pub token_program: Program<'info, Token>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct SetPauseState<'info> {
    #[account(
        mut,
        seeds = [b"usv_state"],
        bump = usv_state.bump,
        has_one = admin
    )]
    pub usv_state: Account<'info, USVState>,
    
    pub admin: Signer<'info>,
}

#[derive(Accounts)]
pub struct GetStats<'info> {
    #[account(
        seeds = [b"usv_state"],
        bump = usv_state.bump
    )]
    pub usv_state: Account<'info, USVState>,
}

// State structures
#[account]
pub struct USVState {
    pub admin: Pubkey,
    pub mint: Pubkey,
    pub total_supply: u64,
    pub tokens_claimed: u64,
    pub total_qr_codes: u32,
    pub token_price_lamports: u64,
    pub is_paused: bool,
    pub bump: u8,
}

impl USVState {
    pub const LEN: usize = 32 + 32 + 8 + 8 + 4 + 8 + 1 + 1;
}

#[account]
pub struct QRCodeAccount {
    pub code: String,
    pub is_claimed: bool,
    pub batch_info: String,
    pub created_at: i64,
    pub claimed_at: Option<i64>,
    pub claimer: Option<Pubkey>,
    pub bump: u8,
}

impl QRCodeAccount {
    pub const LEN: usize = 4 + 32 + 1 + 4 + 64 + 8 + 1 + 8 + 1 + 32 + 1;
}

// Error types
#[error_code]
pub enum USVError {
    #[msg("Program is paused")]
    ProgramPaused,
    #[msg("Invalid QR code count")]
    InvalidQRCodeCount,
    #[msg("QR code already claimed")]
    QRCodeAlreadyClaimed,
    #[msg("Invalid QR code")]
    InvalidQRCode,
    #[msg("Invalid amount")]
    InvalidAmount,
}