const emailService = require('./utils/emailService');

async function testEmails() {
  console.log('Testing email functionality...');

  // Test partner registration notification
  await emailService.notifyPartnerRegistration({
    companyName: 'Test Company',
    contactPerson: 'John Doe',
    email: 'test@example.com',
    phone: '123456789',
    address: 'Test Address',
    airdropWallet: 'test-wallet'
  });

  console.log('Test emails sent!');
}

testEmails().catch(console.error);
