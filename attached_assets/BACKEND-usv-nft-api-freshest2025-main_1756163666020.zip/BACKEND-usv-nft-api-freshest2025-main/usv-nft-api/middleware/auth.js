const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Основна JWT автентикация
const authenticateToken = async (req, res, next) => {
  try {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'Липсва токен за достъп'
      });
    }

    // Проверка на JWT токена
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // Намиране на потребителя
    const user = await User.findById(decoded.userId).select('-password');
    
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Невалиден токен'
      });
    }

    if (!user.isActive) {
      return res.status(401).json({
        success: false,
        message: 'Акаунтът е деактивиран'
      });
    }

    // Добавяме потребителя към заявката
    req.user = {
      userId: user._id,
      email: user.email,
      userType: user.userType,
      walletAddress: user.walletAddress
    };

    next();
  } catch (error) {
    console.error('Грешка при автентикация:', error);
    
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({
        success: false,
        message: 'Невалиден токен'
      });
    }
    
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({
        success: false,
        message: 'Токенът е изтекъл'
      });
    }

    return res.status(500).json({
      success: false,
      message: 'Грешка при автентикация'
    });
  }
};

// Проверка дали потребителят е партньор
const isPartner = async (req, res, next) => {
  try {
    if (req.user.userType !== 'partner' && req.user.userType !== 'admin') {
      return res.status(403).json({
        success: false,
        message: 'Достъпът е разрешен само за партньори'
      });
    }

    // За партньори проверяваме дали са одобрени
    if (req.user.userType === 'partner') {
      const user = await User.findById(req.user.userId);
      if (!user.partnerInfo.isApproved) {
        return res.status(403).json({
          success: false,
          message: 'Партньорският акаунт не е одобрен'
        });
      }
    }

    next();
  } catch (error) {
    console.error('Грешка при проверка на партньор:', error);
    return res.status(500).json({
      success: false,
      message: 'Грешка при проверка на достъп'
    });
  }
};

// Проверка дали потребителят е админ
const isAdmin = (req, res, next) => {
  if (req.user.userType !== 'admin') {
    return res.status(403).json({
      success: false,
      message: 'Достъпът е разрешен само за администратори'
    });
  }
  next();
};

// Проверка дали потребителят е клиент или по-висше
const isCustomer = (req, res, next) => {
  const allowedTypes = ['customer', 'partner', 'admin'];
  if (!allowedTypes.includes(req.user.userType)) {
    return res.status(403).json({
      success: false,
      message: 'Няmate достъп до този ресурс'
    });
  }
  next();
};

// Опционална автентикация (не връща грешка ако няма токен)
const optionalAuth = async (req, res, next) => {
  try {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
      req.user = null;
      return next();
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.userId).select('-password');
    
    if (user && user.isActive) {
      req.user = {
        userId: user._id,
        email: user.email,
        userType: user.userType,
        walletAddress: user.walletAddress
      };
    } else {
      req.user = null;
    }

    next();
  } catch (error) {
    // При грешка просто продължаваме без потребител
    req.user = null;
    next();
  }
};

// Rate limiting middleware за API заявки
const createRateLimit = (windowMs, max, message) => {
  const requests = new Map();
  
  return (req, res, next) => {
    const identifier = req.user ? req.user.userId : req.ip;
    const now = Date.now();
    const windowStart = now - windowMs;
    
    // Почистване на стари заявки
    for (const [key, timestamps] of requests.entries()) {
      requests.set(key, timestamps.filter(time => time > windowStart));
      if (requests.get(key).length === 0) {
        requests.delete(key);
      }
    }
    
    // Проверка на текущите заявки
    const userRequests = requests.get(identifier) || [];
    
    if (userRequests.length >= max) {
      return res.status(429).json({
        success: false,
        message: message || 'Твърде много заявки. Опитайте отново по-късно.'
      });
    }
    
    // Добавяне на новата заявка
    userRequests.push(now);
    requests.set(identifier, userRequests);
    
    next();
  };
};

module.exports = {
  authenticateToken,
  isPartner,
  isAdmin,
  isCustomer,
  optionalAuth,
  createRateLimit
};
