const mongoose = require('mongoose');

const qrCodeSchema = new mongoose.Schema({
  code: {
    type: String,
    required: true,
    unique: true
  },
  tokenId: {
    type: Number,
    required: true // От 1 до 1,000,000,000
  },
  isUsed: {
    type: Boolean,
    default: false
  },
  strain: {
    type: String,
    required: true // Какъв стрейн е вейпа
  },
  batchNumber: {
    type: String,
    required: true
  },
  manufactureDate: {
    type: Date,
    required: true
  },
  // Къде е продаден вейпа
  soldAt: {
    storeId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Store'
    },
    partnerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    soldDate: Date
  },
  // Кой е клеймнал токена
  claimedBy: {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    walletAddress: String,
    claimedAt: Date,
    location: {
      latitude: Number,
      longitude: Number,
      city: String,
      country: String
    }
  },
  // URL на QR кода
  qrUrl: String,
  qrImageUrl: String,
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Индекс за бързо търсене
qrCodeSchema.index({ code: 1 });
qrCodeSchema.index({ isUsed: 1 });
qrCodeSchema.index({ strain: 1 });

module.exports = mongoose.model('QRCode', qrCodeSchema);