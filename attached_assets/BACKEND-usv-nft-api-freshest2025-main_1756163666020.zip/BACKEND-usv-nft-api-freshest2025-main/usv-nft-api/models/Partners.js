// Add this debug endpoint temporarily to routes/partners.js
router.post('/debug-register', async (req, res) => {
  try {
    console.log('Partner registration debug data:', req.body);
    
    const { email, password, companyName, contactPerson, phone, address, airdropWallet } = req.body;

    // Check what's missing
    const missing = [];
    if (!email) missing.push('email');
    if (!password) missing.push('password');
    if (!companyName) missing.push('companyName');
    if (!contactPerson) missing.push('contactPerson');

    if (missing.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Missing required fields: ' + missing.join(', '),
        receivedData: req.body
      });
    }

    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'User already exists',
        email: email
      });
    }

    // Try to create partner
    const partner = new User({
      email,
      password,
      userType: 'partner',
      partnerInfo: {
        companyName,
        contactPerson,
        phone,
        address,
        airdropWallet,
        isApproved: false
      }
    });

    await partner.save();

    res.status(201).json({
      success: true,
      message: 'Partner created successfully',
      partnerId: partner._id,
      debug: {
        email: partner.email,
        userType: partner.userType,
        companyName: partner.partnerInfo.companyName
      }
    });

  } catch (error) {
    console.error('Partner registration error:', error);
    res.status(500).json({
      success: false,
      message: 'Registration error',
      error: error.message,
      stack: error.stack
    });
  }
});
