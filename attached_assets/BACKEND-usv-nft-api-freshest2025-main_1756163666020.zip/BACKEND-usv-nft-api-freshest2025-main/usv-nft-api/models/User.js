const mongoose = require('mongoose');
const bcrypt = require('bcrypt');

const userSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    validate: {
      validator: function(email) {
        return /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/.test(email);
      },
      message: 'Please enter a valid email'
    }
  },
  password: {
    type: String,
    required: true,
    minlength: 6
  },
  userType: {
    type: String,
    enum: ['customer', 'partner', 'admin'],
    default: 'customer'
  },
  walletAddress: {
    type: String,
    sparse: true // Позволява множество null стойности
  },
  // Информация за партньори
  partnerInfo: {
    companyName: String,
    contactPerson: String,
    phone: String,
    address: {
      street: String,
      city: String,
      state: String,
      country: String,
      zipCode: String
    },
    airdropWallet: String, // Портфейл за получаване на airdrop токени
    isApproved: {
      type: Boolean,
      default: false
    },
    approvedAt: Date,
    approvedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    }
  },
  // Статистики за потребители
  stats: {
    totalTokensClaimed: {
      type: Number,
      default: 0
    },
    qrCodesScanned: {
      type: [{
        code: String,
        scannedAt: Date,
        location: {
          latitude: Number,
          longitude: Number,
          city: String,
          country: String
        }
      }],
      default: []
    },
    lastActive: {
      type: Date,
      default: Date.now
    }
  },
  // Настройки на профила
  profile: {
    firstName: String,
    lastName: String,
    phone: String,
    birthDate: Date,
    preferences: {
      emailNotifications: {
        type: Boolean,
        default: true
      },
      smsNotifications: {
        type: Boolean,
        default: false
      },
      preferredStrains: [String]
    }
  },
  isActive: {
    type: Boolean,
    default: true
  },
  emailVerified: {
    type: Boolean,
    default: false
  },
  emailVerificationToken: String,
  passwordResetToken: String,
  passwordResetExpires: Date,
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Combined pre-save middleware for password hashing and timestamp update
userSchema.pre('save', async function(next) {
  // Update timestamp
  this.updatedAt = Date.now();
  
  // Hash password only if modified
  if (!this.isModified('password')) return next();
  
  try {
    const saltRounds = 12;
    this.password = await bcrypt.hash(this.password, saltRounds);
    next();
  } catch (error) {
    next(error);
  }
});

// Метод за сравняване на парола
userSchema.methods.comparePassword = async function(candidatePassword) {
  try {
    return await bcrypt.compare(candidatePassword, this.password);
  } catch (error) {
    throw error;
  }
};

// Виртуално поле за пълно име
userSchema.virtual('fullName').get(function() {
  if (this.profile && this.profile.firstName && this.profile.lastName) {
    return `${this.profile.firstName} ${this.profile.lastName}`;
  }
  return this.email;
});

// Методи за статистики
userSchema.methods.addQRCodeScan = function(qrCode, location = {}) {
  // Ensure stats object exists
  if (!this.stats) {
    this.stats = { 
      qrCodesScanned: [], 
      totalTokensClaimed: 0,
      lastActive: new Date()
    };
  }
  
  this.stats.qrCodesScanned.push({
    code: qrCode,
    scannedAt: new Date(),
    location
  });
  this.stats.lastActive = new Date();
};

userSchema.methods.incrementTokensClaimed = function() {
  // Ensure stats object exists
  if (!this.stats) {
    this.stats = { 
      qrCodesScanned: [], 
      totalTokensClaimed: 0,
      lastActive: new Date()
    };
  }
  
  this.stats.totalTokensClaimed += 1;
  this.stats.lastActive = new Date();
};

// Configure virtual fields to be included in JSON output
userSchema.set('toJSON', { virtuals: true });
userSchema.set('toObject', { virtuals: true });

// Индекси за производителност
userSchema.index({ email: 1 });
userSchema.index({ userType: 1 });
userSchema.index({ walletAddress: 1 });
userSchema.index({ 'partnerInfo.isApproved': 1 });

module.exports = mongoose.model('User', userSchema);

