const QRCodeModel = require('../models/QRCode');

class QRGenerator {
  constructor() {
    // Base URL for claim links - should point to your frontend
    this.baseUrl = process.env.CLAIM_URL || 'https://your-frontend-app.com/claim';
    this.apiBaseUrl = process.env.API_BASE_URL || 'https://backend-api-y0ke.onrender.com';
  }

  // Generate a simple unique code
  generateUniqueCode() {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substring(2, 8);
    return `USV-${timestamp.toUpperCase()}-${random.toUpperCase()}`;
  }

  // Create claim URL - this should point to your frontend claim page
  createClaimUrl(qrCode) {
    return `${this.baseUrl}/${qrCode}`;
  }

  // Create API verification URL - for backend verification
  createApiUrl(qrCode) {
    return `${this.apiBaseUrl}/api/claim/verify/${qrCode}`;
  }

  // Validate QR code format
  isValidQRFormat(code) {
    const qrPattern = /^USV-[A-Z0-9]+-[A-Z0-9]+$/;
    return qrPattern.test(code);
  }

  // Check if QR code exists
  async qrExists(code) {
    try {
      const existing = await QRCodeModel.findOne({ code });
      return !!existing;
    } catch (error) {
      console.error('Error checking QR existence:', error);
      return false;
    }
  }

  // Generate unique code that doesn't exist in database
  async generateUniqueValidCode() {
    let attempts = 0;
    let code;
    
    do {
      code = this.generateUniqueCode();
      attempts++;
      
      if (attempts > 10) {
        throw new Error('Failed to generate unique QR code after 10 attempts');
      }
    } while (await this.qrExists(code));
    
    return code;
  }

  // Create a single QR code
  async createSingle(strain, batchNumber, partnerId = null, storeId = null) {
    try {
      console.log('Creating QR code with params:', { strain, batchNumber, partnerId, storeId });
      
      // Generate unique code
      const qrCode = await this.generateUniqueValidCode();
      const claimUrl = this.createClaimUrl(qrCode);
      const apiUrl = this.createApiUrl(qrCode);

      // Get next token ID
      try {
        const lastQR = await QRCodeModel.findOne({}, { tokenId: 1 }).sort({ tokenId: -1 });
        const tokenId = lastQR ? lastQR.tokenId + 1 : 1;

        // Create QR record
        const qrRecord = new QRCodeModel({
          code: qrCode,
          tokenId: tokenId,
          strain: strain || 'Unknown',
          batchNumber: batchNumber || `BATCH-${new Date().getFullYear()}-${String(Date.now()).slice(-3)}`,
          manufactureDate: new Date(),
          qrUrl: claimUrl,
          apiUrl: apiUrl,
          isUsed: false,
          claimedAt: null,
          claimedBy: null,
          soldAt: partnerId || storeId ? {
            partnerId: partnerId,
            storeId: storeId,
            soldDate: new Date()
          } : null
        });

        await qrRecord.save();
        
        console.log('QR code created successfully:', qrCode);

        return {
          success: true,
          qrCode: {
            id: qrRecord._id,
            code: qrRecord.code,
            tokenId: qrRecord.tokenId,
            strain: qrRecord.strain,
            batchNumber: qrRecord.batchNumber,
            claimUrl: qrRecord.qrUrl,
            apiUrl: qrRecord.apiUrl,
            createdAt: qrRecord.createdAt
          }
        };
        
      } catch (dbError) {
        console.error('Database error:', dbError);
        return {
          success: false,
          error: `Database error: ${dbError.message}`
        };
      }
      
    } catch (error) {
      console.error('Error creating QR code:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  // Create multiple QR codes
  async createBatch(count, strain, batchNumber, partnerId = null, storeId = null) {
    try {
      console.log(`Creating batch of ${count} QR codes...`);
      
      // Validate inputs
      const batchCount = parseInt(count) || 1;
      if (batchCount < 1) {
        return {
          success: false,
          error: 'Batch count must be at least 1'
        };
      }
      
      if (batchCount > 1000) {
        return {
          success: false,
          error: 'Maximum batch size is 1000 QR codes'
        };
      }
      
      const results = [];
      const batchId = `BATCH-${Date.now()}`;
      
      for (let i = 0; i < batchCount; i++) {
        const currentBatchNumber = batchNumber || `${batchId}-${String(i + 1).padStart(3, '0')}`;
        const result = await this.createSingle(strain, currentBatchNumber, partnerId, storeId);
        results.push(result);
        
        // Add small delay every 10 codes to avoid overwhelming the database
        if (i > 0 && i % 10 === 0) {
          await new Promise(resolve => setTimeout(resolve, 100));
        }
      }
      
      const successful = results.filter(r => r.success);
      const failed = results.filter(r => !r.success);
      
      console.log(`Batch complete: ${successful.length} successful, ${failed.length} failed`);
      
      return {
        success: true,
        batchId: batchId,
        total: batchCount,
        successful: successful.length,
        failed: failed.length,
        qrCodes: successful.map(r => r.qrCode),
        errors: failed.map(r => r.error)
      };
      
    } catch (error) {
      console.error('Error creating QR batch:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  // Get QR code details
  async getQRDetails(code) {
    try {
      if (!this.isValidQRFormat(code)) {
        return {
          success: false,
          error: 'Invalid QR code format'
        };
      }

      const qrRecord = await QRCodeModel.findOne({ code });
      
      if (!qrRecord) {
        return {
          success: false,
          error: 'QR code not found'
        };
      }

      return {
        success: true,
        qrCode: {
          code: qrRecord.code,
          tokenId: qrRecord.tokenId,
          strain: qrRecord.strain,
          batchNumber: qrRecord.batchNumber,
          isUsed: qrRecord.isUsed,
          claimedAt: qrRecord.claimedAt,
          claimedBy: qrRecord.claimedBy,
          manufactureDate: qrRecord.manufactureDate,
          soldAt: qrRecord.soldAt
        }
      };
    } catch (error) {
      console.error('Error getting QR details:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  // Get statistics
  async getStats() {
    try {
      const total = await QRCodeModel.countDocuments();
      const used = await QRCodeModel.countDocuments({ isUsed: true });
      const unused = total - used;
      
      // Get stats by strain
      const strainStats = await QRCodeModel.aggregate([
        {
          $group: {
            _id: '$strain',
            total: { $sum: 1 },
            used: { $sum: { $cond: ['$isUsed', 1, 0] } }
          }
        }
      ]);

      // Get recent activity
      const recentClaims = await QRCodeModel.find({ isUsed: true })
        .sort({ claimedAt: -1 })
        .limit(10)
        .select('code strain claimedAt claimedBy');
      
      return {
        success: true,
        overall: {
          total: total,
          used: used,
          unused: unused,
          usageRate: total > 0 ? ((used / total) * 100).toFixed(2) + '%' : '0%'
        },
        byStrain: strainStats,
        recentActivity: recentClaims
      };
    } catch (error) {
      console.error('Error getting QR stats:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  // Validate and mark QR as used
  async claimQR(code, walletAddress) {
    try {
      if (!this.isValidQRFormat(code)) {
        return {
          success: false,
          error: 'Invalid QR code format'
        };
      }

      const qrRecord = await QRCodeModel.findOne({ code });
      
      if (!qrRecord) {
        return {
          success: false,
          error: 'QR code not found'
        };
      }

      if (qrRecord.isUsed) {
        return {
          success: false,
          error: 'QR code already claimed',
          claimedAt: qrRecord.claimedAt,
          claimedBy: qrRecord.claimedBy
        };
      }

      // Mark as used
      qrRecord.isUsed = true;
      qrRecord.claimedAt = new Date();
      qrRecord.claimedBy = walletAddress;
      
      await qrRecord.save();

      return {
        success: true,
        message: 'QR code claimed successfully',
        qrCode: {
          code: qrRecord.code,
          tokenId: qrRecord.tokenId,
          strain: qrRecord.strain,
          claimedAt: qrRecord.claimedAt
        }
      };

    } catch (error) {
      console.error('Error claiming QR:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }
}

module.exports = new QRGenerator();
