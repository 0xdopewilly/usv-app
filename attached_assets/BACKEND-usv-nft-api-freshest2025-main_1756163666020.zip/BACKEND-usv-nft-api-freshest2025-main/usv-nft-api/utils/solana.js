const { 
  Connection, 
  PublicKey, 
  Keypair, 
  Transaction, 
  sendAndConfirmTransaction,
  SystemProgram
} = require('@solana/web3.js');
const { 
  Token, 
  TOKEN_PROGRAM_ID, 
  ASSOCIATED_TOKEN_PROGRAM_ID,
  u64
} = require('@solana/spl-token');
// Try multiple ways to import bs58
let bs58;
try {
  bs58 = require('bs58');
} catch (err) {
  console.error('bs58 import error:', err);
}

class SolanaService {
  constructor() {
    // Използваме devnet за тестване
    this.connection = new Connection(
      process.env.SOLANA_RPC_URL || 'https://api.devnet.solana.com',
      'confirmed'
    );
    
    // Зареждаме главния портфейл от .env
    const privateKey = process.env.WALLET_PRIVATE_KEY;
    if (!privateKey) {
      console.warn('WALLET_PRIVATE_KEY not found in environment variables');
      // Create a temporary keypair for development
      this.wallet = Keypair.generate();
    } else {
      try {
        // Try different bs58 decode methods
        let secretKey;
        if (bs58 && typeof bs58.decode === 'function') {
          secretKey = bs58.decode(privateKey);
        } else if (bs58 && typeof bs58 === 'function') {
          secretKey = bs58(privateKey);
        } else {
          // Fallback: try to decode manually or use a different approach
          console.warn('bs58.decode not available, using fallback');
          this.wallet = Keypair.generate();
          return;
        }
        this.wallet = Keypair.fromSecretKey(secretKey);
      } catch (error) {
        console.warn('Error decoding private key:', error.message);
        this.wallet = Keypair.generate();
      }
    }
    
    // USV token mint адрес
    const tokenMint = process.env.USV_TOKEN_MINT;
    if (!tokenMint) {
      console.warn('USV_TOKEN_MINT not found in environment variables');
      // Use a placeholder for development
      this.tokenMintAddress = new PublicKey('11111111111111111111111111111111');
    } else {
      this.tokenMintAddress = new PublicKey(tokenMint);
    }
    
    // Общо количество токени (1 милиард)
    this.TOTAL_SUPPLY = 1000000000;
  }

  // Изпращане на USV токен към потребител
  async sendUSVToken(recipientWalletAddress, amount = 1) {
    try {
      console.log(`Изпращане на ${amount} USV токен към ${recipientWalletAddress}`);
      
      const recipientPublicKey = new PublicKey(recipientWalletAddress);
      
      // Намираме или създаваме токен акаунт за получателя
      const recipientTokenAccount = await Token.getAssociatedTokenAddress(
        ASSOCIATED_TOKEN_PROGRAM_ID,
        TOKEN_PROGRAM_ID,
        this.tokenMintAddress,
        recipientPublicKey
      );

      // Токен акаунт на изпращача
      const senderTokenAccount = await Token.getAssociatedTokenAddress(
        ASSOCIATED_TOKEN_PROGRAM_ID,
        TOKEN_PROGRAM_ID,
        this.tokenMintAddress,
        this.wallet.publicKey
      );

      // Създаваме токен инстанция
      const token = new Token(
        this.connection,
        this.tokenMintAddress,
        TOKEN_PROGRAM_ID,
        this.wallet
      );

      // Проверяваме дали получателят има токен акаунт
      const recipientAccountInfo = await this.connection.getAccountInfo(recipientTokenAccount);
      
      let transaction = new Transaction();
      
      if (!recipientAccountInfo) {
        // Създаваме токен акаунт за получателя
        console.log('Създаване на токен акаунт за получателя...');
        transaction.add(
          Token.createAssociatedTokenAccountInstruction(
            ASSOCIATED_TOKEN_PROGRAM_ID,
            TOKEN_PROGRAM_ID,
            this.tokenMintAddress,
            recipientTokenAccount,
            recipientPublicKey,
            this.wallet.publicKey
          )
        );
      }

      // Добавяме трансфер инструкция
      transaction.add(
        Token.createTransferInstruction(
          TOKEN_PROGRAM_ID,
          senderTokenAccount,
          recipientTokenAccount,
          this.wallet.publicKey,
          [],
          amount * Math.pow(10, 9) // Конвертираме в най-малката единица
        )
      );

      // Изпращаме транзакцията
      const signature = await sendAndConfirmTransaction(
        this.connection,
        transaction,
        [this.wallet]
      );

      console.log(`Успешна транзакция: ${signature}`);

      return {
        success: true,
        signature,
        message: `Успешно изпратени ${amount} USV токен(а)`,
        explorerUrl: `https://explorer.solana.com/tx/${signature}?cluster=devnet`
      };
    } catch (error) {
      console.error('Грешка при изпращане на USV токен:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  // Airdrop за партньори
  async airdropToPartner(partnerWalletAddress, amount) {
    try {
      console.log(`Airdrop на ${amount} USV токена към партньор ${partnerWalletAddress}`);
      
      // Използваме същата функция но с по-голямо количество
      return await this.sendUSVToken(partnerWalletAddress, amount);
    } catch (error) {
      console.error('Грешка при airdrop:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  // Проверка на баланс
  async checkWalletBalance(walletAddress) {
    try {
      const publicKey = new PublicKey(walletAddress);
      const tokenAccount = await Token.getAssociatedTokenAddress(
        ASSOCIATED_TOKEN_PROGRAM_ID,
        TOKEN_PROGRAM_ID,
        this.tokenMintAddress,
        publicKey
      );

      const balance = await this.connection.getTokenAccountBalance(tokenAccount);
      return {
        success: true,
        balance: balance.value.uiAmount || 0,
        rawBalance: balance.value.amount
      };
    } catch (error) {
      console.error('Грешка при проверка на баланс:', error);
      return {
        success: true,
        balance: 0,
        rawBalance: '0'
      };
    }
  }

  // Създаване на liquidity pool (за по-късно)
  async createLiquidityPool(pairedTokenMint, initialUSVAmount, initialPairedAmount) {
    // TODO: Имплементация за създаване на liquidity pool
    // Това ще използва Raydium или Orca протокол
    console.log('Liquidity pool функционалността ще бъде добавена');
  }

  // Вземане на текуща цена от liquidity pool
  async getCurrentPrice() {
    // TODO: Връзка с DEX за текуща цена
    // За момента връщаме фиксирана цена
    return {
      success: true,
      price: 0.20, // $0.20 за токен
      currency: 'USD'
    };
  }
}

module.exports = new SolanaService();