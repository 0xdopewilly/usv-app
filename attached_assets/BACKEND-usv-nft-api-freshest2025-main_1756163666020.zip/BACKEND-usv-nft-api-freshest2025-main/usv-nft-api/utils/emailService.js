const nodemailer = require('nodemailer');

class EmailService {
  constructor() {
    this.transporter = nodemailer.createTransporter({
      host: process.env.EMAIL_HOST,
      port: parseInt(process.env.EMAIL_PORT) || 587,
      secure: process.env.EMAIL_PORT === '465', // true for 465, false for other ports
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
      }
    });
  }

  // Send partner registration notification to admin
  async notifyPartnerRegistration(partnerData) {
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: process.env.ADMIN_EMAIL, // Your email address
      subject: 'New Partner Registration - USV NFT',
      html: `
        <h2>New Partner Registration</h2>
        <p><strong>Company:</strong> ${partnerData.companyName}</p>
        <p><strong>Contact Person:</strong> ${partnerData.contactPerson}</p>
        <p><strong>Email:</strong> ${partnerData.email}</p>
        <p><strong>Phone:</strong> ${partnerData.phone}</p>
        <p><strong>Address:</strong> ${partnerData.address}</p>
        <p><strong>Airdrop Wallet:</strong> ${partnerData.airdropWallet}</p>
        <p><strong>Registration Time:</strong> ${new Date().toLocaleString()}</p>
        
        <p>Please review and approve this partner in your admin panel.</p>
      `
    };

    try {
      await this.transporter.sendMail(mailOptions);
      console.log('Partner registration notification sent');
    } catch (error) {
      console.error('Error sending partner notification:', error);
    }
  }

  // Send welcome email to new partner
  async sendPartnerWelcome(partnerEmail, partnerName) {
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: partnerEmail,
      subject: 'Welcome to USV NFT Partnership Program',
      html: `
        <h2>Welcome to USV NFT!</h2>
        <p>Dear ${partnerName},</p>
        <p>Thank you for registering as a partner with USV NFT.</p>
        <p>Your application is currently under review. We'll notify you once it's approved.</p>
        <p>Best regards,<br>USV NFT Team</p>
      `
    };

    try {
      await this.transporter.sendMail(mailOptions);
      console.log('Welcome email sent to partner');
    } catch (error) {
      console.error('Error sending welcome email:', error);
    }
  }

  // Send QR claim notification
  async notifyQRClaim(qrData, userWallet) {
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: process.env.ADMIN_EMAIL,
      subject: 'QR Code Claimed - USV NFT',
      html: `
        <h2>QR Code Claimed</h2>
        <p><strong>QR Code:</strong> ${qrData.code}</p>
        <p><strong>Token ID:</strong> ${qrData.tokenId}</p>
        <p><strong>Strain:</strong> ${qrData.strain}</p>
        <p><strong>Batch:</strong> ${qrData.batchNumber}</p>
        <p><strong>Claimed by Wallet:</strong> ${userWallet}</p>
        <p><strong>Claim Time:</strong> ${new Date().toLocaleString()}</p>
      `
    };

    try {
      await this.transporter.sendMail(mailOptions);
      console.log('QR claim notification sent');
    } catch (error) {
      console.error('Error sending QR claim notification:', error);
    }
  }
}

module.exports = new EmailService();
