const axios = require('axios');

// Change this to your actual backend URL
const API_URL = process.env.API_URL || 'https://backend-api-y0ke.onrender.com';

// Test data
const testData = {
  // User registration
  registerUser: {
    email: `test${Date.now()}@example.com`,
    password: 'password123',
    userType: 'customer'
  },
  
  // Partner registration
  registerPartner: {
    email: `partner${Date.now()}@example.com`,
    password: 'password123',
    companyName: 'Test Company',
    contactPerson: 'John Doe',
    phone: '+1234567890',
    address: '123 Test Street',
    airdropWallet: 'wallet123'
  },
  
  // Login
  login: {
    email: 'test@example.com',
    password: 'password123'
  },
  
  // QR Generation
  generateQR: {
    count: 5,
    strain: 'Blue Dream',
    batchNumber: 'BATCH-TEST-001',
    partnerId: null,
    storeId: null
  },
  
  // Claim
  claim: {
    qrCode: 'USV-TEST-123',
    walletAddress: 'wallet123',
    location: {
      latitude: 42.6977,
      longitude: 23.3219,
      city: 'Sofia',
      country: 'Bulgaria'
    }
  }
};

// Helper function to make requests
async function testEndpoint(method, endpoint, data = null, token = null) {
  try {
    console.log(`\n📍 Testing ${method} ${endpoint}`);
    console.log('📤 Request data:', JSON.stringify(data, null, 2));
    
    const config = {
      method,
      url: `${API_URL}${endpoint}`,
      headers: {
        'Content-Type': 'application/json',
        ...(token && { 'Authorization': `Bearer ${token}` })
      },
      ...(data && { data })
    };
    
    const response = await axios(config);
    console.log('✅ Success:', response.status);
    console.log('📥 Response:', JSON.stringify(response.data, null, 2));
    return response.data;
  } catch (error) {
    console.error('❌ Error:', error.response?.status || error.code);
    console.error('📥 Error response:', error.response?.data || error.message);
    return null;
  }
}

// Run tests
async function runTests() {
  console.log('🚀 Starting POST endpoint tests...');
  console.log(`🌐 Testing against: ${API_URL}`);
  
  // Test health check first
  await testEndpoint('GET', '/health');
  
  // Test user registration
  const registerResult = await testEndpoint('POST', '/api/auth/register', testData.registerUser);
  
  // Test login
  const loginResult = await testEndpoint('POST', '/api/auth/login', {
    email: testData.registerUser.email,
    password: testData.registerUser.password
  });
  
  const token = loginResult?.token;
  
  // Test partner registration
  await testEndpoint('POST', '/api/partners/register', testData.registerPartner);
  
  // Test QR generation (requires admin auth)
  await testEndpoint('POST', '/api/admin/generate-qr-codes', testData.generateQR);
  
  // Test debug endpoint
  await testEndpoint('POST', '/api/admin/debug-generate-qr-codes', testData.generateQR);
  
  // Test claim
  await testEndpoint('POST', '/api/claim/claim', testData.claim, token);
  
  console.log('\n✅ All tests completed!');
}

// Check if axios is installed
try {
  require.resolve('axios');
  runTests();
} catch (e) {
  console.log('Please install axios first: npm install axios');
}