const express = require('express');
const router = express.Router();
const QRCode = require('../models/QRCode');
const User = require('../models/User');
const solanaService = require('../utils/solana');
const { authenticateToken } = require('../middleware/auth');

// Verify QR code (NEW endpoint that was missing)
router.get('/verify/:code', async (req, res) => {
  try {
    const { code } = req.params;
    
    console.log(`Verifying QR code: ${code}`);
    
    // Find QR code in database
    const qrRecord = await QRCode.findOne({ code })
      .populate('soldAt.storeId')
      .populate('soldAt.partnerId', 'partnerInfo.companyName');
    
    if (!qrRecord) {
      return res.status(404).json({
        success: false,
        message: 'Невалиден QR код'
      });
    }
    
    // Return verification info
    res.json({
      success: true,
      valid: true,
      qrCode: {
        code: qrRecord.code,
        strain: qrRecord.strain,
        tokenId: qrRecord.tokenId,
        batchNumber: qrRecord.batchNumber,
        isUsed: qrRecord.isUsed,
        claimedAt: qrRecord.claimedBy?.claimedAt || null,
        claimedBy: qrRecord.claimedBy?.walletAddress || null,
        store: qrRecord.soldAt?.storeId || null,
        partner: qrRecord.soldAt?.partnerId || null
      }
    });
  } catch (error) {
    console.error('Грешка при проверка на QR код:', error);
    res.status(500).json({
      success: false,
      message: 'Грешка при проверка на QR код',
      error: error.message
    });
  }
});

// Check QR code (existing endpoint - keep for compatibility)
router.get('/check/:qrCode', async (req, res) => {
  try {
    const { qrCode } = req.params;
    
    // Find QR code in database
    const qrRecord = await QRCode.findOne({ code: qrCode })
      .populate('soldAt.storeId')
      .populate('soldAt.partnerId', 'partnerInfo.companyName');
    
    if (!qrRecord) {
      return res.status(404).json({
        success: false,
        message: 'Невалиден QR код'
      });
    }
    
    if (qrRecord.isUsed) {
      return res.status(400).json({
        success: false,
        message: 'Този QR код вече е използван',
        claimedAt: qrRecord.claimedBy?.claimedAt,
        strain: qrRecord.strain
      });
    }
    
    return res.json({
      success: true,
      message: 'QR кодът е валиден и готов за клеймване',
      data: {
        strain: qrRecord.strain,
        tokenId: qrRecord.tokenId,
        batchNumber: qrRecord.batchNumber,
        store: qrRecord.soldAt?.storeId,
        partner: qrRecord.soldAt?.partnerId
      }
    });
  } catch (error) {
    console.error('Грешка при проверка на QR код:', error);
    return res.status(500).json({
      success: false,
      message: 'Сървърна грешка',
      error: error.message
    });
  }
});

// Claim tokens using QR code (NEW RESTful endpoint)
router.post('/:code', async (req, res) => {
  try {
    const { code } = req.params;
    const { walletAddress, location } = req.body;

    console.log(`Attempting to claim QR code: ${code} for wallet: ${walletAddress}`);

    // Validate wallet address
    if (!walletAddress) {
      return res.status(400).json({
        success: false,
        message: 'Wallet address е задължителен'
      });
    }

    // Find QR code
    const qrRecord = await QRCode.findOne({ code });
    
    if (!qrRecord) {
      return res.status(404).json({
        success: false,
        message: 'Невалиден QR код'
      });
    }
    
    if (qrRecord.isUsed) {
      return res.status(400).json({
        success: false,
        message: 'Този QR код вече е използван',
        claimedAt: qrRecord.claimedBy?.claimedAt,
        claimedBy: qrRecord.claimedBy?.walletAddress
      });
    }

    // Try to send USV tokens
    try {
      console.log(`Sending 1 USV token to ${walletAddress}`);
      
      const transferResult = await solanaService.sendUSVToken(walletAddress, 1);
      
      if (!transferResult.success) {
        return res.status(500).json({
          success: false,
          message: 'Неуспешно изпращане на токен',
          error: transferResult.error
        });
      }

      // Mark QR as used
      qrRecord.isUsed = true;
      qrRecord.claimedBy = {
        walletAddress,
        claimedAt: new Date(),
        location: location || {}
      };

      // Update user stats if authenticated
      if (req.user) {
        qrRecord.claimedBy.userId = req.user.userId;
        
        await User.findByIdAndUpdate(req.user.userId, {
          $inc: { 'stats.totalTokensClaimed': 1 },
          $push: {
            'stats.qrCodesScanned': {
              code: code,
              scannedAt: new Date(),
              location: location || {}
            }
          }
        });
      }

      await qrRecord.save();

      // Get new balance
      const balanceResult = await solanaService.checkWalletBalance(walletAddress);

      res.json({
        success: true,
        message: 'QR код е успешно използван и токените са изпратени',
        qrCode: {
          code: qrRecord.code,
          strain: qrRecord.strain,
          tokenId: qrRecord.tokenId,
          claimedAt: qrRecord.claimedBy.claimedAt
        },
        transaction: transferResult.signature,
        explorerUrl: transferResult.explorerUrl,
        newBalance: balanceResult?.balance || 'Unknown'
      });

    } catch (solanaError) {
      console.error('Solana service error:', solanaError);
      res.status(500).json({
        success: false,
        message: 'Solana услугата е недостъпна',
        error: 'Solana service unavailable'
      });
    }

  } catch (error) {
    console.error('Error claiming QR code:', error);
    res.status(500).json({
      success: false,
      message: 'Грешка при използване на QR код',
      error: error.message
    });
  }
});

// Original claim endpoint (keep for compatibility)
router.post('/claim', async (req, res) => {
  try {
    const { qrCode, walletAddress, location } = req.body;
    
    // Validation
    if (!qrCode || !walletAddress) {
      return res.status(400).json({
        success: false,
        message: 'QR код и адрес на портфейл са задължителни'
      });
    }
    
    // Find QR code
    const qrRecord = await QRCode.findOne({ code: qrCode });
    
    if (!qrRecord) {
      return res.status(404).json({
        success: false,
        message: 'Невалиден QR код'
      });
    }
    
    if (qrRecord.isUsed) {
      return res.status(400).json({
        success: false,
        message: 'Този QR код вече е използван',
        claimedAt: qrRecord.claimedBy?.claimedAt
      });
    }
    
    // Send USV token to user's wallet
    try {
      console.log(`Изпращане на 1 USV токен към ${walletAddress}`);
      
      const transferResult = await solanaService.sendUSVToken(walletAddress, 1);
      
      if (!transferResult.success) {
        return res.status(500).json({
          success: false,
          message: 'Неуспешно изпращане на токен',
          error: transferResult.error
        });
      }
      
      // Mark QR as used
      qrRecord.isUsed = true;
      qrRecord.claimedBy = {
        walletAddress,
        claimedAt: new Date(),
        location: location || {}
      };
      
      // Update user stats if authenticated
      if (req.user) {
        qrRecord.claimedBy.userId = req.user.userId;
        
        await User.findByIdAndUpdate(req.user.userId, {
          $inc: { 'stats.totalTokensClaimed': 1 },
          $push: {
            'stats.qrCodesScanned': {
              code: qrCode,
              scannedAt: new Date(),
              location: location || {}
            }
          }
        });
      }
      
      await qrRecord.save();
      
      // Get new balance
      const balanceResult = await solanaService.checkWalletBalance(walletAddress);
      
      return res.json({
        success: true,
        message: 'Успешно клеймнахте 1 USV токен!',
        data: {
          transaction: transferResult.signature,
          explorerUrl: transferResult.explorerUrl,
          newBalance: balanceResult?.balance || 'Unknown',
          strain: qrRecord.strain,
          tokenId: qrRecord.tokenId
        }
      });
    } catch (solanaError) {
      console.error('Грешка при изпращане на USV токен:', solanaError);
      return res.status(500).json({
        success: false,
        message: 'Solana услугата е недостъпна',
        error: solanaError.message
      });
    }
  } catch (error) {
    console.error('Грешка при клеймване на токен:', error);
    return res.status(500).json({
      success: false,
      message: 'Сървърна грешка',
      error: error.message
    });
  }
});

// Get wallet balance
router.get('/balance/:walletAddress', async (req, res) => {
  try {
    const { walletAddress } = req.params;
    
    try {
      const balanceResult = await solanaService.checkWalletBalance(walletAddress);
      const priceResult = await solanaService.getCurrentPrice?.() || { price: 0, currency: 'USD' };
      
      return res.json({
        success: true,
        data: {
          walletAddress,
          balance: balanceResult?.balance || 0,
          price: priceResult.price,
          currency: priceResult.currency,
          totalValue: (balanceResult?.balance || 0) * priceResult.price
        }
      });
    } catch (solanaError) {
      console.error('Solana balance check failed:', solanaError);
      res.json({
        success: false,
        message: 'Не можем да проверим баланса в момента',
        error: 'Solana service unavailable'
      });
    }
  } catch (error) {
    console.error('Грешка при проверка на баланс:', error);
    return res.status(500).json({
      success: false,
      message: 'Сървърна грешка',
      error: error.message
    });
  }
});

// Get claim history for authenticated user
router.get('/history', authenticateToken, async (req, res) => {
  try {
    const userId = req.user.userId;
    
    const claimedQRCodes = await QRCode.find({
      'claimedBy.userId': userId
    }).sort({ 'claimedBy.claimedAt': -1 });
    
    return res.json({
      success: true,
      count: claimedQRCodes.length,
      data: claimedQRCodes.map(qr => ({
        code: qr.code,
        strain: qr.strain,
        tokenId: qr.tokenId,
        claimedAt: qr.claimedBy.claimedAt,
        batchNumber: qr.batchNumber
      }))
    });
  } catch (error) {
    console.error('Error getting claim history:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Грешка при зареждане на история',
      error: error.message
    });
  }
});

// Get claim history for a specific wallet
router.get('/history/:walletAddress', async (req, res) => {
  try {
    const { walletAddress } = req.params;
    
    const claims = await QRCode.find({ 
      'claimedBy.walletAddress': walletAddress,
      isUsed: true
    }).sort({ 'claimedBy.claimedAt': -1 });

    res.json({
      success: true,
      count: claims.length,
      claims: claims.map(claim => ({
        code: claim.code,
        strain: claim.strain,
        claimedAt: claim.claimedBy.claimedAt,
        tokenId: claim.tokenId,
        batchNumber: claim.batchNumber
      }))
    });
  } catch (error) {
    console.error('Error getting claim history:', error);
    res.status(500).json({
      success: false,
      message: 'Грешка при зареждане на история',
      error: error.message
    });
  }
});


const emailService = require('../utils/emailService');

// In your claim route
router.post('/claim/:code', async (req, res) => {
  try {
    const { code } = req.params;
    const { walletAddress } = req.body;

    // Your existing claim logic here...
    const qrRecord = await QRCodeModel.findOne({ code });
    
    if (qrRecord && !qrRecord.isUsed) {
      // Mark as claimed
      qrRecord.isUsed = true;
      qrRecord.claimedBy = walletAddress;
      qrRecord.claimedAt = new Date();
      await qrRecord.save();

      // Send notification email
      await emailService.notifyQRClaim(qrRecord, walletAddress);

      res.json({
        success: true,
        message: 'Token claimed successfully'
      });
    }
  } catch (error) {
    console.error('Claim error:', error);
    res.status(500).json({
      success: false,
      message: 'Claim failed'
    });
  }
});




module.exports = router;
