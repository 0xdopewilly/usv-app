const express = require('express');
const router = express.Router();
const qrGenerator = require('../utils/qrGenerator');
const { authenticateToken, isAdmin } = require('../middleware/auth');

// Get QR statistics
router.get('/stats', async (req, res) => {
  try {
    const stats = await qrGenerator.getStats();
    res.json(stats);
  } catch (error) {
    console.error('Error getting QR stats:', error);
    res.status(500).json({
      success: false,
      message: 'Грешка при зареждане на статистика',
      error: error.message
    });
  }
});

// Generate single QR code
router.post('/generate', authenticateToken, async (req, res) => {
  try {
    const { strain, batchNumber, partnerId, storeId } = req.body;

    // Validate required fields
    if (!strain) {
      return res.status(400).json({
        success: false,
        message: 'Strain е задължително поле'
      });
    }

    const result = await qrGenerator.createSingle(
      strain,
      batchNumber,
      partnerId,
      storeId
    );

    if (result.success) {
      res.status(201).json(result);
    } else {
      res.status(500).json(result);
    }
  } catch (error) {
    console.error('Error generating QR code:', error);
    res.status(500).json({
      success: false,
      message: 'Грешка при генериране на QR код',
      error: error.message
    });
  }
});

// Generate batch of QR codes
router.post('/generate-batch', authenticateToken, async (req, res) => {
  try {
    const { count, strain, batchNumber, partnerId, storeId } = req.body;

    // Validate required fields
    if (!count || !strain) {
      return res.status(400).json({
        success: false,
        message: 'Count и strain са задължителни полета'
      });
    }

    // Validate count
    const batchCount = parseInt(count);
    if (isNaN(batchCount) || batchCount < 1 || batchCount > 1000) {
      return res.status(400).json({
        success: false,
        message: 'Count трябва да бъде число между 1 и 1000'
      });
    }

    const result = await qrGenerator.createBatch(
      batchCount,
      strain,
      batchNumber,
      partnerId,
      storeId
    );

    if (result.success) {
      res.status(201).json(result);
    } else {
      res.status(500).json(result);
    }
  } catch (error) {
    console.error('Error generating QR batch:', error);
    res.status(500).json({
      success: false,
      message: 'Грешка при генериране на QR кодове',
      error: error.message
    });
  }
});

// Get QR code details
router.get('/details/:code', async (req, res) => {
  try {
    const { code } = req.params;
    
    const result = await qrGenerator.getQRDetails(code);
    
    if (result.success) {
      res.json(result);
    } else {
      res.status(404).json(result);
    }
  } catch (error) {
    console.error('Error getting QR details:', error);
    res.status(500).json({
      success: false,
      message: 'Грешка при зареждане на QR детайли',
      error: error.message
    });
  }
});

// Admin: Get all QR codes
router.get('/all', authenticateToken, isAdmin, async (req, res) => {
  try {
    const { page = 1, limit = 50, strain, isUsed } = req.query;
    
    // Build filter
    const filter = {};
    if (strain) filter.strain = strain;
    if (isUsed !== undefined) filter.isUsed = isUsed === 'true';

    const QRCode = require('../models/QRCode');
    
    const qrCodes = await QRCode.find(filter)
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .sort({ createdAt: -1 });

    const total = await QRCode.countDocuments(filter);

    res.json({
      success: true,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit),
      qrCodes
    });
  } catch (error) {
    console.error('Error getting all QR codes:', error);
    res.status(500).json({
      success: false,
      message: 'Грешка при зареждане на QR кодове',
      error: error.message
    });
  }
});

module.exports = router;