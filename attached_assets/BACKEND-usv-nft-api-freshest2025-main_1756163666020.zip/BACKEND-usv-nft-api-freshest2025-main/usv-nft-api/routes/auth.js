const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { authenticateToken } = require('../middleware/auth');

// Регистрация на нов потребител
router.post('/register', async (req, res) => {
  try {
    const { email, password, userType, walletAddress, partnerInfo } = req.body;

    // Проверка дали потребителят вече съществува
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'Потребител с този имейл вече съществува'
      });
    }

    // Създаване на нов потребител
    const user = new User({
      email,
      password,
      userType: userType || 'customer',
      walletAddress,
      partnerInfo: userType === 'partner' ? partnerInfo : undefined
    });

    await user.save();

    // Създаване на JWT токен
    const token = jwt.sign(
      { 
        userId: user._id, 
        email: user.email, 
        userType: user.userType 
      },
      process.env.JWT_SECRET,
      { expiresIn: '30d' }
    );

    res.status(201).json({
      success: true,
      message: 'Успешна регистрация',
      token,
      user: {
        id: user._id,
        email: user.email,
        userType: user.userType,
        walletAddress: user.walletAddress
      }
    });
  } catch (error) {
    console.error('Грешка при регистрация:', error);
    res.status(500).json({
      success: false,
      message: 'Грешка при регистрация'
    });
  }
});

// Вход в системата
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Намиране на потребителя
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({
        success: false,
        message: 'Невалиден имейл или парола'
      });
    }

    // Проверка на паролата
    const isPasswordValid = await user.comparePassword(password);
    if (!isPasswordValid) {
      return res.status(400).json({
        success: false,
        message: 'Невалиден имейл или парола'
      });
    }

    // Създаване на JWT токен
    const token = jwt.sign(
      { 
        userId: user._id, 
        email: user.email, 
        userType: user.userType 
      },
      process.env.JWT_SECRET,
      { expiresIn: '30d' }
    );

    res.json({
      success: true,
      message: 'Успешен вход',
      token,
      user: {
        id: user._id,
        email: user.email,
        userType: user.userType,
        walletAddress: user.walletAddress,
        stats: user.stats
      }
    });
  } catch (error) {
    console.error('Грешка при вход:', error);
    res.status(500).json({
      success: false,
      message: 'Грешка при вход'
    });
  }
});

// Свързване на портфейл
router.post('/connect-wallet', authenticateToken, async (req, res) => {
  try {
    const { walletAddress } = req.body;
    const userId = req.user.userId;

    // Актуализиране на портфейл адреса
    const user = await User.findByIdAndUpdate(
      userId,
      { walletAddress },
      { new: true }
    );

    res.json({
      success: true,
      message: 'Портфейлът е успешно свързан',
      walletAddress: user.walletAddress
    });
  } catch (error) {
    console.error('Грешка при свързване на портфейл:', error);
    res.status(500).json({
      success: false,
      message: 'Грешка при свързване на портфейл'
    });
  }
});

// Вземане на профил информация
router.get('/profile', authenticateToken, async (req, res) => {
  try {
    const user = await User.findById(req.user.userId).select('-password');
    
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'Потребителят не е намерен'
      });
    }

    res.json({
      success: true,
      user
    });
  } catch (error) {
    console.error('Грешка при вземане на профил:', error);
    res.status(500).json({
      success: false,
      message: 'Грешка при вземане на профил'
    });
  }
});

module.exports = router;