const express = require('express');
const router = express.Router();
const User = require('../models/User');
const emailService = require('../utils/emailService');
const Store = require('../models/Store');
const QRCode = require('../models/QRCode');
const solanaService = require('../utils/solana');
const { authenticateToken, isPartner, isAdmin } = require('../middleware/auth');

// Debug endpoint for partner registration (temporary)
router.post('/debug-register', async (req, res) => {
  try {
    const { email, password, companyName, contactPerson, phone, address, airdropWallet } = req.body;

    console.log('Debug registration request:', { email, companyName, address });

    // Check if partner already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'Партньор с този имейл вече съществува'
      });
    }

    // Create partner with proper address structure
    const partner = new User({
      email,
      password,
      userType: 'partner',
      partnerInfo: {
        companyName,
        contactPerson,
        phone,
        address: {
          street: address,
          city: '',
          state: '',
          zipCode: '',
          country: ''
        }, // Convert string to object structure
        airdropWallet,
        isApproved: true // Auto-approve for debug
      }
    });

    await partner.save();



 // Send emails
    await emailService.notifyPartnerRegistration({
      companyName,
      contactPerson,
      email,
      phone,
      address,
      airdropWallet
    });

    await emailService.sendPartnerWelcome(email, contactPerson);



    res.status(201).json({
      success: true,
      message: 'Debug партньор е създаден успешно.',
      partnerId: partner._id
    });
  } catch (error) {
    console.error('Грешка при debug регистрация на партньор:', error);
    res.status(500).json({
      success: false,
      message: 'Грешка при регистрация',
      error: error.message
    });
  }
});

// Regular partner registration
router.post('/register', async (req, res) => {
  try {
    const { email, password, companyName, contactPerson, phone, address, airdropWallet } = req.body;

    // Validate required fields
    if (!email || !password || !companyName || !contactPerson || !phone || !address || !airdropWallet) {
      return res.status(400).json({
        success: false,
        message: 'Всички полета са задължителни'
      });
    }

    // Check if partner already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'Партньор с този имейл вече съществува'
      });
    }

    // Handle address - if it's a string, convert to object
    let addressObj = address;
    if (typeof address === 'string') {
      addressObj = {
        street: address,
        city: '',
        state: '',
        zipCode: '',
        country: ''
      };
    }

    // Create partner
    const partner = new User({
      email,
      password,
      userType: 'partner',
      partnerInfo: {
        companyName,
        contactPerson,
        phone,
        address: addressObj,
        airdropWallet,
        isApproved: false // Requires admin approval
      }
    });

    await partner.save();

    res.status(201).json({
      success: true,
      message: 'Заявката за партньорство е изпратена. Очаквайте одобрение.',
      partnerId: partner._id
    });
  } catch (error) {
    console.error('Грешка при регистрация на партньор:', error);
    res.status(500).json({
      success: false,
      message: 'Грешка при регистрация',
      error: error.message
    });
  }
});

// Airdrop tokens to partner
router.post('/airdrop', authenticateToken, isAdmin, async (req, res) => {
  try {
    const { partnerId, amount } = req.body;

    // Validate input
    if (!partnerId || !amount) {
      return res.status(400).json({
        success: false,
        message: 'partnerId и amount са задължителни'
      });
    }

    // Find partner
    const partner = await User.findById(partnerId);
    if (!partner || partner.userType !== 'partner') {
      return res.status(404).json({
        success: false,
        message: 'Партньорът не е намерен'
      });
    }

    if (!partner.partnerInfo.airdropWallet) {
      return res.status(400).json({
        success: false,
        message: 'Партньорът няма зададен портфейл за airdrop'
      });
    }

    // Send tokens
    try {
      const result = await solanaService.airdropToPartner(
        partner.partnerInfo.airdropWallet,
        amount
      );

      if (!result.success) {
        return res.status(500).json({
          success: false,
          message: 'Неуспешен airdrop',
          error: result.error
        });
      }

      res.json({
        success: true,
        message: `Успешно изпратени ${amount} USV токена на ${partner.partnerInfo.companyName}`,
        transaction: result.signature,
        explorerUrl: result.explorerUrl
      });
    } catch (solanaError) {
      console.error('Solana service error:', solanaError);
      res.status(500).json({
        success: false,
        message: 'Грешка при изпращане на токени - Solana service недостъпен',
        error: solanaError.message
      });
    }
  } catch (error) {
    console.error('Грешка при airdrop:', error);
    res.status(500).json({
      success: false,
      message: 'Грешка при изпращане на токени',
      error: error.message
    });
  }
});

// Add store
router.post('/stores', authenticateToken, isPartner, async (req, res) => {
  try {
    const { name, address, coordinates, phone, email, workingHours, inventory } = req.body;
    const partnerId = req.user.userId;

    // Validate required fields
    if (!name || !address) {
      return res.status(400).json({
        success: false,
        message: 'Име и адрес на магазина са задължителни'
      });
    }

    // Validate coordinates if provided
    if (coordinates && (!Array.isArray(coordinates) || coordinates.length !== 2)) {
      return res.status(400).json({
        success: false,
        message: 'Координатите трябва да бъдат масив от 2 числа [longitude, latitude]'
      });
    }

    const store = new Store({
      partnerId,
      name,
      address,
      location: coordinates ? {
        type: 'Point',
        coordinates: coordinates // [longitude, latitude]
      } : undefined,
      contact: {
        phone: phone || '',
        email: email || '',
        workingHours: workingHours || {}
      },
      inventory: inventory || []
    });

    await store.save();

    res.status(201).json({
      success: true,
      message: 'Магазинът е успешно добавен',
      store
    });
  } catch (error) {
    console.error('Грешка при добавяне на магазин:', error);
    res.status(500).json({
      success: false,
      message: 'Грешка при добавяне на магазин',
      error: error.message
    });
  }
});

// Update store inventory
router.put('/stores/:storeId/inventory', authenticateToken, isPartner, async (req, res) => {
  try {
    const { storeId } = req.params;
    const { inventory } = req.body;
    const partnerId = req.user.userId;

    // Validate input
    if (!inventory || !Array.isArray(inventory)) {
      return res.status(400).json({
        success: false,
        message: 'Инвентарът трябва да бъде масив'
      });
    }

    // Check if store belongs to partner
    const store = await Store.findOne({ _id: storeId, partnerId });
    if (!store) {
      return res.status(404).json({
        success: false,
        message: 'Магазинът не е намерен'
      });
    }

    // Update inventory
    store.inventory = inventory.map(item => ({
      ...item,
      lastUpdated: new Date()
    }));
    await store.save();

    res.json({
      success: true,
      message: 'Инвентарът е актуализиран',
      inventory: store.inventory
    });
  } catch (error) {
    console.error('Грешка при актуализиране на инвентар:', error);
    res.status(500).json({
      success: false,
      message: 'Грешка при актуализиране',
      error: error.message
    });
  }
});

// Get all partner stores
router.get('/stores', authenticateToken, isPartner, async (req, res) => {
  try {
    const partnerId = req.user.userId;
    
    const stores = await Store.find({ partnerId });
    
    res.json({
      success: true,
      count: stores.length,
      stores
    });
  } catch (error) {
    console.error('Грешка при вземане на магазини:', error);
    res.status(500).json({
      success: false,
      message: 'Грешка при зареждане на магазини',
      error: error.message
    });
  }
});

// Get partner statistics
router.get('/stats', authenticateToken, isPartner, async (req, res) => {
  try {
    const partnerId = req.user.userId;
    
    // Find all partner stores
    const stores = await Store.find({ partnerId });
    const storeIds = stores.map(s => s._id);
    
    // Find all sold vapes
    const soldVapes = await QRCode.countDocuments({
      'soldAt.partnerId': partnerId
    });
    
    // Find all claimed tokens from their vapes
    const claimedTokens = await QRCode.countDocuments({
      'soldAt.partnerId': partnerId,
      isUsed: true
    });
    
    // Inventory by strains
    const inventoryByStrain = {};
    stores.forEach(store => {
      if (store.inventory && Array.isArray(store.inventory)) {
        store.inventory.forEach(item => {
          if (item.strain) {
            if (!inventoryByStrain[item.strain]) {
              inventoryByStrain[item.strain] = 0;
            }
            inventoryByStrain[item.strain] += item.quantity || 0;
          }
        });
      }
    });
    
    res.json({
      success: true,
      stats: {
        totalStores: stores.length,
        totalSoldVapes: soldVapes,
        totalClaimedTokens: claimedTokens,
        claimRate: soldVapes > 0 ? (claimedTokens / soldVapes * 100).toFixed(2) + '%' : '0%',
        inventoryByStrain
      }
    });
  } catch (error) {
    console.error('Грешка при вземане на статистика:', error);
    res.status(500).json({
      success: false,
      message: 'Грешка при зареждане на статистика',
      error: error.message
    });
  }
});

// Approve partner (admin only)
router.put('/approve/:partnerId', authenticateToken, isAdmin, async (req, res) => {
  try {
    const { partnerId } = req.params;
    
    const partner = await User.findByIdAndUpdate(
      partnerId,
      { 'partnerInfo.isApproved': true },
      { new: true }
    );
    
    if (!partner) {
      return res.status(404).json({
        success: false,
        message: 'Партньорът не е намерен'
      });
    }
    
    res.json({
      success: true,
      message: 'Партньорът е одобрен',
      partner: {
        id: partner._id,
        companyName: partner.partnerInfo.companyName,
        isApproved: partner.partnerInfo.isApproved
      }
    });
  } catch (error) {
    console.error('Грешка при одобряване:', error);
    res.status(500).json({
      success: false,
      message: 'Грешка при одобряване',
      error: error.message
    });
  }
});

// Get all partners (admin only)
router.get('/all', authenticateToken, isAdmin, async (req, res) => {
  try {
    const partners = await User.find(
      { userType: 'partner' },
      {
        password: 0, // Exclude password
        __v: 0
      }
    );
    
    res.json({
      success: true,
      count: partners.length,
      partners
    });
  } catch (error) {
    console.error('Грешка при вземане на партньори:', error);
    res.status(500).json({
      success: false,
      message: 'Грешка при зареждане на партньори',
      error: error.message
    });
  }
});

// Get partner profile
router.get('/profile', authenticateToken, isPartner, async (req, res) => {
  try {
    const partnerId = req.user.userId;
    
    const partner = await User.findById(partnerId, {
      password: 0, // Exclude password
      __v: 0
    });
    
    if (!partner) {
      return res.status(404).json({
        success: false,
        message: 'Партньорът не е намерен'
      });
    }
    
    res.json({
      success: true,
      partner
    });
  } catch (error) {
    console.error('Грешка при вземане на профил:', error);
    res.status(500).json({
      success: false,
      message: 'Грешка при зареждане на профил',
      error: error.message
    });
  }
});

module.exports = router;
