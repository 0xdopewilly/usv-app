const express = require('express');
const router = express.Router();
const Store = require('../models/Store');
const QRCode = require('../models/QRCode');

// Вземане на всички активни магазини
router.get('/', async (req, res) => {
  try {
    const { strain, city, limit = 50 } = req.query;
    
    // Създаване на филтър
    const filter = { isActive: true };
    
    if (strain) {
      filter['inventory.strain'] = strain;
      filter['inventory.quantity'] = { $gt: 0 };
    }
    
    if (city) {
      filter['address.city'] = new RegExp(city, 'i');
    }
    
    const stores = await Store.find(filter)
      .populate('partnerId', 'partnerInfo.companyName')
      .limit(parseInt(limit));
    
    res.json({
      success: true,
      count: stores.length,
      stores: stores.map(store => ({
        id: store._id,
        name: store.name,
        address: store.address,
        location: store.location,
        contact: store.contact,
        partner: store.partnerId?.partnerInfo?.companyName,
        inventory: store.inventory.filter(item => item.quantity > 0)
      }))
    });
  } catch (error) {
    console.error('Грешка при вземане на магазини:', error);
    res.status(500).json({
      success: false,
      message: 'Грешка при зареждане на магазини'
    });
  }
});

// Намиране на близки магазини
router.post('/nearby', async (req, res) => {
  try {
    const { latitude, longitude, maxDistance = 10000, strain } = req.body;
    
    if (!latitude || !longitude) {
      return res.status(400).json({
        success: false,
        message: 'Координатите са задължителни'
      });
    }
    
    // Създаване на географски филтър
    const query = {
      isActive: true,
      location: {
        $near: {
          $geometry: {
            type: 'Point',
            coordinates: [longitude, latitude]
          },
          $maxDistance: maxDistance // в метри
        }
      }
    };
    
    if (strain) {
      query['inventory.strain'] = strain;
      query['inventory.quantity'] = { $gt: 0 };
    }
    
    const stores = await Store.find(query)
      .populate('partnerId', 'partnerInfo.companyName')
      .limit(20);
    
    res.json({
      success: true,
      count: stores.length,
      stores: stores.map(store => ({
        id: store._id,
        name: store.name,
        address: store.address,
        distance: calculateDistance(latitude, longitude, 
          store.location.coordinates[1], store.location.coordinates[0]),
        contact: store.contact,
        inventory: store.inventory.filter(item => 
          (!strain || item.strain === strain) && item.quantity > 0
        )
      }))
    });
  } catch (error) {
    console.error('Грешка при намиране на близки магазини:', error);
    res.status(500).json({
      success: false,
      message: 'Грешка при търсене'
    });
  }
});

// Вземане на статистика по стрейнове
router.get('/strains', async (req, res) => {
  try {
    const stores = await Store.find({ isActive: true });
    
    const strainStats = {};
    let totalQuantity = 0;
    
    stores.forEach(store => {
      store.inventory.forEach(item => {
        if (!strainStats[item.strain]) {
          strainStats[item.strain] = {
            strain: item.strain,
            totalQuantity: 0,
            storeCount: 0,
            stores: []
          };
        }
        
        strainStats[item.strain].totalQuantity += item.quantity;
        strainStats[item.strain].storeCount += 1;
        strainStats[item.strain].stores.push({
          storeId: store._id,
          storeName: store.name,
          quantity: item.quantity
        });
        
        totalQuantity += item.quantity;
      });
    });
    
    res.json({
      success: true,
      totalQuantity,
      strains: Object.values(strainStats)
    });
  } catch (error) {
    console.error('Грешка при вземане на стрейнове:', error);
    res.status(500).json({
      success: false,
      message: 'Грешка при зареждане на данни'
    });
  }
});

// Детайли за магазин
router.get('/:storeId', async (req, res) => {
  try {
    const { storeId } = req.params;
    
    const store = await Store.findById(storeId)
      .populate('partnerId', 'partnerInfo.companyName partnerInfo.phone');
    
    if (!store) {
      return res.status(404).json({
        success: false,
        message: 'Магазинът не е намерен'
      });
    }
    
    // Вземане на статистика за продажби
    const salesStats = await QRCode.aggregate([
      {
        $match: {
          'soldAt.storeId': store._id
        }
      },
      {
        $group: {
          _id: '$strain',
          totalSold: { $sum: 1 },
          totalClaimed: {
            $sum: { $cond: ['$isUsed', 1, 0] }
          }
        }
      }
    ]);
    
    res.json({
      success: true,
      store: {
        id: store._id,
        name: store.name,
        address: store.address,
        location: store.location,
        contact: store.contact,
        partner: {
          name: store.partnerId?.partnerInfo?.companyName,
          phone: store.partnerId?.partnerInfo?.phone
        },
        inventory: store.inventory,
        salesStats
      }
    });
  } catch (error) {
    console.error('Грешка при вземане на детайли:', error);
    res.status(500).json({
      success: false,
      message: 'Грешка при зареждане на магазин'
    });
  }
});

// Помощна функция за изчисляване на разстояние
function calculateDistance(lat1, lon1, lat2, lon2) {
  const R = 6371; // Радиус на Земята в километри
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  const distance = R * c;
  return Math.round(distance * 1000); // Връщаме в метри
}

module.exports = router;