const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const rateLimit = require('express-rate-limit');

// Load environment variables first
dotenv.config();

// Import routes
const authRoutes = require('./routes/auth');
const claimRoutes = require('./routes/claim');
const partnerRoutes = require('./routes/partners');
const storeRoutes = require('./routes/stores');

// Create Express app
const app = express();

// Trust proxy setting for rate limiting
app.set('trust proxy', 1);

// CRITICAL: Body parser middleware MUST come before routes
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Enhanced CORS configuration
const corsOptions = {
  origin: function (origin, callback) {
    const allowedOrigins = [
      process.env.WEBSITE_URL,
      process.env.APP_URL,
      'http://localhost:3000',
      'http://localhost:3001',
      'http://localhost:5173', // Vite default
      'http://localhost:5174'
    ].filter(Boolean); // Remove undefined values

    // Allow requests with no origin (like mobile apps or curl)
    if (!origin) return callback(null, true);
    
    if (allowedOrigins.indexOf(origin) !== -1) {
      callback(null, true);
    } else {
      console.log('CORS blocked origin:', origin);
      callback(null, true); // For development, allow all origins
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  exposedHeaders: ['X-RateLimit-Limit', 'X-RateLimit-Remaining', 'X-RateLimit-Reset'],
  maxAge: 86400 // 24 hours
};

app.use(cors(corsOptions));

// Add request logging middleware
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
  if (req.method === 'POST' || req.method === 'PUT') {
    console.log('Request body:', JSON.stringify(req.body, null, 2));
  }
  next();
});

// MongoDB connection
mongoose.set('strictQuery', false);
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/usv-nft', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('✅ Connected to MongoDB'))
.catch(err => {
  console.error('❌ MongoDB connection error:', err);
  process.exit(1);
});

// Rate limiting with better configuration
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100,
  message: {
    success: false,
    message: 'Too many requests from this IP, please try again later.'
  },
  standardHeaders: true,
  legacyHeaders: false,
  // Skip rate limiting for development
  skip: (req) => process.env.NODE_ENV === 'development',
  handler: (req, res) => {
    res.status(429).json({
      success: false,
      message: 'Too many requests, please try again later.',
      retryAfter: req.rateLimit.resetTime
    });
  }
});

const claimLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 5,
  message: {
    success: false,
    message: 'Too many claim attempts. Please try again later.'
  },
  skip: (req) => process.env.NODE_ENV === 'development'
});

// Apply rate limiting
app.use('/api/', limiter);
app.use('/api/claim/claim', claimLimiter);
app.use('/api/claim/:code', claimLimiter);

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development',
    mongodb: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected'
  });
});

// API Routes - Make sure these are after body parser
app.use('/api/qr', require('./routes/qr'));
app.use('/api/auth', authRoutes);
app.use('/api/claim', claimRoutes);
app.use('/api/partners', partnerRoutes);
app.use('/api/stores', storeRoutes);

// Admin endpoints
app.post('/api/admin/generate-qr-codes', async (req, res) => {
  try {
    console.log('Admin QR generation request:', req.body);
    
    const { count, strain, batchNumber, partnerId, storeId } = req.body;
    
    if (!count || count <= 0 || count > 1000) {
      return res.status(400).json({
        success: false,
        message: 'Count must be between 1 and 1000'
      });
    }
    
    const qrGenerator = require('./utils/qrGenerator');
    const result = await qrGenerator.createBatch(count, strain, batchNumber, partnerId, storeId);
    
    res.json(result);
  } catch (error) {
    console.error('Error generating QR codes:', error);
    res.status(500).json({
      success: false,
      message: 'Error generating QR codes',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// Debug endpoint
app.post('/api/admin/debug-generate-qr-codes', async (req, res) => {
  try {
    console.log('QR generation debug data:', req.body);
    
    const { count, strain, batchNumber, partnerId, storeId } = req.body;
    
    const debug = {
      count,
      strain,
      batchNumber,
      partnerId,
      storeId,
      nodeEnv: process.env.NODE_ENV,
      hasClaimUrl: !!process.env.CLAIM_URL,
      requestHeaders: req.headers,
      requestMethod: req.method,
      bodyReceived: !!req.body,
      bodyKeys: Object.keys(req.body || {})
    };

    try {
      const qrGenerator = require('./utils/qrGenerator');
      debug.qrGeneratorLoaded = true;
      
      if (count && strain) {
        const testResult = await qrGenerator.createSingle(
          strain,
          batchNumber || 'DEBUG-001',
          partnerId || null,
          storeId || null
        );
        
        debug.testGenerationResult = testResult.success;
        if (testResult.success) {
          debug.generatedQRCode = testResult.qrCode.code;
        } else {
          debug.generationError = testResult.error;
        }
      }
    } catch (error) {
      debug.qrGeneratorError = error.message;
    }

    res.json({
      success: true,
      message: 'Debug complete',
      debug
    });
  } catch (error) {
    console.error('Debug error:', error);
    res.status(500).json({
      success: false,
      message: 'Debug error',
      error: error.message
    });
  }
});

// Root endpoint
app.get('/', (req, res) => {
  res.json({
    success: true,
    message: 'USV NFT API is running',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

// Global error handler
app.use((err, req, res, next) => {
  console.error('Global error:', err);
  
  // Handle body parser errors
  if (err.type === 'entity.too.large') {
    return res.status(413).json({
      success: false,
      message: 'Request body too large'
    });
  }
  
  if (err instanceof SyntaxError && err.status === 400 && 'body' in err) {
    return res.status(400).json({
      success: false,
      message: 'Invalid JSON in request body'
    });
  }
  
  res.status(500).json({
    success: false,
    message: 'Something went wrong',
    error: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: 'Endpoint not found',
    path: req.path,
    method: req.method
  });
});

// Start server
const PORT = process.env.PORT || 3000;
const server = app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`📍 API URL: http://localhost:${PORT}`);
  console.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`🔌 CORS enabled for:`, corsOptions.origin);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received. Closing server...');
  server.close(() => {
    console.log('Server closed');
    mongoose.connection.close(() => {
      console.log('MongoDB connection closed');
      process.exit(0);
    });
  });
});

module.exports = app;
