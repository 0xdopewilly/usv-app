const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const rateLimit = require('express-rate-limit');

// Load environment variables first
dotenv.config();

// Импортиране на routes
const authRoutes = require('./routes/auth');
const claimRoutes = require('./routes/claim');
const partnerRoutes = require('./routes/partners');
const storeRoutes = require('./routes/stores');

// Създаване на Express приложение
const app = express();

// FIXED: Add trust proxy setting for rate limiting
app.set('trust proxy', 1);

// Middleware за CORS
app.use(cors({
  origin: [
    process.env.WEBSITE_URL,
    process.env.APP_URL,
    'http://localhost:3000',
    'http://localhost:3001'
  ],
  credentials: true
}));

// Body parser middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));



// Add this to your server.js file BEFORE setting up rate limiting

// Trust proxy for production (Render deployment)
if (process.env.NODE_ENV === 'production') {
  app.set('trust proxy', 1);
}




// FIXED: Better rate limiting configuration
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: {
    success: false,
    message: 'Too many requests from this IP, please try again later.'
  },
  standardHeaders: true, // Return rate limit info in the `RateLimit-*` headers
  legacyHeaders: false, // Disable the `X-RateLimit-*` headers
});

const claimLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 5, // maximum 5 claims per hour
  message: {
    success: false,
    message: 'Твърде много опити за клеймване. Опитайте отново по-късно.'
  }
});

// Apply rate limiting
app.use('/api/', limiter);
app.use('/api/claim/claim', claimLimiter);

// FIXED: Single MongoDB connection
mongoose.set('strictQuery', false);
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/usv-nft', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('✅ Успешна връзка с MongoDB'))
.catch(err => console.error('❌ MongoDB грешка:', err));

// API Routes
app.use('/api/qr', require('./routes/qr'));
app.use('/api/auth', authRoutes);
app.use('/api/claim', claimRoutes);
app.use('/api/partners', partnerRoutes);
app.use('/api/stores', storeRoutes);

// FIXED: Admin QR generation endpoint with authentication check
app.post('/api/admin/generate-qr-codes', async (req, res) => {
  try {
    const { count, strain, batchNumber, partnerId, storeId } = req.body;
    
    // Basic validation
    if (!count || count <= 0 || count > 1000) {
      return res.status(400).json({
        success: false,
        message: 'Count must be between 1 and 1000'
      });
    }
    
    // TODO: Add admin authentication check here when ready
    // const { authenticateToken, isAdmin } = require('./middleware/auth');
    
    const qrGenerator = require('./utils/qrGenerator');
    const result = await qrGenerator.createBatch(count, strain, batchNumber, partnerId, storeId);
    
    res.json(result);
  } catch (error) {
    console.error('Грешка при генериране на QR кодове:', error);
    res.status(500).json({
      success: false,
      message: 'Грешка при генериране',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// Debug endpoint for QR generation
app.post('/api/admin/debug-generate-qr-codes', async (req, res) => {
  try {
    console.log('QR generation debug data:', req.body);
    
    const { count, strain, batchNumber, partnerId, storeId } = req.body;
    
    const debug = {
      count: count,
      strain: strain,
      batchNumber: batchNumber,
      partnerId: partnerId,
      storeId: storeId,
      nodeEnv: process.env.NODE_ENV,
      hasClaimUrl: !!process.env.CLAIM_URL
    };

    // Check if qrGenerator exists and can be loaded
    try {
      const qrGenerator = require('./utils/qrGenerator');
      debug.qrGeneratorLoaded = true;
      debug.qrGeneratorType = typeof qrGenerator;
      
      debug.hasMethods = {
        createSingle: typeof qrGenerator.createSingle === 'function',
        createBatch: typeof qrGenerator.createBatch === 'function'
      };
      
    } catch (error) {
      debug.qrGeneratorError = error.message;
      debug.qrGeneratorLoaded = false;
    }

    // Check if QRCode model exists
    try {
      const QRCode = require('./models/QRCode');
      debug.qrCodeModelLoaded = true;
    } catch (error) {
      debug.qrCodeModelError = error.message;
      debug.qrCodeModelLoaded = false;
    }

    // Try to generate a single QR code
    if (debug.qrGeneratorLoaded) {
      try {
        const qrGenerator = require('./utils/qrGenerator');
        
        const testResult = await qrGenerator.createSingle(
          strain || 'Debug Strain',
          batchNumber || 'DEBUG-001',
          partnerId || null,
          storeId || null
        );
        
        debug.testGenerationResult = testResult.success;
        if (testResult.success) {
          debug.generatedQRCode = testResult.qrCode.code;
        } else {
          debug.generationError = testResult.error;
        }
        
      } catch (error) {
        debug.generationException = error.message;
      }
    }

    res.json({
      success: true,
      message: 'QR Generation Debug Complete',
      debug: debug
    });

  } catch (error) {
    console.error('QR generation debug error:', error);
    res.status(500).json({
      success: false,
      message: 'Debug endpoint error',
      error: error.message
    });
  }
});

// ADDED: Debug endpoint for partner registration
app.post('/api/partners/debug-register', async (req, res) => {
  try {
    console.log('Partner registration debug data:', req.body);
    
    const { email, password, companyName, contactPerson, phone, address, airdropWallet } = req.body;

    const debug = {
      receivedData: req.body,
      hasUserModel: false,
      userModelError: null
    };

    // Check what's missing
    const missing = [];
    if (!email) missing.push('email');
    if (!password) missing.push('password');
    if (!companyName) missing.push('companyName');
    if (!contactPerson) missing.push('contactPerson');

    debug.missingFields = missing;

    if (missing.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Missing required fields: ' + missing.join(', '),
        debug: debug
      });
    }

    // Check if User model exists
    try {
      const User = require('./models/User');
      debug.hasUserModel = true;
      
      // Check if user already exists
      const existingUser = await User.findOne({ email });
      debug.userExists = !!existingUser;
      
      if (existingUser) {
        return res.status(400).json({
          success: false,
          message: 'User already exists',
          debug: debug
        });
      }

      // Try to create partner
      const partner = new User({
        email,
        password,
        userType: 'partner',
        partnerInfo: {
          companyName,
          contactPerson,
          phone,
          address,
          airdropWallet,
          isApproved: false
        }
      });

      await partner.save();
      debug.partnerCreated = true;

      res.status(201).json({
        success: true,
        message: 'Partner created successfully in debug mode',
        partnerId: partner._id,
        debug: debug
      });

    } catch (error) {
      debug.userModelError = error.message;
      console.error('User model error:', error);
      
      res.status(500).json({
        success: false,
        message: 'User model error',
        debug: debug,
        error: error.message
      });
    }

  } catch (error) {
    console.error('Partner registration debug error:', error);
    res.status(500).json({
      success: false,
      message: 'Debug error',
      error: error.message
    });
  }
});

// Add this to your server.js
app.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development'
  });
});


// Health check endpoint
app.get('/', (req, res) => {
  res.json({
    success: true,
    message: 'USV NFT API работи успешно',
    version: '1.0.0',
    timestamp: new Date().toISOString(),
    endpoints: {
      auth: {
        register: 'POST /api/auth/register',
        login: 'POST /api/auth/login',
        profile: 'GET /api/auth/profile',
        connectWallet: 'POST /api/auth/connect-wallet'
      },
      claim: {
        check: 'GET /api/claim/check/:qrCode',
        claim: 'POST /api/claim/claim',
        balance: 'GET /api/claim/balance/:walletAddress',
        history: 'GET /api/claim/history'
      },
      partners: {
        register: 'POST /api/partners/register',
        debugRegister: 'POST /api/partners/debug-register',
        stores: 'GET /api/partners/stores',
        addStore: 'POST /api/partners/stores',
        stats: 'GET /api/partners/stats'
      },
      stores: {
        all: 'GET /api/stores',
        nearby: 'POST /api/stores/nearby',
        strains: 'GET /api/stores/strains',
        details: 'GET /api/stores/:storeId'
      },
      admin: {
        generateQR: 'POST /api/admin/generate-qr-codes',
        debugQR: 'POST /api/admin/debug-generate-qr-codes'
      }
    }
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Global error handler:', err);
  
  // Rate limit error
  if (err.code === 'ERR_ERL_UNEXPECTED_X_FORWARDED_FOR') {
    return res.status(500).json({
      success: false,
      message: 'Rate limiting configuration error'
    });
  }
  
  res.status(500).json({
    success: false,
    message: 'Нещо се обърка! Моля опитайте отново.',
    error: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: 'Този endpoint не съществува',
    path: req.path,
    method: req.method
  });
});

// Стартиране на сървъра
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Сървърът работи на порт ${PORT}`);
  console.log(`📍 API URL: http://localhost:${PORT}`);
  
  if (process.env.NODE_ENV === 'production') {
    console.log('🔒 Работи в production режим');
  } else {
    console.log('🔧 Работи в development режим');
  }
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM получен. Затваряне на сървъра...');
  mongoose.connection.close(() => {
    console.log('MongoDB връзката е затворена.');
    process.exit(0);
  });
});

module.exports = app;
