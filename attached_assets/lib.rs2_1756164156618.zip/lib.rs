use anchor_lang::prelude::*;
use anchor_spl::token::{self, Token, TokenAccount, Mint, MintTo, Transfer};
use anchor_spl::associated_token::AssociatedToken;

declare_id!("5ANErUU8reBAF9p4LmbxKd5tEupeUwVkh9iazB6ucGSY");

#[program]
pub mod usv_token {
    use super::*;

    /// Initialize the USV token program
    pub fn initialize(ctx: Context<Initialize>) -> Result<()> {
        // First, do all the CPI operations before mutably borrowing usv_state
        let seeds = &[b"usv_state".as_ref(), &[ctx.bumps.usv_state]];
        let signer = &[&seeds[..]];
        
        let total_supply = 1_000_000_000 * 1_000_000; // 1B tokens with 6 decimals
        
        let mint_ctx = CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            MintTo {
                mint: ctx.accounts.mint.to_account_info(),
                to: ctx.accounts.admin_token_account.to_account_info(),
                authority: ctx.accounts.usv_state.to_account_info(),
            },
            signer,
        );

        token::mint_to(mint_ctx, total_supply)?;

        // Now initialize the state after CPI operations
        let usv_state = &mut ctx.accounts.usv_state;
        usv_state.admin = ctx.accounts.admin.key();
        usv_state.mint = ctx.accounts.mint.key();
        usv_state.total_supply = total_supply;
        usv_state.tokens_claimed = 0;
        usv_state.total_qr_codes = 0;
        usv_state.token_price_cents = 20;
        usv_state.is_paused = false;
        usv_state.bump = ctx.bumps.usv_state;

        msg!("🚀 USV Token initialized!");
        msg!("📊 Supply: {} tokens", total_supply);
        msg!("🏦 Mint: {}", usv_state.mint);
        
        Ok(())
    }

    /// Generate QR codes
    pub fn generate_qr_codes(
        ctx: Context<GenerateQRCodes>,
        count: u32,
        partner_id: Option<String>,
        batch_info: String,
    ) -> Result<()> {
        let usv_state = &mut ctx.accounts.usv_state;
        require!(!usv_state.is_paused, USVError::ProgramPaused);
        require!(count > 0 && count <= 1000, USVError::InvalidQRCodeCount);

        let clock = Clock::get()?;
        let qr_account = &mut ctx.accounts.qr_code_account;
        
        let qr_code = format!("USV-{:06}-{}", 
            usv_state.total_qr_codes + 1, 
            clock.unix_timestamp % 1000000
        );
        
        qr_account.code = qr_code.clone();
        qr_account.is_claimed = false;
        qr_account.partner_id = partner_id.clone();
        qr_account.batch_info = batch_info.clone();
        qr_account.created_at = clock.unix_timestamp;
        qr_account.claimed_at = None;
        qr_account.claimer = None;
        qr_account.bump = ctx.bumps.qr_code_account;
        
        usv_state.total_qr_codes += 1;
        
        msg!("🎫 Generated QR: {} for batch: {}", qr_code, batch_info);
        Ok(())
    }

    /// Claim tokens using QR code
    pub fn claim_tokens(
        ctx: Context<ClaimTokens>,
        qr_code: String,
        user_email: Option<String>,
    ) -> Result<()> {
        // First, check conditions and do CPI operations before mutably borrowing
        require!(!ctx.accounts.usv_state.is_paused, USVError::ProgramPaused);
        require!(!ctx.accounts.qr_code_account.is_claimed, USVError::QRCodeAlreadyClaimed);
        require!(ctx.accounts.qr_code_account.code == qr_code, USVError::InvalidQRCode);

        // Transfer 1 USV token
        let token_amount = 1_000_000;
        let seeds = &[b"usv_state".as_ref(), &[ctx.accounts.usv_state.bump]];
        let signer = &[&seeds[..]];
        
        let cpi_ctx = CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.admin_token_account.to_account_info(),
                to: ctx.accounts.claimer_token_account.to_account_info(),
                authority: ctx.accounts.usv_state.to_account_info(),
            },
            signer,
        );

        token::transfer(cpi_ctx, token_amount)?;

        // Now update all the state after CPI operations
        let usv_state = &mut ctx.accounts.usv_state;
        let qr_account = &mut ctx.accounts.qr_code_account;
        
        qr_account.is_claimed = true;
        qr_account.claimed_at = Some(Clock::get()?.unix_timestamp);
        qr_account.claimer = Some(ctx.accounts.claimer.key());

        // Update user history
        let user_history = &mut ctx.accounts.user_claim_history;
        if user_history.user == Pubkey::default() {
            user_history.user = ctx.accounts.claimer.key();
            user_history.total_claimed = 0;
            user_history.claimed_codes = Vec::new();
            user_history.bump = ctx.bumps.user_claim_history;
        }
        user_history.claimed_codes.push(qr_code.clone());
        user_history.total_claimed += 1;
        user_history.last_claim_at = Clock::get()?.unix_timestamp;

        usv_state.tokens_claimed += 1;

        msg!("🎉 Token claimed! QR: {}, Amount: 1 USV", qr_code);
        
        if let Some(email) = user_email {
            msg!("📧 User email: {}", email);
        }
        
        Ok(())
    }

    /// Buy tokens with SOL
    pub fn buy_tokens(
        ctx: Context<BuyTokens>,
        sol_amount: u64,
    ) -> Result<()> {
        require!(!ctx.accounts.usv_state.is_paused, USVError::ProgramPaused);

        // 1 SOL = 250 USV tokens
        let tokens_to_give = sol_amount * 250;
        require!(tokens_to_give >= 1_000_000, USVError::MinimumPurchase);

        // Transfer SOL to admin
        let transfer_ix = anchor_lang::system_program::Transfer {
            from: ctx.accounts.buyer.to_account_info(),
            to: ctx.accounts.admin.to_account_info(),
        };
        
        anchor_lang::system_program::transfer(
            CpiContext::new(ctx.accounts.system_program.to_account_info(), transfer_ix),
            sol_amount,
        )?;

        // Transfer tokens to buyer
        let seeds = &[b"usv_state".as_ref(), &[ctx.accounts.usv_state.bump]];
        let signer = &[&seeds[..]];
        
        let cpi_ctx = CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.admin_token_account.to_account_info(),
                to: ctx.accounts.buyer_token_account.to_account_info(),
                authority: ctx.accounts.usv_state.to_account_info(),
            },
            signer,
        );

        token::transfer(cpi_ctx, tokens_to_give)?;

        msg!("💰 Purchased {} USV for {} SOL", tokens_to_give / 1_000_000, sol_amount);
        Ok(())
    }

    /// Airdrop to partner
    pub fn airdrop_to_partner(
        ctx: Context<AirdropToPartner>,
        amount: u64,
        partner_info: String,
    ) -> Result<()> {
        require!(!ctx.accounts.usv_state.is_paused, USVError::ProgramPaused);

        let token_amount = amount * 1_000_000;

        let seeds = &[b"usv_state".as_ref(), &[ctx.accounts.usv_state.bump]];
        let signer = &[&seeds[..]];
        
        let cpi_ctx = CpiContext::new_with_signer(
            ctx.accounts.token_program.to_account_info(),
            Transfer {
                from: ctx.accounts.admin_token_account.to_account_info(),
                to: ctx.accounts.partner_token_account.to_account_info(),
                authority: ctx.accounts.usv_state.to_account_info(),
            },
            signer,
        );

        token::transfer(cpi_ctx, token_amount)?;

        msg!("🎁 Airdropped {} USV to {}", amount, partner_info);
        Ok(())
    }

    /// Set pause state
    pub fn set_pause_state(ctx: Context<SetPauseState>, is_paused: bool) -> Result<()> {
        let usv_state = &mut ctx.accounts.usv_state;
        usv_state.is_paused = is_paused;
        
        msg!("⏸️ Program paused: {}", is_paused);
        Ok(())
    }

    /// Update token price
    pub fn update_token_price(ctx: Context<UpdateTokenPrice>, new_price_cents: u64) -> Result<()> {
        let usv_state = &mut ctx.accounts.usv_state;
        require!(new_price_cents > 0, USVError::InvalidAmount);
        
        let old_price = usv_state.token_price_cents;
        usv_state.token_price_cents = new_price_cents;
        
        msg!("💵 Price updated from {} to {} cents", old_price, new_price_cents);
        Ok(())
    }

    /// Get statistics
    pub fn get_stats(ctx: Context<GetStats>) -> Result<()> {
        let usv_state = &ctx.accounts.usv_state;
        
        msg!("=== 🏆 USV Token Stats ===");
        msg!("👤 Admin: {}", usv_state.admin);
        msg!("🏦 Mint: {}", usv_state.mint);
        msg!("📊 Supply: {} tokens", usv_state.total_supply);
        msg!("🎁 Claimed: {}", usv_state.tokens_claimed);
        msg!("🎫 QR Codes: {}", usv_state.total_qr_codes);
        msg!("💵 Price: {} cents", usv_state.token_price_cents);
        msg!("⏸️ Paused: {}", usv_state.is_paused);
        
        Ok(())
    }
}

// Account structures
#[derive(Accounts)]
pub struct Initialize<'info> {
    #[account(
        init,
        payer = admin,
        space = 8 + USVState::LEN,
        seeds = [b"usv_state"],
        bump
    )]
    pub usv_state: Account<'info, USVState>,
    
    #[account(
        init,
        payer = admin,
        mint::decimals = 6,
        mint::authority = usv_state,
        seeds = [b"mint"],
        bump
    )]
    pub mint: Account<'info, Mint>,
    
    #[account(
        init,
        payer = admin,
        associated_token::mint = mint,
        associated_token::authority = usv_state,
    )]
    pub admin_token_account: Account<'info, TokenAccount>,
    
    #[account(mut)]
    pub admin: Signer<'info>,
    
    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
    pub rent: Sysvar<'info, Rent>,
}

#[derive(Accounts)]
#[instruction(count: u32)]
pub struct GenerateQRCodes<'info> {
    #[account(
        mut,
        seeds = [b"usv_state"],
        bump = usv_state.bump,
        has_one = admin
    )]
    pub usv_state: Account<'info, USVState>,
    
    #[account(
        init,
        payer = admin,
        space = 8 + QRCodeAccount::LEN,
        seeds = [b"qr_code", (usv_state.total_qr_codes + 1).to_le_bytes().as_ref()],
        bump
    )]
    pub qr_code_account: Account<'info, QRCodeAccount>,
    
    #[account(mut)]
    pub admin: Signer<'info>,
    
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(qr_code: String)]
pub struct ClaimTokens<'info> {
    #[account(
        mut,
        seeds = [b"usv_state"],
        bump = usv_state.bump
    )]
    pub usv_state: Account<'info, USVState>,
    
    #[account(
        mut,
        seeds = [b"qr_code", qr_code.as_bytes()],
        bump = qr_code_account.bump
    )]
    pub qr_code_account: Account<'info, QRCodeAccount>,
    
    #[account(
        mut,
        associated_token::mint = mint,
        associated_token::authority = usv_state,
    )]
    pub admin_token_account: Account<'info, TokenAccount>,
    
    #[account(
        init_if_needed,
        payer = claimer,
        associated_token::mint = mint,
        associated_token::authority = claimer,
    )]
    pub claimer_token_account: Account<'info, TokenAccount>,
    
    pub mint: Account<'info, Mint>,
    
    #[account(
        init_if_needed,
        payer = claimer,
        space = 8 + UserClaimHistory::LEN,
        seeds = [b"user_claims", claimer.key().as_ref()],
        bump
    )]
    pub user_claim_history: Account<'info, UserClaimHistory>,
    
    #[account(mut)]
    pub claimer: Signer<'info>,
    
    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct BuyTokens<'info> {
    #[account(
        seeds = [b"usv_state"],
        bump = usv_state.bump
    )]
    pub usv_state: Account<'info, USVState>,
    
    #[account(
        mut,
        associated_token::mint = mint,
        associated_token::authority = usv_state,
    )]
    pub admin_token_account: Account<'info, TokenAccount>,
    
    #[account(
        init_if_needed,
        payer = buyer,
        associated_token::mint = mint,
        associated_token::authority = buyer,
    )]
    pub buyer_token_account: Account<'info, TokenAccount>,
    
    pub mint: Account<'info, Mint>,
    
    /// CHECK: Admin account
    #[account(mut, address = usv_state.admin)]
    pub admin: UncheckedAccount<'info>,
    
    #[account(mut)]
    pub buyer: Signer<'info>,
    
    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct AirdropToPartner<'info> {
    #[account(
        seeds = [b"usv_state"],
        bump = usv_state.bump,
        has_one = admin
    )]
    pub usv_state: Account<'info, USVState>,
    
    #[account(
        mut,
        associated_token::mint = mint,
        associated_token::authority = usv_state,
    )]
    pub admin_token_account: Account<'info, TokenAccount>,
    
    #[account(
        init_if_needed,
        payer = admin,
        associated_token::mint = mint,
        associated_token::authority = partner,
    )]
    pub partner_token_account: Account<'info, TokenAccount>,
    
    pub mint: Account<'info, Mint>,
    
    /// CHECK: Partner wallet
    pub partner: UncheckedAccount<'info>,
    
    #[account(mut)]
    pub admin: Signer<'info>,
    
    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct SetPauseState<'info> {
    #[account(
        mut,
        seeds = [b"usv_state"],
        bump = usv_state.bump,
        has_one = admin
    )]
    pub usv_state: Account<'info, USVState>,
    
    pub admin: Signer<'info>,
}

#[derive(Accounts)]
pub struct UpdateTokenPrice<'info> {
    #[account(
        mut,
        seeds = [b"usv_state"],
        bump = usv_state.bump,
        has_one = admin
    )]
    pub usv_state: Account<'info, USVState>,
    
    pub admin: Signer<'info>,
}

#[derive(Accounts)]
pub struct GetStats<'info> {
    #[account(
        seeds = [b"usv_state"],
        bump = usv_state.bump
    )]
    pub usv_state: Account<'info, USVState>,
}

// State structures
#[account]
pub struct USVState {
    pub admin: Pubkey,
    pub mint: Pubkey,
    pub total_supply: u64,
    pub tokens_claimed: u64,
    pub total_qr_codes: u32,
    pub token_price_cents: u64,
    pub is_paused: bool,
    pub bump: u8,
}

impl USVState {
    pub const LEN: usize = 32 + 32 + 8 + 8 + 4 + 8 + 1 + 1;
}

#[account]
pub struct QRCodeAccount {
    pub code: String,
    pub is_claimed: bool,
    pub partner_id: Option<String>,
    pub batch_info: String,
    pub created_at: i64,
    pub claimed_at: Option<i64>,
    pub claimer: Option<Pubkey>,
    pub bump: u8,
}

impl QRCodeAccount {
    pub const LEN: usize = 4 + 32 + 1 + 1 + 4 + 64 + 4 + 64 + 8 + 1 + 8 + 1 + 32 + 1;
}

#[account]
pub struct UserClaimHistory {
    pub user: Pubkey,
    pub claimed_codes: Vec<String>,
    pub total_claimed: u64,
    pub last_claim_at: i64,
    pub bump: u8,
}

impl UserClaimHistory {
    pub const LEN: usize = 32 + 4 + (4 + 32) * 50 + 8 + 8 + 1;
}

// Error types
#[error_code]
pub enum USVError {
    #[msg("Program is paused")]
    ProgramPaused,
    #[msg("Invalid QR code count")]
    InvalidQRCodeCount,
    #[msg("QR code already claimed")]
    QRCodeAlreadyClaimed,
    #[msg("Invalid QR code")]
    InvalidQRCode,
    #[msg("Invalid amount")]
    InvalidAmount,
    #[msg("Minimum purchase is 1 token")]
    MinimumPurchase,
}